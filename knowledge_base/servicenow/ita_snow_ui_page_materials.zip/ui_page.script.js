window.addEventListener('load', () => {
    const ui = new CommonUi();
    ui.init().then(async function(){
        // UIページ ツールチップを無効化
        $.fn.tooltip = function(){ return this; };
        // UIページでもselect2が読み込まれているが、ITAで使っているバージョンと違うためITAで使用しているものを読み込む
        delete $.fn.select2;
        await fn.loadAssets({ type: 'js', url: '/_/ita/lib/select2/select2.min.js'});
        ui.setUi();
    });
});