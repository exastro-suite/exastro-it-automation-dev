// JavaScript Document

class WidgetCommon {
/*
##################################################
    Constructor
##################################################
*/
constructor( id, data, position, maxSize, infoData ) {
    this.id = id;
    this.data = data;
    this.widgetPosition = position;
    this.maxSize = maxSize;
    this.infoData = infoData;
    
    this.$ = {};
}
/*
##################################################
    Widget HTML
##################################################
*/
widgetHtml( titleNote = '' ) {
    const wg = this;
    
    const id = wg.id,
            data = wg.data;
    
    const attrs = {
        widget_id: 'data-widget-id',
        display: 'data-widget-display',
        header: 'data-widget-header',
        background: 'data-widget-background',
        rowspan: 'data-rowspan',
        colspan: 'data-colspan'
    }
    
    // Widget固有設定（attrがあるもの）
    if ( data.unique_setting.length ) {
        for ( const setting of data.unique_setting ) {
            if ( setting.attr ) {
                attrs[ setting.name ] = setting.attr;
            }
        }
    }
    const attr = [];
    for ( const k in attrs ) {
        const val = data[ k ];
        if ( val !== undefined ) attr.push(`${attrs[ k ]}="${val}"`);
    }

    // 編集ボタン
    const editButton = [`<li class="widget-edit-menu-item"><button class="widget-edit-button widget-edit" title="${getMessage.FTE08057}" data-type="edit">${fn.html.icon('edit')}</button></li>`];
    if ( data.widget_id !== 0 ) editButton.push(`<li class="widget-edit-menu-item"><button class="widget-edit-button widget-delete" title="${getMessage.FTE08058}" data-type="delete">${fn.html.icon('cross')}</button></li>`);
    
    const html = ``
    + `<div id="${id}" style="grid-area:${id}" class="widget-grid" ${attr.join(' ')}>`
        + `<div class="widget">`
            + `<div class="widget-header">`
                + `<div class="widget-move-knob"></div>`
                + `<div class="widget-name">`
                    + `<span class="widget-name-inner">${fn.cv( data.title, '', true ) + fn.cv( titleNote, '', true )}</span>`
                    + `<div class="widget-edit-menu">`
                        + `<ul class="widget-edit-menu-list">`
                            + editButton.join('')
                        + `</ul>`
                    + `</div>`
                + `</div>`
            + `</div>`
            + `<div class="widget-body">`
            + `</div>`
        + `</div>`
    + `</div>`;
    
    return html;
}
/*
##################################################
    Widget setting modal body HTML
##################################################
*/
modalOpen( currentPosition ) {
    const wg = this;
    
    return new Promise(function( resolve ){
        const config = {
            mode: 'modeless',
            position: 'top',
            width: '640px',
            header: {
                title: fn.cv( wg.data.title, '', true ),
            },
            footer: {
                button: {
                    ok: { text: getMessage.FTE00087, action: 'default'},
                    cancel: { text: getMessage.FTE00088, action: 'normal'},
                }
            }
        };

        const functions =  {
            ok: function(){
                $modal.find('.commonBody').not('.otherBlock').find('.input, .radioText:checked').each(function(){
                    const $input = $( this ),
                            type = $input.attr('type'),
                            val = $input.val(),
                            name = $input.attr('name');
                    
                    if ( type === 'number') {
                        const num = Number( val );
                        if ( isNaN( num ) ) {
                            wg.data[ name ] = null;
                        } else {
                            wg.data[ name ] = num;
                        }
                    } else {
                        wg.data[ name ] = val;
                    }
                });
                // リスト
                $modal.find('.otherBlock[data-block-type="list"]').each(function(){
                    const $list = $( this ),
                            name = $list.attr('data-block-name');
                    wg.data[ name ] = wg.getListData( $list );
                });
                closeModal( true );
            },
            cancel: function(){
                closeModal( false );
            }
        }

        const closeModal = function( flag ){
            wg.modal.close();
            wg.modal = null;
            resolve( flag );
        }
        
        const maxSize = wg.checkWidgetSize( currentPosition, wg.data.rowspan, wg.data.colspan );
        
        // Widget 基本設定
        const commonSetting = [
            {
                name: 'title',
                title: getMessage.FTE08059,
                type: 'text'
            },
            {
                name: 'colspan',
                title: getMessage.FTE08060,
                type: 'number',
                min: 1,
                max: maxSize[1]
            },
            {
                name: 'rowspan',
                title: getMessage.FTE08061,
                type: 'number',
                min: 1,
                max: maxSize[0]
            },
            {
                name: 'display',
                title: getMessage.FTE08062,
                type: 'radio',
                list: [
                    { value: 'show', text: getMessage.FTE08007 },
                    { value: 'hide', text: getMessage.FTE08008 }
                ]
            },
            {
                name: 'header',
                title: getMessage.FTE08063,
                type: 'radio',
                list: [
                    { value: 'show', text: getMessage.FTE08007 },
                    { value: 'hide', text: getMessage.FTE08008 }
                ]
            },
            {
                name: 'background',
                title: getMessage.FTE08064,
                type: 'radio',
                list: [
                    { value: 'show', text: getMessage.FTE08007 },
                    { value: 'hide', text: getMessage.FTE08008 }
                ]
            }
        ];

        const bodyHtml = ``
        + `<div class="commonSection">`
            + wg.settingModalBlock( getMessage.FTE08065, commonSetting )
            + `${( Object.keys( wg.data.unique_setting ).length )? wg.settingModalBlock( getMessage.FTE08066, wg.data.unique_setting ): ''}`
        + `</div>`;

        wg.modal = new Dialog( config, functions );
        wg.modal.open( bodyHtml );
        
        const $modal = wg.modal.$.dbody;
        
        // フェーダーイベント
        $modal.find('.inputFaderWrap').each(function(){
            fn.faderEvent( $( this ) );
        });
        
        // リストイベント
        wg.setListEvent( $modal );
        
        // サイズを更新するごとにサイズの最大値を更新する
        const $row = $modal.find('.inputFader[name="rowspan"]'),
                $col = $modal.find('.inputFader[name="colspan"]');
                
        $row.add( $col ).on('change', function(){
            const rowVal = Number( $row.val() ),
                    colVal = Number( $col.val() ),
                    max = wg.checkWidgetSize( currentPosition, rowVal, colVal ),
                    type = $( this ).attr('name');
            
            if ( type === 'rowspan') {
                $col.attr('data-max', max[1] ).trigger('maxChange');
            } else {
                $row.attr('data-max', max[0] ).trigger('maxChange');
            }
        });
    });
}
/*
##################################################
    サイズ変更可能な行列を求める
##################################################
*/
checkWidgetSize( p, setRow, setCol ) {
    const wg = this,
            wp = wg.widgetPosition,
            maxCol = wg.maxSize.col,
            maxRow = wg.maxSize.row,
            c = [];
    
    positionLabel:
    for ( let i = 0; i < maxRow; i++ ) {
        const rn = p[0] + i;
        if ( wp[rn] === undefined ) break;
        for ( let j = 0; j < maxCol - p[1]; j++ ) {
            const cn = p[1] + j;
            if ( wp[rn][cn] !== undefined && ( wp[rn][cn].match(/^b/) || wp[rn][cn] === wg.id )) {
                c[i] = j + 1;
            } else {
                if ( j === 0 ) {
                    break positionLabel;
                } else {
                    break;
                }
            }
        }
    }
    
    const cLength = c.length;
    let row = 0,
        col = wg.maxSize.col;
    
    // 列サイズ
    for ( let i = 0; i < setRow; i++ ) {
        if ( col > c[i] ) col = c[i];
    }
    
    // 行サイズ
    for ( let i = 0; i < cLength; i++ ) {
        if ( setCol <= c[i] ) {
            row++;
        } else {
            break;
        }
    }

    return [ row, col ];
}
/*
##################################################
    設定Block
##################################################
*/
settingModalBlock( title, commonSetting ) {
    const wg = this;
    
    const rows = [],
            other = [];
    for ( const setting in commonSetting ) {
        switch( commonSetting[ setting ].type ) {
            case 'list': other.push( wg.settingModalList( commonSetting[ setting ] ) ); break;
            default: rows.push( wg.settingModalRow( commonSetting[ setting ] ));
        }
    }
    
    const html = [];
    if ( rows.length ) {
        html.push(``
        + `<div class="commonTitle">${title}</div>`
        + `<div class="commonBody">`
            + `<div class="commonInputGroup">`
                + `<table class="commonInputTable">`
                    + `<tbody class="commonInputTbody">`
                        + rows.join('')
                    + `<tbody>`
                + `</table>`
            + `</div>`
        + `</div>`);
    }
    if ( other.length ) {
        html.push( other.join('') );
    }
    
    return html.join('');
}
/*
##################################################
    設定行
##################################################
*/
settingModalRow( settingData ) {
    return ``
    + `<tr class="commonInputTr">`
        + `<th class="commonInputTh"><div class="commonInputTitle">${fn.cv( settingData.title, '', true )}</div></th>`
        + `<td class="commonInputTd">${this.settingModalInput( settingData )}</td>`
    + `</tr>`;
}
/*
##################################################
    設定入力欄
##################################################
*/
settingModalInput( settingData ) {
    const key = settingData.name,
            value = fn.cv( this.data[ key ], '', true );
    switch ( settingData.type ) {
        case 'text':  return fn.html.inputText('db-modal-text', value, key );
        case 'number': {
            const option = {};
            if ( settingData.before ) option.before = settingData.before;
            if ( settingData.after ) option.after = settingData.after;
            return fn.html.inputFader('db-modal-number', value, key, { min: settingData.min, max: settingData.max }, option );
        }
        case 'radio': return this.settingModalInputRadio( value, key, settingData.list );
    }
}
/*
##################################################
    設定ラジオ
##################################################
*/
settingModalInputRadio( value, key, list ) {
    const itemArray = [];    
    for ( const item of list ) {
        const itemValue = item.value,
                text = fn.cv( item.text, '', true ),
                checked = ( value === itemValue )? { checked: 'checked'}: {},
                listHtml = `<li class="commonRadioItem">${fn.html.radioText('db-modal-radio', itemValue, key, `db-modal-radio-${key}_${itemValue}`, checked, text )}</li>`;
        itemArray.push( listHtml );
    }
    
    return `<ul class="commonRadioList">${itemArray.join('')}</ul>`;
}
/*
##################################################
    設定リスト
##################################################
*/
settingModalList( settingData ) {
    const wg = this;
    
    const key = settingData.name;
    
    // 編集メニュー
    const menuList = {
        Main: [
            { button: { type: 'add', icon: 'plus', text: getMessage.FTE08014, action: 'normal'}},
            { button: { type: 'download', icon: 'download', text: getMessage.FTE08015, action: 'normal'}, separate: true },
            { button: { type: 'read', icon: 'upload', text: getMessage.FTE08016, action: 'normal'}},
        ]
    };
    
    let html = ``
    + `<div class="commonTitle">${fn.cv( settingData.title, '', true )}</div>`
    + `<div class="commonBody otherBlock" data-block-name="${key}" data-block-type="${settingData.type}">`
    + `<div class="commonInputGroup">`
    + fn.html.operationMenu( menuList )
    + `<table class="db-modal-list-table">`
        + `<thead class="db-modal-list-thead">`
            + `<tr>`
                + `<th class="db-modal-list-th db-modal-list-action"></th>`;
    
    for ( const type in settingData.list ) {
        html += `<th class="db-modal-list-th"><div class="db-modal-list-header">${settingData.list[ type ]}</div></th>`;
    }
    
    html += ``
                + `<th class="db-modal-list-th db-modal-list-action"></th>`
            + `<tr>`
        + `</thead>`
        + `<tbody class="db-modal-list-tbody">`
    
    let value = this.data[ key ];
    if ( !value || !value.length ) {
        value = [{name: '', url: ''}];
    }
    
    const disabled = ( value.length === 1 )? true: false;
    wg.listIndex = 0;
    for ( const item of value ) {
        html += wg.createListRowHtml( key, item, disabled );
    }
    
    html += ``
            + `<tr>`
        + `</tbody>`
    + `</table>`
    + `</div>`
    + `</div>`;
    
    return html;
}
/*
##################################################
    リストHTML
##################################################
*/
createListRowHtml( key, item, disabledFlag = false ) {
    const wg = this;
    
    const disabled = ( disabledFlag )? ' disabled': '',
            row = [`<tr class="db-modal-list-tr"><td class="db-modal-list-td"><div class="db-modal-list-move${disabled}"></div></td>`];
    
    for ( const type in item ) {
        const idName = `${key}_${type}_${wg.listIndex}`;
                row.push(`<td class="db-modal-list-td"><div class="db-modal-list-input">${fn.html.inputText('db-modal-text', fn.cv( item[ type ], '', true ), idName, { key: type } )}</div></td>`);
    }    
    wg.listIndex++;
    row.push(`<td class="db-modal-list-td"><div class="db-modal-list-delete${disabled}">${fn.html.icon('cross')}</div></td></tr>`);
    return row.join('');
}
/*
##################################################
    項目が１つの場合は移動と削除を無効化する
##################################################
*/
checkListDisabled() {
    const wg = this;
    
    const $tr = wg.modal.$.dbody.find('.db-modal-list-tr');

    if ( $tr.length === 1 ) {
        $tr.find('.db-modal-list-move, .db-modal-list-delete').addClass('disabled');
    } else {
        $tr.find('.db-modal-list-move, .db-modal-list-delete').removeClass('disabled');
    }
    
}
/*
##################################################
    リストイベント
##################################################
*/
setListEvent() {
    const wg = this;

    wg.modal.$.dbody.find('.otherBlock[data-block-type="list"]').each(function(){
        const $listBlock = $( this ),
                key = $listBlock.attr('data-block-name');
        
        // メニュー
        $listBlock.find('.operationMenuButton').on('click', function(){
            const $button = $( this ),
                    type = $button.attr('data-type');
            switch( type ) {
                case 'add': {
                    const empty = {},
                            setting = wg.data.unique_setting.find(function( item ){ return item.name === key; });
                    for ( const item in setting.list ) {
                        empty[ item ] = '';
                    }
                    $listBlock.find('.db-modal-list-tbody').append( wg.createListRowHtml( key, empty ) );
                    wg.checkListDisabled();
                } break;
                case 'download': {
                    let downloadData;
                    try {
                        downloadData = JSON.stringify( wg.getListData( $listBlock ) );
                    } catch( error ) {
                        alert( error );
                    }
                    fn.download('text', downloadData, `dashboard_${key}`);
                } break;
                case 'read':
                    fn.fileSelect('json').then(function( result ){
                        const rowHtml = [];
                        for ( const item in result.json ) {
                            rowHtml.push( wg.createListRowHtml( key, result.json[ item ] ) );
                        }
                        $listBlock.find('.db-modal-list-tbody').html( rowHtml.join('') );
                    }).catch(function( error ){
                        alert( error );
                    });
                break;
            }
        });
        
        // 削除
        $listBlock.on('mousedown', '.db-modal-list-delete', function(){
            $( this ).closest('.db-modal-list-tr').remove();
            wg.checkListDisabled();
        });
        
        // 移動
        $listBlock.on('mousedown', '.db-modal-list-move', function( mde ){
            const $move = $( this ),
                    $window = $( window );
                    
            if ( !$move.is('.disabled') ) {
                const $line = $move.closest('.db-modal-list-tr'),
                        $list = $line.closest('.db-modal-list-tbody'),
                        height = $line.outerHeight(),
                        defaultY = $line.position().top,
                        maxY = $list.outerHeight() - height,
                        $dummy = $('<tr class="db-modal-list-dummy"></tr>'),
                        $body = $move.closest('.dialogBody'),
                        defaultScroll = $body.scrollTop();
                
                // 幅を固定
                $line.find('.db-modal-list-td').each(function(){
                    const $td = $( this );
                    $td.css('width', $td.outerWidth() );
                });
                
                $list.addClass('active');
                $line.addClass('move').css('top', defaultY ).after( $dummy )
                $dummy.css('height', height );
                
                fn.deselection();

                let positionY = defaultY;
                const listPosition = function(){
                    let setPostion = positionY - ( defaultScroll - $body.scrollTop() );
                    if ( setPostion < 0 ) setPostion = 0;
                    if ( setPostion > maxY ) setPostion = maxY;
                    $line.css('top', setPostion );
                };

                $body.on('scroll.freeMove', function(){
                    listPosition();
                });
                
                $window.on({
                    'mousemove.freeMove': function( mme ){
                        positionY = defaultY + mme.pageY - mde.pageY;
                        listPosition();
                        if ( $( mme.target ).closest('.db-modal-list-tr').length ) {
                            const $target = $( mme.target ).closest('.db-modal-list-tr'),
                                    targetNo = $target.index(),
                                    dummyNo = $dummy.index();
                            if ( targetNo < dummyNo ) {
                                $target.before( $dummy );
                            } else {
                                $target.after( $dummy );
                            }
                        }
                    },
                    'mouseup.freeUp': function(){
                        $body.off('scroll.freeMove');
                        $window.off('mousemove.freeMove mouseup.freeUp');
                        $list.removeClass('active');
                        $line.removeClass('move');
                        $line.find('.db-modal-list-td').removeAttr('style');
                        $dummy.replaceWith( $line );
                    }
                });
            }
        });
        
        
    });
    
}
/*
##################################################
    リストデータ取得
##################################################
*/
getListData( $list ) {
    const data = [];
    $list.find('.db-modal-list-tr').each(function(){
        const $tr = $( this ),
                row = {};
        $tr.find('.input').each(function(){
            const $item = $( this ),
                    val = $item.val(),
                    name = $item.attr('data-key');
            row[ name ] = val;
        });
        // 未入力がある場合は無視
        let count = 0;
        for ( const key in row ) {
            if ( row[ key ] === '') count++;
        }
        if ( count === 0 ) data.push( row );
    });
    return data;
}
/*
##################################################
    リンクHTML
##################################################
*/
linkHtml( className, href, text, type = 'same', option = {}) {
    if ( option.encode === true ) {
        href = encodeURI( fn.cv( href, '' ) );
    }
    
    const attr = [`class="${className} db-link" href="${href}" data-type="${type}"`];
    if ( type === 'blank') {
        attr.push(`target="_blank" rel="noopener noreferrer"`);
    }

    return `<a ${attr.join(' ')}>${text}</a>`;
}

}
class WidgetImage extends WidgetCommon {
/*
##################################################
    Widget
##################################################
*/
widget() {
    const wg = this;
    
    wg.$.widget = $( wg.widgetHtml() );
    wg.$.widget.find('.widget-body').html( wg.body() );
    
    return wg.$.widget;
}
/*
##################################################
    Body
##################################################
*/
body() {
    const wg = this,
            imageHtml = `<img class="db-image" src="${fn.cv( wg.data.image_url, '', true )}">`;
    
    if ( wg.data.link_url !== '') {
        const url = encodeURI( wg.data.link_url );
        return wg.linkHtml('db-image-link', url, imageHtml, wg.data.page_move );
    } else {
        return imageHtml;
    }
}

}
class WidgetLinkList extends WidgetCommon {
/*
##################################################
    Widget
##################################################
*/
widget() {
    const wg = this;
    
    wg.$.widget = $( wg.widgetHtml() );
    wg.$.widget.find('.widget-body').html( wg.body() );
    
    return wg.$.widget;
}
/*
##################################################
    Body
##################################################
*/
body() {
    const wg = this;
    
    const html = [];
    if ( fn.typeof( wg.data.link_list ) === 'array' && wg.data.link_list.length) {
        for ( const item of wg.data.link_list ) {
            const url = encodeURI( item.url ),
                text = fn.cv( item.name, '', true );
            html.push(``
            + `<li class="db-linklist-item" style="width:calc(100%/${fn.cv( wg.data.menu_number, 1 )});">`
                + wg.linkHtml('db-linklist-link', url, text, wg.data.page_move )
            + `</li>`);
        }
    }
    
    return `<div class="db-linklist-list-warp"><ul class="db-linklist-list">${html.join('')}</ul></div>`;
}

}
class WidgetMenuGroup extends WidgetCommon {
/*
##################################################
    Widget
##################################################
*/
widget() {
    const wg = this;
    
    wg.$.widget = $( wg.widgetHtml() );
    wg.$.widget.find('.widget-body').html( wg.body() );
    
    return wg.$.widget;
}
/*
##################################################
    Body
##################################################
*/
body() {
    const wg = this;
    
    const list = [];
    
    const menuGroups = wg.createMenuGroupList( wg.infoData );
    for ( const menuGroup of menuGroups ) {
        // ポジション情報がない場合はw0に変更する
        if ( menuGroup.position === '' ) menuGroup.position = 'w0';
        
        if ( menuGroup.position === wg.id && menuGroup.parent_id === null && menuGroup.menus.length && menuGroup.main_menu_rest ) {
                const menuNameRest = menuGroup.main_menu_rest,
                    menuGroupId = menuGroup.id,
                    icon = ( menuGroup.icon )? `data:;base64,${menuGroup.icon}`: `${conf.webAssetsUrl}/_/ita/imgs/icon_default.png`;

                const link = ``
                + `<div class="db-menu-group-link-inner">`
                    + `<div class="db-menu-group-item-image"><img src="${icon}"></div>`
                    + `<div class="db-menu-group-item-name">${fn.cv( menuGroup.menu_group_name, '', true )}</div>`
                + `</div>`;

                const href = fn.createPageUrl( menuNameRest );
                const html = ``
                + `<li class="db-menu-group-item" style="width:calc(100%/${wg.data.menu_number})" data-menu-id="${menuGroupId}">`
                    + wg.linkHtml('db-menu-group-link', href, link, wg.data.page_move );
                + `</li>`;
                list.push( html );
            }
    }
    return `<div class="db-menu-group"><ul class="db-menu-group-list">${list.join('')}</ul></div>`;    
}
/*
##################################################
    Sort : disp_seq
##################################################
*/
dispSeqSort( data ) {
    data.sort(function( a, b ){
        if ( a.disp_seq < b.disp_seq ) {
            return -1;
        } else if ( a.disp_seq > b.disp_seq ) {
            return 1;
        } else {
            // disp_seqが同じ場合は名前で判定する
            const aa = ( a.menu_group_name )? a.menu_group_name: ( a.menu_name )? a.menu_name: '',
                    bb = ( b.menu_group_name )? b.menu_group_name: ( b.menu_name )? b.menu_name: '';
            if ( aa < bb ) {
                return -1;
            } else if ( aa > bb ) {
                return 1;
            } else {
                return 0;
            }
        }
    });
}
/*
##################################################
    メニューデ階層データの作成
##################################################
*/
createMenuGroupList( infoData ) {
    const wg = this;

    // メニューグループリストの作成
    const menuGroupList = [],
            childs = [];

    // 配列のディープコピー
    const tempMenuGroups = $.extend( true, [], infoData );

    // 親と子を分ける
    for ( const menuGroup of tempMenuGroups ) {
        if ( menuGroup.parent_id === null ) {
            menuGroupList.push( menuGroup );
        } else {
            childs.push( menuGroup );
        }
    }

    // 親に子を追加
    for ( const parent of menuGroupList ) {
        for ( const child of childs ) {
            if ( parent.id === child.parent_id ) {
                child.main_menu_rest = null;
                if ( child.menus && child.menus.length ) {
                    wg.dispSeqSort( child.menus );
                    if ( child.menus[0].menu_name_rest ) {
                            child.main_menu_rest = child.menus[0].menu_name_rest;
                    }
                }
                parent.menus.push( child );
            }
        }
        wg.dispSeqSort( parent.menus );

        parent.main_menu_rest = null;
        let subRest = null;
        let count = 0;
        for ( const menu of parent.menus ) {
            if ( menu.menu_name_rest && parent.main_menu_rest === null && count === 0 ) {
                parent.main_menu_rest = menu.menu_name_rest;
            } else if ( menu.menus && menu.menus.length && menu.menus[0].menu_name_rest && subRest === null  ) {
                subRest = menu.menus[0].menu_name_rest;
            }
            count++;
        }
        if ( !parent.main_menu_rest && subRest ) parent.main_menu_rest = subRest;
    }
    wg.dispSeqSort( menuGroupList );

    return menuGroupList;
}

}
class WidgetPieChart extends WidgetCommon {
/*
##################################################
    Widget
##################################################
*/
widget() {
    const wg = this;
    
    wg.$.widget = $( wg.widgetHtml() );
    wg.$.widget.find('.widget-body').html( wg.body() );
    
    return wg.$.widget;
}
/*
##################################################
    Movement（movement）データ変換
##################################################
*/
movement( data ) {
    const movementSetting = {
        'Ansible Legacy':  ['ansible_legacy', 0, fn.createPageUrl('movement_list_ansible_legacy'), '#F0891D'],
        'Ansible Pioneer':  ['ansible_pioneer', 0, fn.createPageUrl('movement_list_ansible_pioneer'), '#009768'],
        'Ansible Legacy Role':  ['ansible_legacy_role', 0, fn.createPageUrl('movement_list_ansible_role'), '#684915'],
        'Terraform Cloud/EP':  ['terraform_cloud_ep', 0, fn.createPageUrl('movement_list_terraform_cloud_ep'), '#6C60E8'],
        'Terraform CLI':  ['terraform_cli', 0, fn.createPageUrl('movement_list_terraform_cli'), '#889dd8'],
    };
    const movementData = {};
    for ( const key in data ) {
        const num = Number( data[ key ].number );
        if ( !isNaN( num ) && num !== 0 ) {
            const name = data[ key ].name;
            movementData[ name ] = movementSetting[ name ];
            movementData[ name ][ 1 ] = num;
        }
    }
    return movementData;
}
/*
##################################################
    作業状況（work_info）データ変換
##################################################
*/
workStatus( data ) {
    const workStatusSetting = {};
    const href = fn.createPageUrl('conductor_list');
    workStatusSetting[ getMessage.FTE08076 ] = ['runing', 0, href, '#002B62'];
    workStatusSetting[ getMessage.FTE08077 ] = ['schedule', 0, href, '#7A91AD'];
    workStatusSetting[ getMessage.FTE08078 ] = ['stop', 0, href, '#FF640A'];
    workStatusSetting[ getMessage.FTE08079 ] = ['waiting', 0, href, '#ADADAD'];

    // フィルター
    for ( const type in workStatusSetting ) {
        const filter = {
            status_id: {
                LIST: type
            }
        };
        workStatusSetting[ type ][2] += `&filter=${fn.filterEncode( filter )}`;
    }
    
    for ( const type in data ) { // conductor
        for ( const num in data[ type ] ) {
            for ( const id in data[ type ][ num ] ) {
                const result = data[ type ][ num ][ id ];
                if ( workStatusSetting[ result.status ] ) {
                    workStatusSetting[ result.status ][1]++;
                }
            }
        }
    }
    return workStatusSetting;
}
/*
##################################################
    作業結果（work_result）データ変換
##################################################
*/
workResult( data ) {
    const workResultSetting = {};
    const href = fn.createPageUrl('conductor_list');
    workResultSetting[ getMessage.FTE08068 ] = ['done', 0, href, '#91D21E'];
    workResultSetting[ getMessage.FTE08069 ] = ['fail', 0, href, '#8227B4'];
    workResultSetting[ getMessage.FTE08070 ] = ['warning', 0, href, '#FFB400'];
    workResultSetting[ getMessage.FTE08071 ] = ['stop', 0, href, '#FFDC00'];
    workResultSetting[ getMessage.FTE08072 ] = ['cancel', 0, href, '#FF69A3'];
    workResultSetting[ getMessage.FTE08073 ] = ['error', 0, href, '#E60000'];

    // フィルター
    for ( const type in workResultSetting ) {
        const filter = {
            status_id: {
                LIST: type
            }
        };
        workResultSetting[ type ][2] += `&filter=${fn.filterEncode( filter )}`;
    }
    
    const resultData = {};
    for ( const type in data ) { // conductor
        for ( const num in data[ type ] ) {
            for ( const id in data[ type ][ num ] ) {
                const result = data[ type ][ num ][ id ];
                if ( workResultSetting[ result.status ] ) {
                    workResultSetting[ result.status ][1]++;
                }                
            }
        }
    }
    return workResultSetting;
}
/*
##################################################
    円グラフ
##################################################
*/
body() {
    const wg = this;

    // 円グラフデータ変換
    let pieChartData;
    switch ( wg.data.widget_name ) {
        case 'movement': pieChartData = wg.movement( wg.infoData ); break;
        case 'workStatus': pieChartData = wg.workStatus( wg.infoData ); break;
        case 'workResult': pieChartData = wg.workResult( wg.infoData ); break;
        default: pieChartData = wg.infoData;
    }
    
    const widgetID = wg.id,
            title = fn.cv( wg.data.pie_chart_title, '', true );
    
    const xmlns = 'http://www.w3.org/2000/svg',
            radius = 50,  // 円グラフ半径
            strokeWidth = 20,  // 円グラフ線幅
            circumference = radius * 2 * Math.PI, // 円周（半径×２×円周率）
            cxcy = radius + strokeWidth,
            viewBox = cxcy * 2,
            viewBoxAttr = '0 0 ' + viewBox + ' ' + viewBox;
    
    // 円グラフ
    const $pieChartSvg = $( document.createElementNS( xmlns, 'svg') );
    $pieChartSvg.attr('class','pie-chart-svg').get(0).setAttribute('viewBox', viewBoxAttr );
    
    // 装飾
    const $pieChartSvgDecoration = $( document.createElementNS( xmlns, 'svg') );
    $pieChartSvgDecoration.attr('class','pie-chart-decoratio-svg').get(0).setAttribute('viewBox', viewBoxAttr );
    $pieChartSvgDecoration.html(
        '<circle cx="' + cxcy + '" cy="' + cxcy + '" r="' + ( cxcy - 5 ) + '" class="pie-chart-circle-outside"></circle>'
        + '<circle cx="' + cxcy + '" cy="' + cxcy + '" r="' + ( cxcy - 15 - strokeWidth ) + '" class="pie-chart-circle-inside"></circle>'
    );
    
    // 割合表示
    const $pieChartRatioSvg = $( document.createElementNS( xmlns, 'svg') );
    $pieChartRatioSvg.attr('class','pie-chart-ratio-svg').get(0).setAttribute('viewBox', viewBoxAttr );
    
    const outSideNamber = [];
    let totalNumber = 0,
        serialWidthNumber = 0,
        serialAngleNumber = -90,
        outsideGroupCheck = 0,
        outsideGroupNumber = -1,
        checkGroupText = '';
    
    // 合計値
    for ( let key in pieChartData ) {
        totalNumber += pieChartData[key][1];
    }
    
    // Table
    let tableHTML = '';
    if ( Object.keys( pieChartData ).length ) {
        tableHTML += ''
        + '<div class="db-table-wrap">'
            + '<table class="db-table">'
            + '<tbody>';
        for ( let key in pieChartData ) {
            const number = Number( pieChartData[key][1] ),
                    numHtml = ( number !== 0 )?
                wg.linkHtml('db-cell-l db-cell-ln', pieChartData[key][2], number, wg.data.page_move ):
                `<span class="db-cell-z">0</span>`;

            tableHTML += ''
                + '<tr class="db-row" data-type="' + pieChartData[key][0] + '">'
                    + '<th class="db-cell"><div class="db-cell-i">'
                    + '<span class="db-usage" style="background-color:' + pieChartData[key][3] + '"></span>' + key
                    + '</div></th>'
                    + '<td class="db-cell"><div class="db-cell-i">'
                    + numHtml
                    + '</div></td>'
                + '</tr>';
        }
        tableHTML += ''
            + '</tbody>'
            + '</table>'
        + '</div>';
    } else {
        tableHTML += '<div class="db-nodata">No data</div>';
    }
    
    for ( let key in pieChartData ) {
        const $pieChartCircle = $( document.createElementNS( xmlns, 'circle') ),
                $pieChartText = $( document.createElementNS( xmlns, 'text') );

        // 割合・幅の計算
        const className = 'circle-' + pieChartData[key][0],
                number = pieChartData[key][1],
                ratio = number / totalNumber,
                angle = 360 * ratio;

        // 幅
        let ratioWidth = Math.round( circumference * ratio * 1000 ) / 1000;
        if ( serialWidthNumber + ratioWidth > circumference ) ratioWidth = circumference - serialWidthNumber;
        const remainingWidth =  Math.round( ( circumference - ( serialWidthNumber + ratioWidth ) ) * 1000 ) / 1000;

        // stroke-dasharrayの形に整える
        let strokeDasharray = '';
        if ( isNaN( ratioWidth ) ) {
            strokeDasharray === 'none';
        } else {
            if ( serialWidthNumber === 0 ) {
                strokeDasharray = ratioWidth + ' ' + remainingWidth + ' 0 0';
            } else {
                strokeDasharray = '0 ' + serialWidthNumber + ' ' + ratioWidth + ' '+ remainingWidth;
            }
        }

        // 属性登録
        $pieChartCircle.attr({
            'cx': cxcy,
            'cy': cxcy,
            'r': radius,
            'stroke': pieChartData[key][3],
            'class': 'pie-chart-circle ' + className,
            'style': 'stroke-dasharray:0 0 0 '+ circumference,
            'data-style': strokeDasharray,
            'data-type': pieChartData[key][0]
        });

        // 追加
        $pieChartSvg.append( $pieChartCircle );

        // 割合追加
        if ( ratio > 0 ) {
            const textAngle = serialAngleNumber + ( angle / 2 ),
                    centerPosition = wg.anglePiePosition( cxcy, cxcy, radius, textAngle );
            let ratioClass = 'pie-chart-ratio ' + className,
                x = centerPosition[0],
                y = centerPosition[1];

            const displayRatio = Math.round( ratio * 1000 ) / 10;

            // 特定値以下の場合は表示の調整をする
            if ( displayRatio < 2.5 ) {
                if ( outsideGroupCheck === 0 ) {
                    checkGroupText += '@'; // グループフラグ
                    outsideGroupNumber++;
                    outSideNamber[outsideGroupNumber] = new Array();
                }
                outsideGroupCheck = 1;
                outSideNamber[outsideGroupNumber].push( [ratioClass,textAngle,displayRatio] );
            } else {
                // 30%以下の場合グループを分けない
                if ( displayRatio > 30 ) {
                    outsideGroupCheck = 0;
                    checkGroupText += 'X';
                }
                if ( displayRatio < 10 ) {
                    ratioClass += ' rotate';
                    let rotateAngle = textAngle;
                    if ( textAngle > 90 ) rotateAngle = rotateAngle + 180;
                    $pieChartText.attr('transform', 'rotate('+rotateAngle+','+x+','+y+')' );
                        y += 1.5; //ベースライン調整
                } else {
                        y += 2.5;
                }
                $pieChartText.html( displayRatio + '<tspan class="ratio-space"> </tspan><tspan class="ratio-mark">%</tspan>').attr({
                    'x': x,
                    'y': y,
                    'text-anchor': 'middle',
                    'stroke': pieChartData[key][3],
                    'class': ratioClass
                });
                $pieChartRatioSvg.append( $pieChartText );
            }
        }

        // スタート幅
        serialWidthNumber += ratioWidth;
        serialAngleNumber += angle;
        if ( serialWidthNumber > circumference ) serialWidthNumber = circumference;
    }
    
    // 2.5%以下は外側に表示する
    let outSideGroupLength = outSideNamber.length;
    if ( outSideNamber.length > 0 ) {
        // 最初と最後が繋がる場合、最初のグループを最後に結合する
        if ( checkGroupText.length > 2 && checkGroupText.slice( 0, 1 ) === '@' && checkGroupText.slice( -1 ) === '@' ) {
            outSideNamber[ outSideGroupLength - 1] = outSideNamber[ outSideGroupLength - 1].concat( outSideNamber[0] );
            outSideNamber.shift();
            outSideGroupLength = outSideNamber.length;
        }
        for ( let i = 0; i < outSideGroupLength; i++ ) {
            const outSideNamberLength = outSideNamber[i].length;
            if ( outSideNamberLength > 0 ) {
                const maxOutWidth = 14;
                // 配列の真ん中から処理する
                let arrayNumber = Math.floor( ( outSideNamberLength - 1 ) / 2 );
                for ( let j = 0; j < outSideNamberLength; j++ ) {
                    arrayNumber = ( ( j + 1 ) % 2 !== 0 )? arrayNumber - j: arrayNumber + j; 
                    if ( outSideNamber[i][arrayNumber] !== undefined ) {
                        const $pieChartText = $( document.createElementNS( xmlns, 'text') ),
                                $pieChartLine = $( document.createElementNS( xmlns, 'line') ),
                                count = Math.floor( j / 2 ),
                                position = radius + maxOutWidth;
                        let textAnchor = 'middle',
                            ratioClass = outSideNamber[i][arrayNumber][0]  + ' outside',
                            angle = outSideNamber[i][arrayNumber][1],
                            ratio = outSideNamber[i][arrayNumber][2],
                            newAngle = angle,
                            lineStartPositionAngle,
                            rotetaNumber,
                            verticalPositionNumber = 0;

                        // 横位置調整
                        const setAngle = 16 * count + 8,
                                setLineAngle = ( Number.isInteger( ratio ) )? 4: 6;
                        if ( ( j + 1 ) % 2 !== 0 ) {
                            newAngle -= setAngle;
                            lineStartPositionAngle = newAngle + setLineAngle;
                        } else {
                            newAngle += setAngle;
                            lineStartPositionAngle = newAngle - setLineAngle;
                        }

                        if ( newAngle > 0 && newAngle < 180 ) {
                            verticalPositionNumber = 4;
                            rotetaNumber = newAngle + 270;
                        } else {
                            rotetaNumber = newAngle + 90;
                        }

                        const outsidePosition = wg.anglePiePosition( cxcy, cxcy, position, newAngle ),
                                x = outsidePosition[0],
                                y = outsidePosition[1],
                                lineStartPosition = wg.anglePiePosition( cxcy, cxcy, position, lineStartPositionAngle ),
                                x1 = lineStartPosition[0],
                                y1 = lineStartPosition[1],
                                lineEndPosition = wg.anglePiePosition( cxcy, cxcy, radius + strokeWidth / 2 - 2, angle ),
                                x2 = lineEndPosition[0],
                                y2 = lineEndPosition[1];

                        $pieChartLine.attr({
                            'x1': x1,
                            'y1': y1,
                            'x2': x2,
                            'y2': y2,
                            'class': 'pie-chart-ratio-line'
                        });
                        $pieChartText.html( ratio + '<tspan class="ratio-space"> </tspan><tspan class="ratio-mark">%</tspan>' ).attr({
                            'x': x,
                            'y': y + verticalPositionNumber,
                            'text-anchor': textAnchor,
                            'class': ratioClass,
                            'transform': 'rotate(' + rotetaNumber + ',' + x + ',' +y + ')'
                        });
                        $pieChartRatioSvg.append( $pieChartText, $pieChartLine );
                    }
                }
            }
        }
    }
    
    // テキスト
    const $pieChartTotalSvg = $( document.createElementNS( xmlns, 'svg') );
    $pieChartTotalSvg.get(0).setAttribute('viewBox', '0 0 ' + viewBox + ' ' + viewBox );
    $pieChartTotalSvg.attr('class','pie-chart-total-svg');

    const $pieChartName = $( document.createElementNS( xmlns, 'text') ).text( title ).attr({
        'class': 'pie-chart-total-name', 'x': '50%', 'y': '35%'
    });
    const $pieChartNumber = $( document.createElementNS( xmlns, 'text') ).text( totalNumber ).attr({
        'class': 'pie-chart-total-number', 'x': '50%', 'y': '50%'
    });
    const $pieChartTotal = $( document.createElementNS( xmlns, 'text') ).text('Total').attr({
        'class': 'pie-chart-total-text', 'x': '50%', 'y': '60%'
    });  
    $pieChartTotalSvg.append( $pieChartName, $pieChartNumber, $pieChartTotal );
    
    // SVG / HTML set
    const $pieChartHTML = $('<div class="pie-chart"><div class="pie-chart-inner"></div></div>' + tableHTML );
    $pieChartHTML.find('.pie-chart-inner').append( $pieChartSvgDecoration, $pieChartTotalSvg, $pieChartSvg, $pieChartRatioSvg );  
    
    return $pieChartHTML;
}
/*
##################################################
    角度から位置を求める
##################################################
*/
anglePiePosition ( x1, y1, r, a ) {
    const x2 = x1 + r * Math.cos( a * ( Math.PI / 180 ) ),
            y2 = y1 + r * Math.sin( a * ( Math.PI / 180 ) );
    return [ x2, y2 ];
}
/*
##################################################
    準備完了時
##################################################
*/
ready() {
    const wg = this;
    
    const $pieChartSvg = wg.$.widget.find('.pie-chart-svg'),
            $pieChartRatioSvg = wg.$.widget.find('.pie-chart-ratio-svg'),
            $pieChartHTML = wg.$.widget.find('.widget-body'),
            $circles = $pieChartSvg.find('.pie-chart-circle'),
            circleLength = $circles.length,
            strokeWidth = 20;

    let circleAnimationCount = 0;
    $pieChartRatioSvg.css('opacity','1');
    // 仮セットした値を本セットする
    $circles.each( function(){
        const $circle = $( this );
        if ( $circle.attr('data-style') !== '') {
            $circle.attr('style', ''
                + 'stroke-dasharray:' + $circle.attr('data-style') + ';'
                + 'stroke-width: ' + strokeWidth + 'px;');
        }
    }).on({
        // 全てのアニメーションが終わったら
        'transitionend webkitTransitionEnd': function() {
            circleAnimationCount++;
            if ( circleAnimationCount >= circleLength ) {
            $pieChartHTML.removeClass('start');
            // 円グラフホバー
            $circles.on({
                'mouseenter': function(){
                const $enter = $( this ),
                        dataType = $enter.attr('data-type');
                if ( dataType !== undefined ) {
                    $enter.closest('.widget-body').find('tr[data-type="' + dataType + '"]').addClass('emphasis');
                    $enter.css('stroke-width', strokeWidth * 1.2 );
                }
                },
                'mouseleave': function(){
                const $leave = $( this ),
                        dataType = $leave.attr('data-type');
                if ( dataType !== undefined ) {
                    $leave.css('stroke-width', strokeWidth );
                    $leave.closest('.widget-body').find('.emphasis').removeClass('emphasis');
                }
                },
                'click': function() {
                    const $pie = $( this ),
                        dataType = $pie.attr('data-type');
                    if ( dataType !== undefined ) {
                        $pie.closest('.widget-body').find('tr[data-type="' + dataType + '"]').find('.db-cell-l')[0].click();
                    }
                }
            });
            // Tableグラフホバー
            $pieChartHTML.find('.db-row').on({
                'mouseenter': function(){
                const $enter = $( this ),
                        dataType = $enter.attr('data-type');
                $enter.addClass('emphasis');
                if ( dataType !== undefined ) {
                    $enter.closest('.widget-body').find('.pie-chart-circle.circle-' + dataType ).css('stroke-width', strokeWidth * 1.2 );
                }
                },
                'mouseleave': function(){
                const $leave = $( this ),
                        dataType = $leave.attr('data-type');
                $leave.removeClass('emphasis');
                if ( dataType !== undefined ) {
                    $leave.closest('.widget-body').find('.pie-chart-circle.circle-' + dataType ).css('stroke-width', strokeWidth );
                }
                }
            });
            }        
        }
    });
}

}
class WidgetReserveList extends WidgetCommon {
/*
##################################################
    Widget
##################################################
*/
widget() {
    const wg = this;
    
    wg.$.widget = $( wg.widgetHtml( getMessage.FTE08081( wg.data.period ) ) );
    wg.$.widget.find('.widget-body').html( wg.body() );
    
    return wg.$.widget;
}
/*
##################################################
    Body
##################################################
*/
body() {
    const wg = this;
    
    wg.stopCountDown();
    
    let tableHTML = '';
    
    const dataSet = {
        conductor: {
            name: 'conductor_name',
            menu: 'conductor_confirmation',
            rest: 'conductor_instance_id'
        }
    };
    
    const today = new Date();
    for ( const type in wg.infoData ) {
        tableHTML += `<div class="db-reserve"><div class="db-reserve-inner">`;
        
        const tableArray = [];
        for ( const reserve of wg.infoData[ type ] ) {
            for ( const id in reserve ) {
                const date = new Date( reserve[id].time_book ),
                        diff = ( date - today ) / 86400000;
                if ( wg.data.period >= diff ) {
                    const link = fn.createPageUrl( dataSet[ type ].menu, {
                        [dataSet[ type ].rest]: id
                    });
                    tableArray.push({
                        id: id,
                        name: reserve[id][ dataSet[ type ].name ],
                        operation_name: reserve[id].operation_name,
                        status: reserve[id].status,
                        time_book: reserve[id].time_book,
                        link: link
                    });
                }
            }
        }
        
        if ( tableArray.length > 0 ) {
            tableArray.sort(function( a, b ){
                if ( a.time_book > b.time_book ) {
                    return 1;          
                } else if ( a.time_book < b.time_book ) {
                    return -1;
                } else {
                    return 0;
                }
            });

            // header
            tableHTML += ``
            + `<table class="db-reserve-table db-table">`
                + `<thead class="db-reserve-thead">`
                    + `<tr class="db-reserve-tr db-tr">`
                        + `<th class="db-reserve-th db-cell db-cell-text tHeadTh"><div class="db-cell-i">${getMessage.FTE08059}</div></th>`
                        + `<th class="db-reserve-th db-cell db-cell-text tHeadTh"><div class="db-cell-i">${getMessage.FTE08033}</div></th>`
                        + `<th class="db-reserve-th db-cell tHeadTh db-cell-min"><div class="db-cell-i">${getMessage.FTE08034}</div></th>`
                        + `<th class="db-reserve-th db-cell tHeadTh db-cell-min"><div class="db-cell-i">${getMessage.FTE08035}</div></th>`
                        + `<th class="db-reserve-th db-cell tHeadTh db-cell-min"><div class="db-cell-i">${getMessage.FTE08036}</div></th>`
                    + `</tr>`
                + `</thead>`
                + `<tbody>`;
            
            for ( const item of tableArray ) {
                const date = fn.date( item.time_book, 'yyyy/MM/dd HH:mm').replace(' ', '<br>');
                tableHTML += ``
                + `<tr class="db-reserve-tr db-tr">`
                    + `<td class="db-reserve-td db-cell"><div class="db-cell-i">`
                        + wg.linkHtml('db-reserve-link db-cell-l', item.link, fn.cv( item.name, '', true ), wg.data.page_move )
                    + `</div></td>`
                    + `<td class="db-reserve-td db-cell"><div class="db-cell-i">${fn.cv( item.operation_name, '', true )}</div></td>`
                    + `<td class="db-reserve-td db-cell db-cell-min"><div class="db-cell-i">`
                        + `<div class="db-reserve-status"><span class="db-reserve-status-icon"></span>${fn.cv( item.status, '', true )}</div>`
                    + `</div></td>`
                    + `<td class="db-reserve-td db-cell db-cell-min"><div class="db-cell-i">${date}</div></td>`
                    + `<td class="db-reserve-td db-cell db-cell-min"><div class="db-cell-i">`
                        + `<div class="db-reserve-count-down" data-date="${item.time_book}"></div>`
                    + `</div></td>`
                + `</tr>`;
            }
            tableHTML += `</tbody></table>`;
        } else {
            tableHTML += `<div class="db-reserve-message">${getMessage.FTE08087( wg.data.period )}</div>`;
        }
        
        tableHTML += `</div></div>`;
    }
    
    return tableHTML;
}
/*
##################################################
    Ready
##################################################
*/
ready() {
    const wg = this;
    
    wg.countDown();
}
/*
##################################################
    カウントダウン
##################################################
*/
countDown() {
    const wg = this;
    
    const countDown = function() {
        const today = new Date();
        wg.$.widget.find('.db-reserve-count-down').each(function(){
            const $date = $( this ),
                    date = new Date( $date.attr('data-date') ),
                    diff = date - today;

            const day = ( diff >= 0 )? Math.floor( diff / (24 * 60 * 60 * 1000) ): 0,
                    hour = ( diff >= 0 )? Math.floor(( diff % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000)): 0,
                    min = ( diff >= 0 )? Math.floor(( diff % (24 * 60 * 60 * 1000)) / (60 * 1000)) % 60: 0;

            const html = ``
            + `<span class="db-reserve-cd">${fn.zeroPadding( day, 3, true )}</span>${getMessage.FTE08037}`
            + `<span class="db-reserve-cd">${fn.zeroPadding( hour, 2, true )}</span>${getMessage.FTE08038}`
            + `<span class="db-reserve-cd">${fn.zeroPadding( min, 2, true )}</span>${getMessage.FTE08039}`;

            if ( diff <= 0 ) {
                $date.addClass('running').removeClass('shortly');
            } else if ( day == 0 ) {
                $date.addClass('shortly');
            }

            $date.html( html );
        });
    };
    
    wg.widgetTimerId = setInterval( countDown, 60000 );
    countDown();
}
/*
##################################################
    カウントダウン停止
##################################################
*/
stopCountDown() {
    const wg = this;
    
    if ( wg.widgetTimerId !== false ) {
        clearInterval( wg.widgetTimerId );
        wg.widgetTimerId = false;
    }
}

}
class WidgetStackedGraph extends WidgetCommon {
/*
##################################################
    Widget
##################################################
*/
widget() {
    const wg = this;
    
    // 表示期間
    const today = new Date(),
            targetDay = new Date().setDate( today.getDate() - wg.data.period + 1 ),
            note = getMessage.FTE08080( fn.date( targetDay, 'yyyy/MM/dd'), fn.date( today, 'yyyy/MM/dd') );
    
    wg.$.widget = $( wg.widgetHtml( note ) );
    wg.$.widget.find('.widget-body').html( wg.body() );
    
    return wg.$.widget;
}
/*
##################################################
    作業履歴（work_result）データ変換
##################################################
*/
workHistory( data ) {
    const wg = this;
    
    const workHistory = {};
    
    // 凡例
    // [ name, 表示名, リンク先, 背景カラー ]
    const href = fn.createPageUrl('conductor_list');
    workHistory.usage = [
        ['sum', getMessage.FTE08067, href, 'transparent'],
        ['done', getMessage.FTE08068, href, '#91D21E'],
        ['fail', getMessage.FTE08069, href,'#8227B4'],
        ['warning', getMessage.FTE08070, href,'#FFB400'],
        ['stop', getMessage.FTE08071, href,'#FFDC00'],
        ['cancel', getMessage.FTE08072, href,'#FF69A3'],
        ['error', getMessage.FTE08073, href,'#E60000']
    ];
    
    // 縦軸・横軸名称
    workHistory.unit = [ getMessage.FTE08074, getMessage.FTE08075 ];
    
    // 項目名称
    workHistory.item = [];
    
    // グラフデータ
    workHistory.data = [];
    
    const period = wg.data.period,
            date = new Date(),
            today = new Date( new Date().toDateString() );

    // 履歴配列初期化
    for ( let i = 0; i < period; i++ ) {
        workHistory.item.push([ fn.date( date, 'yyyy/MM/dd'), date.getDate() ]);
        workHistory.data.push([ 0, 0, 0, 0, 0, 0, 0 ]);
        date.setDate( date.getDate() - 1 );
    }

    // ダミーデータ作成
    /*
    data.conductor = [];

    const test = new Date();
    const testA = ["正常終了","異常終了","警告終了","緊急停止", "予約取消","想定外エラー"];
    for ( let i = 0; i < 480; i++ ) {
        data.conductor[i] = {};
        data.conductor[i][i] = {
            end: fn.date( test.setHours( test.getHours() + 1 ), 'yyyy/MM/dd HH:mm:ss'),
            menu_name_rest: "conductor_list",
            status: testA[ Math.floor(Math.random() * 6 )]
        }
    }
    */

    // 日別にカウントする
    for ( const type in data ) {
        for ( const num in data[ type ] ) {
            for ( const id in data[ type ][ num ] ) {
                const result = data[ type ][ num ][ id ],
                        status = result.status,
                        targetDay = new Date( new Date( result.end ).toDateString() ),
                        diff = Math.round( ( today.getTime() - targetDay.getTime() ) / 86400000 );

                const usage = workHistory.usage.findIndex(function( item ){
                    return item[1] === status;
                });

                if ( diff < period ) {
                    workHistory.data[ diff ][ usage ]++;
                }
            }
        }
    }

    return workHistory;
}
/*
##################################################
    Stacked graph
##################################################
*/
body() {
    const wg = this;
    
    const widgetID = wg.id;
    
    // グラフデータ変換
    switch ( wg.data.widget_name ) {
        case 'workHistory': wg.stackedGraphData = wg.workHistory( wg.infoData ); break;
        default: wg.stackedGraphData = wg.infoData;
    }
    const stackedGraphData = wg.stackedGraphData;

    let sgHTML = '<div class="stacked-graph">';
    
    // 凡例と縦軸単位
    sgHTML += ``
    + `<div class="stacked-graph-header">`
        + `<div class="stacked-graph-vertica-unit">${stackedGraphData.unit[0]}</div>`
        + `<div class="stacked-graph-usage">`
            + `<ul class="stacked-graph-usage-list">`;
    
    const usageLength = stackedGraphData.usage.length;
    for ( let i = 1; i < usageLength; i++ ) {
        sgHTML += ``
        + `<li class="stacked-graph-usage-item">`
            + `<span class="db-usage" style="background-color:${stackedGraphData.usage[i][3]}"></span>`
            + stackedGraphData.usage[i][1]
        + `</li>`;
    }
    
    sgHTML += '</ul>'
        + '</div>'
    + '</div>';
    
    // 合計値と最大値
    let sgMax = 0;
    
    const sgLength = stackedGraphData.data.length
    for ( let i = 0; i < sgLength; i++ ) {
        const itemLength = stackedGraphData.data[i].length;
        for ( let j = 1; j < itemLength; j++ ) {
            stackedGraphData.data[i][0] += stackedGraphData.data[i][j];
        }
        if ( stackedGraphData.data[i][0] > sgMax ) sgMax = stackedGraphData.data[i][0];
    }
    
    // グラフ縦軸
    const digit = String( sgMax ).length, // 桁数
            digitNumber = Math.pow( 5, digit - 1 ), // 縦軸の数
            graphMaxNumber = Math.ceil( sgMax / digitNumber ) * digitNumber; // グラフ最大値
    
    sgHTML += ``
    + `<div class="stacked-graph-body">`
        + `<ol class="stacked-graph-vertical-axis">`;
    
    const verticalAxisLength = graphMaxNumber / digitNumber;
    for( let i = 0; i <= verticalAxisLength; i++ ) {
        sgHTML += `<li class="stacked-graph-vertical-axis-item">${ i * digitNumber }</li>`;
    }
    sgHTML += `</ol>`;

    // グラフ本体
    sgHTML += `<ol class="stacked-graph-horizontal-axis">`;
    for ( let i = sgLength - 1; 0 <= i; i-- ) {
        const sum = stackedGraphData.data[i][0],
                sumPer = Math.round( sum / graphMaxNumber * 100 ),
                itemLength = stackedGraphData.data[i].length;

        sgHTML += ``
        + `<li class="stacked-graph-item">`
            + `<dl class="stacked-graph-item-inner" data-id="${i}">`
                + `<dt class="stacked-graph-item-title"><span class="day-number">${stackedGraphData.item[i][1]}</span></dt>`
                + `<dd class="stacked-graph-bar">`;

        if ( sum !== 0 ) {
            sgHTML += `<ul class="stacked-graph-bar-group" data-style="${sumPer}%">`;
            for ( let j = 1; j < itemLength; j++ ) {
                const itemPer = Math.round( stackedGraphData.data[i][j] / sum * 100 );
                sgHTML += `<li class="stacked-graph-bar-item stacked-graph-bar-${stackedGraphData.usage[j][0]}" style="height:${itemPer}%;background-color:${stackedGraphData.usage[j][3]}"></li>`;
            }
            sgHTML += '</ul>';
        }
        
        sgHTML += ``
                + `</dd>`
            + `</dl>`
        + `</li>`;
    }
    
    sgHTML += '</ol></div>';
    
    // 横軸単位
    sgHTML += ``
    + `<div class="stacked-graph-footer">`
        + `<div class="stacked-graph-horizontal-unit">${stackedGraphData.unit[1]}</div>`
    + '</div>'
    + `</div></div><div class="stacked-graph-popup"></div></div>`;
    
    return sgHTML;
}
/*
##################################################
    準備完了時
##################################################
*/
ready() {
    const wg = this;
    
    wg.$.widget.find('.stacked-graph-bar-group').each( function(){
        const $bar = $( this );
        $bar.attr('style', 'height:' + $bar.attr('data-style') );
    });
    wg.setDetaileEvent();
}
/*
##################################################
    詳細表示イベント
##################################################
*/
setDetaileEvent() {
    const wg = this;
    wg.$.widget.find('.stacked-graph-item-inner').on({
        'mouseenter.detaile': function() {
            const $bar = $( this ),
                    $window = $( window ),
                    $pop = wg.$.widget.find('.stacked-graph-popup'),
                    dataID = Number( $bar.attr('data-id') ),
                    resultData = wg.stackedGraphData.data[ dataID ],
                    resultLength = resultData.length,
                    usage = wg.stackedGraphData.usage,
                    item =  wg.stackedGraphData.item,
                    total = wg.stackedGraphData.data[ dataID ][ 0 ];
            
            const resultRow = function( date, color, text, url, number, sumFlag = false ){
                // filter
                const filter = {
                    last_update_date_time: {
                        RANGE: {
                            START: `${date} 00:00:00`,
                            END: `${date} 23:59:59`
                        }
                    }
                };
                // 計は全て
                if ( sumFlag ) {
                    const itemList = [];
                    for ( const u of usage ) {
                        if ( u[0] !== 'sum') itemList.push( u[1] );
                    }
                    filter.status_id = {
                        LIST: itemList
                    }
                } else {
                    filter.status_id = {
                        LIST: text
                    }
                }
                
                const numHtml = ( number !== 0 )?
                    wg.linkHtml('db-cell-l db-cell-ln', `${url}&filter=${fn.filterEncode( filter )}`, number, wg.data.page_move ):
                    `<span class="db-cell-z">0</span>`;
            
                return ''
                + '<tr class="db-row">'
                    + '<th class="db-cell"><div class="db-cell-i">'
                    + '<span class="db-usage" style="background-color:' + color + '"></span>' + text
                    + '</div></th>'
                    + '<td class="db-cell"><div class="db-cell-i"">'
                    + numHtml
                    + '</div></td></tr>';
            };
            
            let beforeTitle;
            const setResult = function(){
                // Table
                const title = item[ dataID ][ 0 ];

                // タイトルが同じなら更新しない
                if ( title === beforeTitle ) return;
                beforeTitle = title;

                let tableHTML = '<div class="stacked-graph-popup-inner">'
                    + '<div class="stacked-graph-popup-close">' + fn.html.icon('cross') + '</div>'
                    + '<div class="stacked-graph-popup-date">' + title + '</div>'
                    + '<div class="db-table-wrap"><table class="db-table"><tbody>';

                for ( let i = 1; i < resultLength; i++ ) {
                    tableHTML += resultRow( title, usage[i][3], usage[i][1], usage[i][2], resultData[i] );
                }
                tableHTML += resultRow( title, usage[0][3], usage[0][1], usage[0][2], resultData[0], true );

                tableHTML += '</tbody></table></div></div>';
                $pop.html( tableHTML );
                $pop.find('.stacked-graph-popup-close').on('click', function(){
                    $pop.removeClass('fixed').html('').hide();
                });
            };
            
            const setPopPosition = function( pageX, pageY ) {
                const scrollTop = $window.scrollTop(),
                        scrollLeft = $window.scrollLeft(),
                        windowWidth = $window.width(),
                        popupWidth = $pop.outerWidth();

                let leftPosition = pageX - scrollLeft;

                // 右側チェック
                if ( leftPosition + ( popupWidth / 2 ) > windowWidth ) {
                    leftPosition = leftPosition - (( leftPosition + ( popupWidth / 2 ) ) - windowWidth );
                }
                // 左側チェック
                if ( leftPosition - ( popupWidth / 2 ) < 0 ) {
                    leftPosition = popupWidth / 2;
                }

                $pop.show().css({
                    'left': leftPosition,
                    'top': pageY - scrollTop - 8
                });
            };

            // 上側の位置のチェック
            const positionCheck = function( e ) {
                const $target = $( e.target ).closest('.stacked-graph-item');
                if ( $target.length ) {
                    const
                    $group = $target.find('.stacked-graph-bar-group'),
                    $title = $target.find('.stacked-graph-item-title');
                    
                    let y = 0;
                    if ( $group.length ) {
                        y = $group.offset().top;
                    } else {
                        y = $title.offset().top;
                    }
                    
                    setResult();

                    // 上にはみ出ているか？
                    const headerHeight = $('#header').outerHeight();
                    const popupHeight = $pop.outerHeight();

                    if ( y - popupHeight - headerHeight - 16 < 0 ) {
                        y = $title.offset().top + popupHeight + 24;
                    }
                    setPopPosition( e.pageX, y );
                    
                }
            }

            $bar.on('click.stackedGraphPopup', function( e ){
                positionCheck( e );
                $pop.toggleClass('fixed');
            });

            $window.on('mousemove.stackedGraphPopup', function( e ) {
                if ( !$pop.is('.fixed') ) positionCheck( e );
            });
        },
        'mouseleave.detaile': function() {
            wg.$.widget.find('.stacked-graph-popup').not('.fixed').html('').hide();
            $( this ).off('click.stackedGraphPopup');
            $( window ).off('mousemove.stackedGraphPopup');
        }
        
    });
}

}