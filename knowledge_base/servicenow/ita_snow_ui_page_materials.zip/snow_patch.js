////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   common.js fn functions patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
/*
##################################################
    共通パラメーター
##################################################
*/
fn.getCommonParams = () => {
    return {
        path: fn.getPathname(),
        organizationId : conf.orgId,
        workspaceId: conf.wsId
    };
},
/*
##################################################
    ファイル名から拡張子を取得
##################################################
*/
fn.getExt = (filename) => {
    const i = filename.lastIndexOf('.');
    return i > 0 ? filename.slice(i + 1) : '';
}
/*
##################################################
    API endpoint
##################################################
*/
fn.getRestApiUrl = ( url, type = 'ita') => {
    return `/api/${conf.orgId}/workspaces/${conf.wsId}/${type}${url}`;
}
/*
##################################################
   script, styleの読み込み
##################################################
*/
fn.loadAssets = ( assets ) => {
    const f = function( type, url, id, webAssetsUrl = true ){
        return new Promise(function( resolve, reject ){
            type = ( type === 'css')? 'link': 'script';
            if ( webAssetsUrl ) {
                url = url + '?v=' + fn.getUiVersion();
            }

            const body = document.getElementById('container'),
                  asset = document.createElement( type );

            switch ( type ) {
                case 'script':
                    if ( webAssetsUrl ) {
                        asset.src = conf.webAssetsUrl + url;
                    } else {
                        asset.src = url;
                    }
                    if ( id ) asset.id = id;
                break;
                case 'link':
                    if ( webAssetsUrl ) {
                        asset.href = conf.webAssetsUrl + url;
                    } else {
                        asset.href = url;
                    }
                    asset.rel = 'stylesheet';
                    if ( id ) asset.id = id;
                break;
            }

            body.appendChild( asset );

            asset.onload = function() {
                resolve();
            };

            asset.onerror = function( e ) {
                reject( e )
            };
        });
    };
    if ( fn.typeof( assets ) === 'array') {
        return Promise.all(
            assets.map(function( asset ){
                return f( asset.type, asset.url, asset.id, asset.webAssetsUrl );
            })
        );
    } else {
        return f( assets.type, assets.url, assets.id );
    }
},
/*
##################################################
    fetch
##################################################
*/
fn.fetch = ( url, token, method = 'GET', data, option = {}, ignoreError=false, ignoreErrorCount=0 ) => {
    let errorCount = 0;

    // エラー無視回数の上限設定
    const ignoreErrorLimit = 120;

    const f = async ( u ) => {
        u = fn.getRestApiUrl( u, option.apiType );
        const itaInit = {
            method: method,
            path: u
        };
        // body
        if ( ( method === 'POST' || method === 'PATCH' ) && data !== undefined ) {
            itaInit.body = data;
        }
        // ServiceNow スクリプト済み REST リソース
        const path = conf.apiPath;
        const init = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-UserToken': window.g_ck
            },
            body: JSON.stringify( itaInit )
        };
        if ( option.controller ) {
            init.signal = option.controller.signal;
        }
        try {
            const response = await fetch( path, init );
            if ( errorCount === 0 ) {
                if ( response.ok ) {
                    try {
                        const json = await response.json();
                        const result = json.result || {};
                        if ( option.message ) {
                            return [ result.data, result.message ];
                        } else {
                            return result.data;
                        }
                    } catch ( error ) {
                        throw error;
                    }
                } else {
                    errorCount++;
                    if ( response.status == 500 && ignoreError == true && ignoreErrorCount < ignoreErrorLimit ) { // エラーを無視
                        return {errorIgnored: true};
                    }
                    try {
                        const json = await response.json();
                        const result = json.result || {};
                        return Promise.reject( await fn.responseError( response.status, result, null, option ) );
                    } catch ( error ) {
                        fn.systemErrorAlert();
                        throw error;
                    }
                }
            } else {
                return null;
            }
        } catch ( error ) {
            if ( error.name !== 'AbortError') {
                console.error( error );
                if ( errorCount === 0 ) {
                    throw error;
                }
            } else {
                return null;
            }
        }
    };
    if ( fn.typeof( url ) === 'array') {
        return Promise.all(
            url.map(function( u ){
                return f( u );
            })
        );
    } else if ( fn.typeof( url ) === 'string') {
        return f( url );
    }
}
/*
##################################################
   データ登録（進捗表示）
##################################################
*/
fn.xhr = function( url, data ) {
    return new Promise(function( resolve, reject ){
        let progressModal = fn.progressModal( getMessage.FTE00184, { close: true });

        // 閉じたときに処理を中断する
        progressModal.btnFn = {
            headerClose: function(){
                ajax.abort();
                progressModal.close();
                progressModal = null;
                reject('break');
            }
        };

        const token = CommonAuth.getToken();

        url = fn.getRestApiUrl( url );
        
        const itaInit = {
            headers: {'Content-Type': 'application/json'},
            method: 'POST',
            path: url,
            body: data
        };
        console.log(itaInit);

        const progress = function( e ) {
            progressModal.progress( e.loaded, e.total );
        };

        const ajax = $.ajax({
            url: conf.apiPath,
            method: 'POST',
            dataType: 'json',
            data: JSON.stringify( itaInit ),
            contentType: 'application/json; charset=utf-8',
            headers: {
                'Accept': 'application/json',
                'X-UserToken': token
            },
            async: true,
            xhr: function() {
                const xhr = $.ajaxSettings.xhr();
                xhr.upload.addEventListener('progress', progress );
                return xhr;
            }
        }).done(function( json, status, jqXHR ){
            if ( status === 'success') {
                progressModal.close();
                progressModal = null;
                const result = json.result || {};
                resolve( result.data, progressModal );
            } else {
                reject( null );
            }
        }).fail(function( jqXHR ){
            if ( jqXHR.statusText !== 'abort') {
                setTimeout(function(){
                    fn.responseError( jqXHR.status, jqXHR.responseJSON, null, { dataRegistrationFlag: true }).then(function( json ){
                        progressModal.close();
                        progressModal = null;
                        const result = json.result || {};
                        reject( result );
                    });
                }, 200 );
            }
        });
    });
}
/*
##################################################
   ファイルの取得
##################################################
*/
fn.getFile = function( endPoint, method = 'GET', data, option = {} ) {
    return new Promise( async function( resolve, reject ){
        try {
            const getFileController = new AbortController();
            const title = ( option.title )? option.title: getMessage.FTE00180;
            let progressModal = fn.progressModal( title, { close: true });

            // 閉じたときに処理を中断する
            progressModal.btnFn = {
                headerClose: function(){
                    $( window ).trigger('getFile_close');
                    getFileController.abort();
                    progressModal.close();
                    progressModal = null;
                    reject('break');
                }
            };
        
            // ITA用
            const itaInit = {
                method: method,
                path: fn.getRestApiUrl( endPoint ),
                mode: 'upstream',
                ext: option.ext || ''
            };
            if ( data ) {
                itaInit.body = data;
            }
            
            const init = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-UserToken': window.g_ck
                },
                body: JSON.stringify( itaInit ),
                signal: getFileController.signal
            };

            // データ読込開始
            const response = await fetch(conf.apiPath, init );

            if ( response.ok ) {
                // 成功
                const reader = response.body.getReader();
                const contentLength = response.headers.get('X-File-Size');

                // ファイル名
                const disposition = response.headers.get('Content-Disposition');
                let fileName = 'noname';
                if ( disposition && disposition.indexOf('attachment') !== -1 ) {
                    const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                    const matches = filenameRegex.exec( disposition );
                    if ( matches != null && matches[1] ) {
                        fileName = decodeURIComponent(matches[1].replace(/['"]/g, ''));
                    }
                }

                // オリジンプライベートファイルシステム（OPFS）が使えるかで処理を分岐する
                let fileData;
                // データ読込
                const chunks = [];
                let receivedLength = 0;
                while( true ) {
                    const { done, value } = await reader.read();
                    if ( done === true ) {
                        break;
                    } else {
                        chunks.push( value );
                        receivedLength += value.length;
                        progressModal.progress( receivedLength, contentLength );
                    }
                }
                // ファイルに変換
                const blob = new Blob( chunks );
                fileData = new File([blob], fileName, { type: blob.type });

                // option.fileType === json の場合はレスポンスのdata部分のみをjsonで返す
                if ( option.fileType === 'json') {
                    const jsonText = await fn.fileToText( fileData );
                    const json = fn.jsonParse( jsonText );
                    fileData = json.data;
                }

                // バーのtransition-duration: .2s;分ずらす
                setTimeout(function(){
                    if ( progressModal !== null ) {
                        progressModal.close();
                        progressModal = null;
                        if ( option.fileName ) {
                            resolve({
                                file: fileData,
                                fileName: fileName
                            });
                        } else {
                            resolve( fileData );
                        }
                    }
                }, 200 );
            } else {
                // 失敗
                response.json().then(function( json ){
                    fn.responseError( response.status, json ).then(function( result ){
                        progressModal.close();
                        progressModal = null;
                        reject( result );
                    });
                }).catch(function( error ){
                    fn.systemErrorAlert();
                });
            }
        } catch ( e ) {
            if ( e.message === 'network error') {
                reject('break');
            } else {
                reject( e );
            }
        }
    });
}
/*
##################################################
   エラーページへ移動
##################################################
*/
fn.gotoErrPage = function( message ) {
    // windowFlagでWorker内か判定
    if ( typeof window !== 'undefined') {
        if ( message !== 'Failed to fetch') {
            if ( message ) {
                window.alert( message );
            } else {
                window.alert('Unknown error.');
            }
            if ( confirm('Do you want to go to the top page?') ) {
                fn.goToPage( null );
            }
        }
    } else {
        if ( message ) {
            console.error( message );
        } else {
            console.error('Unknown error.');
        }
    }
}
/*
##################################################
   リンクURL作成
##################################################
*/
fn.createPageUrl = function( menu, option = {}) {
    if ( typeof window === 'undefined') return;

    const current = new URL( window.location.href );
    const params = current.searchParams;
    const basePath = current.pathname;
    const sysId = params.get('sys_id');

    const target = new URL( basePath, current.origin );
    target.searchParams.set('sys_id', sysId );
    if ( menu ) target.searchParams.set('menu', menu );

    for ( const key in option ) {
        target.searchParams.set( key, option[ key ] );
    }
    return target.href;
}
/*
##################################################
   ページ移動
##################################################
*/
fn.goToPage = function( menu, option = {}) {
    const url = fn.createPageUrl( menu, option );
    window.location.assign( url );
}
/*
##################################################
   ファイルエディター
##################################################
*/
fn.fileEditor = function( fileData, fileName, mode = 'edit', option = {} ) {
    return new Promise( function( resolve ){
        const fileType = fn.fileTypeCheck( fileName );
        let fileMode = fn.fileModeCheck( fileName );

        // モーダル設定
        const height = ( mode === 'edit' && fileType === false )? 'auto': '100%';
        const config = {
            position: 'center',
            width: '960px',
            height: height,
            header: {
                title: fn.cv( fileName, '', true ),
            },
            footer: {
                button: {}
            }
        };
        // モーダルボタン
        const funcs = {};

        // 編集モード
        if ( mode === 'edit') {
            config.footer.button.update = { text: getMessage.FTE00168, action: 'positive', width: '160px'};
        }

        config.footer.button.download = { text: getMessage.FTE00169, action: 'restore', width: '88px'};
        config.footer.button.close = { text: getMessage.FTE00170, action: 'normal', width: '88px'};
        funcs.close = function() {
            modal.close();
            modal = null;

            resolve( null );
        };

        const modeSelectList = {
            text: 'Text(txt)',
            yaml: 'YAML(yaml,yml)',
            terraform: 'Terraform(tf,hc,hcl,sentinel)',
            json: 'JSON(json)',
            python: 'Python(py,j2)'
        };

        const themeSelectList = {
            chrome: 'Bright',
            monokai: 'Dark'
        };

        const modalHtmlSelect = function() {
            let html = ``;

            const nameInputTr = `<tr class="commonInputTr">`
                + `<th class="commonInputTh">`
                    + `<div class="commonInputTitle">${getMessage.FTE00171}</div>`
                + `</th><td class="commonInputTd" colspan="3">`
                    + fn.html.inputText('editorFileName', '', 'editorFileName')
                + `</td>`
            + `</tr>`;

            const modeSelectTr = `<tr class="commonInputTr">`
                + `<th class="commonInputTh">`
                    + `<div class="commonInputTitle">${getMessage.FTE00172}</div>`
                + `</th><td class="commonInputTd">`
                    + fn.html.select( modeSelectList, 'editorModeSelect', '', 'editorModeSelect')
                + `</td>`
                + `<th class="commonInputTh">`
                    + `<div class="commonInputTitle">${getMessage.FTE00173}</div>`
                + `</th><td class="commonInputTd">`
                    + fn.html.select( themeSelectList, 'editorThemeSelect', '', 'editorThemeSelect')
                + `</td>`
            + `</tr>`;

            if ( mode === 'edit') {
                html += `<div class="editorHeader"><table class="commonInputTable">${nameInputTr}`;
                if ( fileType === 'text') {
                    html += modeSelectTr;
                }
                html += `</table></div>`;
            } else if ( fileType === 'text') {
                html += `<div class="editorHeader"><table class="commonInputTable">${modeSelectTr}</table></div>`;
            }

            if ( fileType === 'text') {
                html += `<div id="aceEditor" class="editorBody"></div>`;
            } else if ( fileType === 'image') {
                html += `<div class="editorImageBody editorBody"><img class="editorImage"></div>`;
            }
            return `<div class="fileEditor">${html}</div>`;
        };

        let modal = new Dialog( config, funcs );
        modal.open();

        if ( fileType === 'text') {
            if ( fileData === null ) fileData = '';
            fn.fileOrBase64ToText( fileData ).then(function( text ){
                modal.setBody( modalHtmlSelect() );
                if ( mode === 'edit') {
                    modal.$.dbody.find('.editorFileName').val( fileName );
                }
                modal.$.dbody.find('.editorBody').text( text );
                fn.removeDownloadTemp();

                // Ace editor
                const storageTheme = fn.storage.get('editorTheme', 'local', false ),
                      aceTheme = ( storageTheme )? storageTheme: ( $('body').is('.darkmode') )? 'monokai': 'chrome';

                const langTools = ace.require('ace/ext/language_tools');

                const aceEditor = ace.edit('aceEditor', {
                    theme: `ace/theme/${aceTheme}`,
                    mode: `ace/mode/${fileMode}`,
                    displayIndentGuides: true,
                    fontSize: '14px',
                    minLines: 2,
                    showPrintMargin: false,
                    readOnly: ( mode !== 'edit' ),
                    wrapBehavioursEnabled: false,
                    enableBasicAutocompletion: true,
                    enableLiveAutocompletion: true
                });
                modal.$.dbody.find('.ace_scrollbar').addClass('commonScroll');

                // Ace editor mode
                modal.$.dbody.find('.editorModeSelect').val( modeSelectList[fileMode] ).on('change', function() {
                    const value = $( this ).val();
                    for ( const mode in modeSelectList ) {
                        if ( modeSelectList[ mode ] === value ) {
                            fileMode = mode;
                            aceEditor.session.setMode(`ace/mode/${mode}`);
                            break;
                        }
                    }
                });

                // Ace editor theme
                modal.$.dbody.find('.editorThemeSelect').val( themeSelectList[aceTheme] ).on('change', function() {
                    const value = $( this ).val();
                    for ( const theme in themeSelectList ) {
                        if ( themeSelectList[ theme ] === value ) {
                            aceEditor.setTheme(`ace/theme/${theme}`);
                            fn.storage.set('editorTheme', theme, 'local', false );
                            break;
                        }
                    }
                });

                // 端で折り返す
                aceEditor.session.setUseWrapMode( true );

                // ITA独自変数
                const menuName = fn.getParams().menu;
                if ( !fn.ignoreItaOriginalVariable.includes( menuName ) ) {
                    const rhymeCompleter = {
                        getCompletions: function( editor, session, pos, prefix, callback ) {
                            callback( null, fn.itaOriginalVariable().map(function( val ){
                                return { value: val, meta: getMessage.FTE00174 };
                            }));
                        }
                    };
                    langTools.addCompleter(rhymeCompleter);
                }

                // ダウンロード
                modal.btnFn.download = function() {
                    const value = aceEditor.getValue();

                    fn.base64Encode( value ).then(function( base64 ){
                        if ( mode === 'edit') {
                            fileName = modal.$.dbody.find('.editorFileName').val();
                        }
                        fn.download('base64', base64, fileName );
                    });
                };

                // 変更時
                aceEditor.session.on('change', function(){
                    // yamlチェック
                    if ( fileMode === 'yaml') {
                        const value = aceEditor.getValue(),
                              session = aceEditor.getSession();
                        try {
                            const result = jsyaml.load( value );
                            session.setAnnotations([]);
                        } catch( error ) {
                            session.setAnnotations([{
                                row: error.mark.line,
                                column: error.mark.column,
                                text: error.reason,
                                type: "error"
                            }]);
                        }
                    }
                });

                // 更新
                modal.btnFn.update = function() {
                    const value = aceEditor.getValue();

                    fileName = modal.$.dbody.find('.editorFileName').val();
                    modal.close();
                    modal = null;

                    resolve({
                        name: fileName,
                        file: fn.textToFile( value, fileName )
                    });
                };
            });
        } else if ( fileType === 'image') {
            if ( fileData === null ) fileData = '';
            fn.fileOrBase64ToBase64( fileData ).then(function( base64 ){
                // ダウンロード
                modal.btnFn.download = function() {
                    if ( mode === 'edit') {
                        fileName = modal.$.dbody.find('.editorFileName').val();
                    }
                    fn.download('base64', base64, fileName );
                };

                modal.setBody( modalHtmlSelect() );
                if ( mode === 'edit') {
                    modal.$.dbody.find('.editorFileName').val( fileName );

                    // 更新
                    modal.btnFn.update = function() {
                        fileName = modal.$.dbody.find('.editorFileName').val();
                        modal.close();
                        modal = null;

                        resolve({
                            name: fileName,
                            file: fn.base64ToFile( base64, fileName )
                        });
                    };
                }

                // imageの場合画像をセットする
                if ( fileType === 'image') {
                    const
                    mime = fn.imageMimeTypeCheck( fileName ),
                    src = `data:image/${mime};base64,${base64}`;

                    modal.$.dbody.find('.editorImage').attr('src', src );
                    fn.removeDownloadTemp();
                }
            });
        } else {
            // 編集不可ファイル
            // ファイル名のみ変更可能

            // ダウンロード
            modal.btnFn.download = async function() {
                if ( mode === 'edit') {
                    fileName = modal.$.dbody.find('.editorFileName').val();
                }
                if ( fileData !== null ) {
                    fn.download('file', fileData, fileName );
                } else {
                    try {
                        const file = await fn.getFile( option.endPoint, 'GET', null, { title: getMessage.FTE00185, ext: fn.getExt(fileName) } );
                        fn.download('file', file, fileName );
                    } catch ( e ) {
                        if ( e !== 'break') {
                            console.error( e );
                            alert( getMessage.FTE00179 );
                        }
                    }
                }
            };

            modal.setBody( modalHtmlSelect() );
            if ( mode === 'edit') {
                modal.$.dbody.find('.editorFileName').val( fileName );

                // 更新
                modal.btnFn.update = function() {
                    fileName = modal.$.dbody.find('.editorFileName').val();
                    modal.close();
                    modal = null;

                    resolve({
                        name: fileName,
                        file: fileData
                    });
                };
            }
        }
    });

}
/*
##################################################
  テーマセット
##################################################
*/
fn.setTheme = function( theme ) {
    const $theme = $('#thema');
    const $body = $('body');
    const src = conf.webAssetsUrl + `/_/ita/thema/${theme}.css`;
    $theme.attr('href', src );
    $body.attr('data-theme', theme );

    // ダークモード
    if ( theme === 'darkmode') {
        $body.addClass('darkmode');
    } else {
        $body.removeClass('darkmode');
    }
}
/*
##################################################
    データ読み込み エラー
##################################################
*/
fn.responseError = function( status, responseJson, fetchController, option = {}) {
    const windowFlag = ( typeof window !== 'undefined');
    const iframeFlag = windowFlag? ( window.parent !== window ): false;
    return new Promise(function( resolve, reject ){
        switch ( status ) {
            // 呼び出し元に返す
            case 498: // メンテナンス中
            case 499: // バリデーションエラー
                resolve( responseJson );
            break;
            // 権限無しの場合、トップページに戻す
            case 401:
                if ( option.authorityErrMove !== false ) {
                    if ( !iframeFlag ) {
                        if ( fetchController ) fetchController.abort();

                        if ( option.dataRegistrationFlag !== true ) {
                            if ( responseJson && responseJson.message ) {
                                alert( responseJson.message );
                            } else {
                                alert('401 Unauthorized');
                            }
                            fn.goToPage(null);
                        } else {
                            let message = getMessage.FTE00186( status );
                            if ( responseJson && responseJson.message ) {
                                message = message + '\n' + responseJson.message;
                            }
                            alert( message );
                            resolve( null );
                        }
                    } else {
                        const message = ( responseJson && responseJson.message )? responseJson.message: '';
                        fn.iframeMessage( message );
                        resolve( null );
                    }
                } else {
                    resolve( responseJson );
                }
            break;
            case 403:
                if ( !iframeFlag ) {
                    if ( fetchController ) fetchController.abort();

                    if ( option.dataRegistrationFlag !== true ) {
                        if ( responseJson && responseJson.message ) {
                            alert( responseJson.message );
                        } else {
                            alert('403 Forbidden');
                        }
                        fn.goToPage(null);
                    } else {
                        let message = getMessage.FTE00186( status );
                        if ( responseJson && responseJson.message ) {
                            message = message + '\n' + responseJson.message;
                        }
                        alert( message );
                        resolve( null );
                    }
                } else {
                    const message = ( responseJson && responseJson.message )? responseJson.message: '';
                    fn.iframeMessage( message );
                    reject();
                }
            break;
            // その他のエラー
            default:
                console.error( status );
                console.error( responseJson );
                if ( option.dataRegistrationFlag !== true ) {
                    fn.systemErrorAlert();
                    reject();
                } else {
                    status = fn.cv( status, 'Unknown');
                    alert( getMessage.FTE00186( status ) );
                    resolve( null );
                }
        }
    });
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   ui.js class CommonUi patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
/*
##################################################
    画面初期設定
##################################################
*/
CommonUi.prototype.init = function(){
    const ui = this;

    return new Promise(function( resolve ){

        // UIモード
        if ( window.parent === window ) {
            ui.$.container.addClass('windowMode');

            // サイドメニュー開閉チェック
            const sideMenu = fn.storage.get('sideMenuClose');
            if ( sideMenu === true ) {
                ui.$.container.addClass('menuClose');
            }

            // サイドメニューイベントのセット
            ui.setSideMenuEvents();

            // Session storageにデータがある場合は先に表示する
            ui.storageLang = fn.storage.get('lang', 'session');
            ui.storageMenuGroups = fn.storage.get('restMenuGroups', 'session');
            ui.storagePanel = fn.storage.get('restPanel', 'session');
            ui.storageUser = fn.storage.get('restUser', 'session');

            if ( ui.storageLang && ui.storageMenuGroups && ui.storagePanel && ui.storageUser ) {
                ui.lang = ui.storageLang;
                const uiVersion = fn.getUiVersion();
                const langAtt = (ui.lang === 'ja')? sysAtt.ja: sysAtt.en;
                import( langAtt ).then(function( module ){
                    if ( ui.lang === 'ja') {
                        getMessage = module.messageid_ja();
                    } else {
                        getMessage = module.messageid_en();
                    }
                    ui.rest.menuGroups = ui.storageMenuGroups;
                    ui.rest.panel = ui.storagePanel;
                    ui.rest.user = ui.storageUser;

                    ui.setSideMenu();
                    ui.maintenanceMode();
                    ui.headerMenu( false );

                    resolve();
                });
            } else {
                resolve();
            }

        } else {
            ui.$.container.addClass('iframeMode');

            const iframeMode = fn.getParams().iframeMode;
            if ( iframeMode ) {
                ui.$.container.attr('data-iframeMode', iframeMode );
            }
            resolve();
        }
    });
}
/*
##################################################
    UI set
##################################################
*/
CommonUi.prototype.setUi = function(){
    const ui = this;

    const set = function() {
        // iframeで読み込まれていないか？
        if ( window.parent === window ) {
            ui.mode = 'window';
            ui.getSideMenuData();
        } else {
            ui.mode = 'iframe';
        }
        ui.setMenu();
    }

    // 言語ファイル
    const $lang = $('#lang'),
            tmpLang = CommonAuth.getLanguage();
    if ( ui.lang !== tmpLang ) {
        fn.storage.set('lang', tmpLang, 'session');
        ui.lang = tmpLang;

        if ( $lang.length ) $('#lang').remove();
        const uiVersion = fn.getUiVersion();
        const langAtt = (ui.lang === 'ja')? sysAtt.ja: sysAtt.en;
        import( langAtt ).then(function( module ){
            if ( ui.lang === 'ja') {
                getMessage = module.messageid_ja();
            } else {
                getMessage = module.messageid_en();
            }

            if ( ui.storageUser ) ui.headerMenu( false );
            set();
        });
    } else {
        set();
    }
}
/*
##################################################
   User infomation
##################################################
*/
CommonUi.prototype.userInfo = function() {
    const mn = this;

    // ユーザ情報確認
    if ( !mn.rest.user ) return;

    const name = fn.cv( mn.rest.user.user_name, '', true ),
          id = fn.cv( mn.rest.user.user_id, '', true ),
          roles = fn.cv( mn.rest.user.roles, []);

    const roleList = [];
    for ( const role of roles ) {
        roleList.push(`<li class="headerMenuInfoRoleItem">`
            + role
        + `</li>`);
    }

    return `
    <button class="headerMenuButton">
        <span class="icon icon-user"></span>
        <span class="headerMenuButtonName"><span class="headerMenuButtonNameText">${name}</span></span>
    </button>
    <div class="headerMenuInfoContainer">
        <div class="headerMenuInfoBlock userInfo">
            <div class="headerMenuInfoBody">
                <div class="headerMenuInfoType">User</div>
                <div class="headerMenuInfoName">${name}</div>
                <div class="headerMenuInfoId">${id}</div>
                <span class="icon icon-user"></span>
            </div>
        </div>
        <!-- ロール -->
        <div class="headerMenuInfoBlock headerMenuInfoRole">
            <div class="headerMenuInfoTitle">${fn.html.icon('role')} ${getMessage.FTE10006}</div>
            <div class="headerMenuInfoBody">
                <ul class="headerMenuInfoRoleList">
                    ${roleList.join('')}
                </ul>
            </div>
        </div>
        <!-- 設定など -->
        <div class="headerMenuInfoBlock headerMenuInfoMenu">
            <div class="headerMenuInfoBody">
                <ul class="headerMenuInfoMenuList">
                    <li class="headerMenuInfoMenuItem">
                        ${fn.html.button( fn.html.icon('gear') + getMessage.FTE10061, ['headerMenuInfoMenuButton', 'itaButton'], { type: 'setting', action: 'default'})}
                    </li>
                    <li class="headerMenuInfoMenuItem">
                        ${fn.html.button( fn.html.icon('note') + getMessage.FTE10033, ['headerMenuInfoMenuButton', 'itaButton'], { type: 'version', action: 'default'})}
                    </li>
                </ul>
                <!--
                <ul class="headerMenuInfoMenuList">
                    <li class="headerMenuInfoMenuItem">
                        ${fn.html.button( fn.html.icon('logout') + getMessage.FTE10034, ['headerMenuInfoMenuButton', 'itaButton'], { type: 'logout', action: 'positive'})}
                    </li>
                </div>
                -->
            </div>
        </div>
    </div>`;
}
/*
##################################################
   Workspace infomation
##################################################
*/
CommonUi.prototype.workspaceInfo = function() {
    const mn = this;

    // ユーザ情報確認
    if ( !mn.rest.user ) return;

    const workspaces = fn.cv( mn.rest.user.workspaces, {}),
          workspaceId = mn.params.workspaceId,
          currentWorkspaceName = fn.cv( workspaces[workspaceId], '', true );

    const workspaceList = [];
    for ( const work in workspaces ) {
        const
        id = fn.escape( work ),
        name = fn.cv( workspaces[work], '', true),
        itemClassName = ( work === workspaceId )? "headerMenuInfoWorkspaceItem headerMenuInfoCurrent": "headerMenuInfoWorkspaceItem";
        workspaceList.push(`<li class="${itemClassName}">`
            + `<button class="headerMenuInfoWorkspaceButton" data-workspace="${id}">${name}</button>`
        + `</li>`);
    }

    return `
    <button class="headerMenuButton">
        <span class="icon icon-workspace"></span>
        <span class="headerMenuButtonName"><span class="headerMenuButtonNameText">${currentWorkspaceName}</span></span>
    </button>
    <div class="headerMenuInfoContainer">
        <div class="headerMenuInfoBlock workspaceInfo">
            <div class="headerMenuInfoBody">
                <div class="headerMenuInfoType">Workspace</div>
                <div class="headerMenuInfoName">${currentWorkspaceName}</div>
                <div class="headerMenuInfoId">${fn.escape( workspaceId )}</div>
                <span class="icon icon-workspace"></span>
            </div>
        </div>
        <!-- ワークスペース -->
        <!--<div class="headerMenuInfoBlock headerMenuInfoWorkspace">
            <div class="headerMenuInfoTitle">${fn.html.icon('workspace')} ${getMessage.FTE10005}</div>
            <div class="headerMenuInfoBody">
                <ul class="headerMenuInfoWorkspaceList">
                    ${workspaceList.join('')}
                </ul>
            </div>
        </div>-->
        <!-- 設定など -->
        <!--<div class="headerMenuInfoBlock headerMenuInfoMenu">
            <div class="headerMenuInfoBody">
                <ul class="headerMenuInfoMenuList">
                    <li class="headerMenuInfoMenuItem">
                        ${fn.html.button( fn.html.icon('menuList') + getMessage.FTE10062, ['headerMenuInfoMenuButton', 'itaButton'], { type: 'platform', action: 'positive'})}
                    </li>
                </div>
            </div>
        </div>-->
    </div>`;
}
/*
##################################################
    表示しているメニューリストの作成
##################################################
*/
CommonUi.prototype.menuMain = function() {
    const ui = this;

    if ( ui.params.menuNameRest && ui.currentMenuGroupList ) {
        const item = function( m, secondary ){
            const menuName = fn.cv( m.menu_name, '', true );
            const menuRest = fn.cv( m.menu_name_rest, '');
            const url = fn.createPageUrl( menuRest );
            const attr = [`href="${url}"`];
            const className = ['menuLink'];
            if ( secondary ) className.push('menuSecondaryLink');
            if ( menuRest === ui.params.menuNameRest ) {
                className.push('current');
                attr.push('tabindex="-1"');
                ui.currentPage = {
                    title: menuName,
                    name: menuRest
                };
                if ( secondary ) {
                    ui.currentSecondaryGroup = secondary;
                }
            }
            return `<li class="menuItem"><a class="${className.join(' ')}" ${attr.join(' ')}>${menuName}</a></li>`;
        };

        const list = function( menus, secondary ) {
            const htmlArray = [];
            for ( const menu of menus ) {
                if ( menu.menus ) {
                    // Secondary
                    const secondaryGroupName = fn.cv( menu.menu_group_name, '', true ),
                            secondaryGroupLink = fn.cv( menu.main_menu_rest, ''),
                            secondaryClassName = ['menuSecondaryToggleButton'],
                            listStyle = [],
                            menuID = fn.cv( menu.id, '');
                    if ( menu.secondary_open_flag ) {
                        secondaryClassName.push('open');
                        listStyle.push('display:block');
                    }
                    const secondaryHTML = ``
                    + `<li class="menuItem">`
                        + `<div class="menuSecondary">`
                            +`<button class="${secondaryClassName.join(' ')}" data-id="${menuID}">`
                                + `${secondaryGroupName}<span class="menuSecondaryToggleIcon"></span>`
                            + `</button>`
                            + `<ul class="menuList menuSecondaryList" style="${listStyle.join(';')}">`
                                + list( menu.menus, { title: secondaryGroupName, link: secondaryGroupLink })
                            + `</ul>`
                        + `</div>`
                    + `</li>`;
                    htmlArray.push( secondaryHTML );
                } else {
                    htmlArray.push( item( menu, secondary ) );
                }
            }
            return htmlArray.join('');
        };

        return ui.sideMenuBody( ui.currentGroup.title, null, list( ui.currentMenuGroupList.menus ), ui.currentGroup.panel, true, true );
    } else {
        // メインメニュー用リスト
        const url = fn.createPageUrl( null );
        const dashboard = `<li class="menuItem"><a class="menuLink current" href="${url}">DashBoard</a></li>`;
        ui.currentPage = {
            title: getMessage.FTE10001
        };
        return ui.sideMenuBody( ui.currentPage.title, null, dashboard );
    }
}
/*
##################################################
    Sub main list
##################################################
*/
CommonUi.prototype.menuSub = function( subMenuList ) {
    const ui = this;

    const item = function( m, secondary ){
        const menuName = fn.cv( m.menu_name, '', true );
        const menuRest = fn.cv( m.menu_name_rest, '');
        const url = fn.createPageUrl( menuRest );
        const attr = [`href="${url}"`];
        const className = ['menuLink'];
        if ( secondary ) className.push('menuSecondaryLink');
        return `<li class="menuItem"><a class="${className.join(' ')}" ${attr.join(' ')}>${menuName}</a></li>`;
    };

    const list = function( menus, secondary ) {
        const htmlArray = [];
        for ( const menu of menus ) {
            if ( menu.menus ) {
                // Secondary
                const secondaryGroupName = fn.cv( menu.menu_group_name, '', true ),
                        secondaryGroupLink = fn.cv( menu.main_menu_rest, ''),
                        secondaryClassName = ['menuSecondaryToggleButton'],
                        listStyle = [],
                        menuID = fn.cv( menu.id, '');
                if ( menu.secondary_open_flag ) {
                    secondaryClassName.push('open');
                    listStyle.push('display:block');
                }
                const secondaryHTML = ``
                + `<li class="menuItem">`
                    + `<div class="menuSecondary">`
                        +`<button class="${secondaryClassName.join(' ')}" data-id="${menuID}">`
                            + `${secondaryGroupName}<span class="menuSecondaryToggleIcon"></span>`
                        + `</button>`
                        + `<ul class="menuList menuSecondaryList" style="${listStyle.join(';')}">`
                            + list( menu.menus, { title: secondaryGroupName, link: secondaryGroupLink })
                        + `</ul>`
                    + `</div>`
                + `</li>`;
                htmlArray.push( secondaryHTML );
            } else {
                htmlArray.push( item( menu, secondary ) );
            }
        }
        return htmlArray.join('');
    };

    return list( subMenuList );
}
/*
##################################################
    Menu group
##################################################
*/
CommonUi.prototype.menuGroup = function() {
    const ui = this;

    const list = [],
            length = ui.menuGroupList.length;

    for ( let i = 0; i < length; i++ ) {
        const menuGroup = ui.menuGroupList[i];
        if ( menuGroup.parent_id === null ) {
            const url = fn.createPageUrl( menuGroup.main_menu_rest );
            const title = fn.cv( menuGroup.menu_group_name, '', true ),
                    id =  fn.cv( menuGroup.id, ''),
                    panel = ui.getPanelImage( title, null, ui.rest.panel[ id ] );
            list.push(`<li class="menuItem"><a class="menuGroupLink menuLink" data-id="${id}" data-num="${i}" href="${url}"><span class="menuGroupPanel">${panel}</span><span class="menuGroupTitle">${title}</span></a></li>`);
        }
    }

    return ui.sideMenuBody( getMessage.FTE10002, 'menuGroup', list.join(''));
}
/*
##################################################
    Topic path
##################################################
*/
CommonUi.prototype.topicPath = function() {
    const ui = this;
    const topics = [],
            title = [ ui.currentPage.title ];
    if ( ui.currentGroup.link ) {
        const top = fn.createPageUrl( null );
        const url = fn.createPageUrl( ui.currentGroup.link );
        topics.push({ href: top, title: getMessage.FTE10001 });
        topics.push({ href: url, title: ui.currentGroup.title });
        title.push( ui.currentGroup.title );
    }
    if ( ui.currentSecondaryGroup ) {
        const url = fn.createPageUrl( ui.currentSecondaryGroup.link );
        topics.push({ href: url, title: ui.currentSecondaryGroup.title });
        title.push( ui.currentSecondaryGroup.title );
    }

    const list = [];
    if ( topics.length ) {
        for ( const topic of topics ) {
            list.push(`<li class="topichPathItem"><a class="topichPathLink" href="${topic.href}">${topic.title}</a></li>`);
        }
        list.push(`<li class="topichPathItem"><span class="topichPathCurrent">${ui.currentPage.title}</span></li>`);
    } else {
        list.push(`<li class="topichPathItem"><span class="topichPathCurrent">${getMessage.FTE10001}</span></li>`);
    }

    const html = `
    <ol class="topichPathList">
        ${list.join('')}
    </ol>`;

    ui.$.header.find('.topicPath').html( html );

    title.push('Exastro IT Automation');
    document.title = title.join(' / ');
}
/*
##################################################
  パネルイメージを返す
##################################################
*/
CommonUi.prototype.getPanelImage = function( title, icon, panel ) {
    if ( icon ) {
        return `<span class="icon icon-${icon}"></span>`;
    } else {
        return ( fn.cv( panel, false ) )?
        `<img class="menuTitleIconImage" src="data:;base64,${panel}" alt="${title}">`:
        `<img class="menuTitleIconImage" src="${conf.webAssetsUrl}/_/ita/imgs/icon_default.png" alt="${title}">`;
    }
}
/*
##################################################
   バージョン確認
##################################################
*/
CommonUi.prototype.checkVersion = function( version ) {
    const driverList = [];
    for ( const item of version.installed_driver ) {
        driverList.push(`<li class="driverItem">${fn.html.icon('plus')} ${item}</li>`);
    }

    const versionHtml = `<div class="versionContainer">
        <div class="versionLogo"><img class="versionLogoImg" src="${conf.webAssetsUrl}/_/ita/imgs/logo.svg" alt="Exastro IT Automation"></div>
        <div class="versionNumber"><span class="versionNumberWrap">Version: ${version.version}</span></div>
        <div class="installedDriver">
            <div class="driverTitle">${getMessage.FTE10035}</div>
            <ul class="driverList">
                ${driverList.join('')}
            </ul>
        </div>
    </div>`;

    return new Promise( function( resolve ){
        fn.alert('Exastro IT Automation', versionHtml ).then(function(){
            resolve();
        });
    });
}
/*
##################################################
    作業状態確認メニュー
##################################################
*/
CommonUi.prototype.operationStatusMenu = function() {
    const mn = this;

    const contentTab = [
        { name: 'operationStatus', title: getMessage.FTE00080, type: 'blank' },
        { name: 'executeLog', title: getMessage.FTE00081, type: 'blank', view: false, className: 'executeLogTab'},
        { name: 'errorLog', title: getMessage.FTE00082, type: 'blank', view: false, className: 'errorLogTab' }
    ];

    const menuInfo = fn.cv( mn.info.menu_info.menu_info, '');

    mn.$.content.html( mn.commonContainer( mn.title, menuInfo, mn.contentTab( contentTab ) ) );
    mn.setCommonEvents();
    mn.contentTabEvent('#operationStatus');

    const assets = [
        { type: 'js', url: '/_/ita/js/operation_status.js'},
        { type: 'css', url: '/_/ita/css/conductor.css'},
    ];

    fn.loadAssets( assets ).then(function(){
        patch_operation_status();
        const id = fn.getParams().execution_no;
        fn.createCheckOperation( mn.params.menuNameRest, id );
        mn.onReady();
    });
}
/*
##################################################
    defaultMenu
##################################################
*/
CommonUi.prototype.defaultMenu = function( sheetType, dataType = 'n', fileFlag = true ) {
    const mn = this;

    const contentTab = [{ name: 'dataList', title: getMessage.FTE10008, type: 'blank' }];
    // 履歴タブ
    if ( mn.flag.history ) {
        contentTab.push({ name: 'changeHistory', title: getMessage.FTE10009, type: 'blank' });
    }
    if ( dataType === 'n') {
        contentTab.push({ name: 'dataDownload', title: getMessage.FTE10010 });
    }

    const menuInfo = fn.cv( mn.info.menu_info.menu_info, '', true );

    mn.$.content.html( mn.commonContainer( mn.title, menuInfo, mn.contentTab( contentTab ) ) );
    mn.contentTabEvent('#dataList');

    // 一覧
    const $dataList = mn.$.content.find('#dataList'),
          initSetFilter = fn.getParams().filter,
          option = { sheetType: sheetType, dataType: dataType, fileFlag: fileFlag };
    if ( initSetFilter !== undefined ) option.initSetFilter = initSetFilter;
    mn.mainTable = new DataTable('MT', 'view', mn.info, mn.params, option );
    $dataList.find('.sectionBody').html( mn.mainTable.setup() );

    // 履歴ボディ
    if ( mn.flag.history ) {
        const $history = mn.$.content.find('#changeHistory');
        mn.historyTable = new DataTable('HT', 'history', mn.info, mn.params );
        $history.find('.sectionBody').html( mn.historyTable.setup() );

        // 一覧 個別履歴ボタン
        mn.mainTable.$.container.on('click', '.tBodyRowMenuUi', function(){
            const $button = $( this ),
                  uuid = $button.attr('data-id');

            mn.contentTabOpen('#changeHistory');
            $history.find('.tableHistoryId').val( uuid ).trigger('input');

            mn.historyTable.$.header.find('.itaButton').prop('disabled', false );
            mn.historyTable.workStart('filter');
            mn.historyTable.workerPost('history', uuid );
        });
    }

    // 全件ダウンロード・ファイル一括登録
    if ( dataType === 'n') {
        const $download = mn.$.content.find('#dataDownload');
        $download.find('.operationButton').on('click', function(){
            const $button = $( this ),
                type = $button.attr('data-type');

            // File name
            let fileName = '';

            if ( mn.currentGroup && mn.currentGroup.title ) {
                if ( mn.currentGroup.title.length > 64 ) {
                    fileName += mn.currentGroup.title.slice( 0, 61 ) + '..._';
                } else {
                    fileName += mn.currentGroup.title + '_';
                }
            }

            if ( mn.title && mn.title.length > 64 ) {
                fileName += mn.title.slice( 0, 61 ) + '..._';
            } else {
                fileName += mn.title + '_';
            }

            const downloadFile = async function( type, url, fileName ){
                $button.prop('disabled', true );
                try {
                    const ext = ( type !== 'json')? 'xlsx': 'json';
                    const file = await fn.getFile( url, 'GET', null, { title: getMessage.FTE00185, fileType: type, ext: ext });
                    if ( type !== 'json') type = 'file';
                    fn.download( type, file, fileName );
                } catch ( error ) {
                    if ( error !== 'break') {
                        fn.gotoErrPage( error.message );
                    }
                }
                fn.disabledTimer( $button, false, 1000 );
            };

            switch ( type ) {
                case 'allDwonloadExcel': {
                    $button.prop('disabled', true );

                    fn.fetch(`/menu/${mn.params.menuNameRest}/filter/count/`).then(function( result ){
                        const limit = mn.info.menu_info.xls_print_limit;
                        if ( limit && mn.info.menu_info.xls_print_limit < result ) {
                            alert( getMessage.FTE00085( result, limit) );
                        } else {
                            downloadFile('excel', `/menu/${mn.params.menuNameRest}/excel/?file=binary`, fileName + 'all.xlsx');
                        }
                    }).catch(function( error ){
                        fn.gotoErrPage( error.message );
                    }).then(function(){
                        fn.disabledTimer( $button, false, 1000 );
                    });
                } break;
                case 'allDwonloadJson':
                    if ( window.confirm( getMessage.FTE00181 ) ) {
                        downloadFile('json', `/menu/${mn.params.menuNameRest}/filter/`, fileName + 'all.json');
                    }
                break;
                case 'allDwonloadJsonNoFile':
                    downloadFile('json', `/menu/${mn.params.menuNameRest}/filter/?file=no`, fileName + 'all.json');
                break;
                case 'newDwonloadExcel':
                    downloadFile('excel', `/menu/${mn.params.menuNameRest}/excel/format/?file=binary`, fileName + 'format.xlsx');
                break;
                case 'excelUpload':
                    mn.fileRegister( $button, 'excel');
                break;
                case 'jsonUpload':
                    mn.fileRegister( $button, 'json');
                break;
                case 'allHistoryDwonloadExcel':
                    downloadFile('excel', `/menu/${mn.params.menuNameRest}/excel/journal/?file=binary`, fileName + 'journal.xlsx');
                break;
            }
        });
    }

    mn.setCommonEvents();
    mn.onReady();
}
/*
##################################################
   ファイル一括登録
##################################################
*/
CommonUi.prototype.fileRegister = async function( $button, type ) {
    const mn = this;

    const fileType = ( type === 'excel')? 'file': 'json',
          fileMime = ( type === 'excel')? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'application/json',
          restUrl = ( type === 'excel')? `excel/maintenance/`: `maintenance/all/`;

    // ボタンを無効
    $button.prop('disabled', true );

    // ファイル選択
    fn.fileSelect( fileType, null, fileMime ).then(async function( selectFile ){

        // 登録するか確認する
        const buttons = {
            ok: { text: getMessage.FTE10025, action: 'positive'},
            cancel: { text: getMessage.FTE10026, action: 'normal'}
        };

        const table = { tbody: []};
        table.tbody.push([ getMessage.FTE10027, selectFile.name ]);
        table.tbody.push([ getMessage.FTE10028, selectFile.size.toLocaleString() + ' byte']);

        let postData;
        const option = {};
        if ( fileType === 'json') {
            try {
                table.tbody.push([ getMessage.FTE10029, selectFile.json.length.toLocaleString() ]);
            } catch( e ) {
                throw new Error( getMessage.FTE10021 );
            }
            postData = selectFile.json;
        } else {
            try {
                const base64 = await fn.fileToBase64( selectFile );
                postData = {
                    'excel': base64
                }
            } catch( e ) {
                throw new Error( e );
            }
        }

        fn.alert( getMessage.FTE00083, fn.html.table( table, 'fileSelectTable', 1 ), 'confirm', buttons ).then( function( flag ){
            if ( flag ) {
                const processing = fn.processingModal( getMessage.FTE00084 );

                // POST（登録）
                fn.fetch(`/menu/${mn.params.menuNameRest}/${restUrl}`, null, 'POST', postData, option ).then(function( result ){
                    // 登録成功
                    fn.resultModal( result ).then(function(){
                        mn.contentTabOpen('#dataList');
                        mn.mainTable.changeViewMode();
                    });
                }).catch(function( error ){
                    if ( fn.typeof( error ) === 'object') {
                        if ( error.result === '498-00001') {
                            if ( fn.typeof( error.message ) === 'string') window.alert( error.message );
                        } else {
                            // 登録失敗
                            fn.errorModal( error, mn.title, mn.info );
                        }
                    }
                }).then(function(){
                    // ボタンを戻す
                    fn.disabledTimer( $button, false, 1000 );
                    processing.close();
                });
            } else {
                // キャンセル
                fn.disabledTimer( $button, false, 0 );
            }
        });
    }).catch(function( error ){
        if ( error !== 'cancel') {
            alert( error );
        }
        fn.disabledTimer( $button, false, 0 );
    });
}
/*
##################################################
    Create menu
##################################################
*/
CommonUi.prototype.createMenu = function( mode ) {
    const mn = this;

    const assets = [
        { type: 'js', url: sysAtt.createMenu, webAssetsUrl: false },
        { type: 'css', url: '/_/ita/css/editor_common.css'},
        { type: 'css', url: '/_/ita/css/create_menu.css'}
    ];

    fn.loadAssets( assets ).then(function(){
        //patch_create_menu();
        const createMenu = new CreateMenu('#content', mn.rest.user );
        createMenu.setup();

        mn.onReady();
    });
}
/*
##################################################
    Conductor
##################################################
*/
CommonUi.prototype.condcutor = function( mode ) {
    const mn = this;

    const assets = [
        { type: 'js', url: '/_/ita/js/conductor.js'},
        { type: 'css', url: '/_/ita/css/editor_common.css'},
        { type: 'css', url: '/_/ita/css/conductor.css'}
    ];

    const getId = function(){
        if ( mode === 'confirmation') {
            return fn.getParams().conductor_instance_id;
        } else {
            return fn.getParams().conductor_class_id;
        }
    }
    const id = getId();
    if ( mode === 'edit' && id ) mode = 'view';

    fn.loadAssets( assets ).then(function(){
        patch_conductor();
        const conductor = fn.createConductor( mn.params.menuNameRest, '#content', mode, id );
        conductor.setup();

        mn.onReady();
    });
}
/*
##################################################
    比較実行
##################################################
*/
CommonUi.prototype.compare = function() {
    const mn = this;

    const menuInfo = fn.cv( mn.info.menu_info.menu_info, '');
    mn.$.content.html( mn.commonContainer( mn.title, menuInfo, mn.contentSection() ) );
    mn.setCommonEvents();

    const assets = [
        { type: 'js', url: '/_/ita/js/compare.js'},
        { type: 'js', url: '/_/ita/lib/diff2html/diff2html.min.js'},
        { type: 'css', url: '/_/ita/css/compare.css'},
        { type: 'css', url: '/_/ita/lib/diff2html/diff2html.css'}
    ];

    fn.loadAssets( assets ).then(function(){
        patch_compare();
        const compare = new Compare( mn.params.menuNameRest );
        compare.setup();

        mn.onReady();
    });
}
/*
##################################################
    エクスポート・インポート
##################################################
*/
CommonUi.prototype.exportImport = function( type ) {
    const mn = this;

    const menuInfo = fn.cv( mn.info.menu_info.menu_info, '');
    mn.$.content.html( mn.commonContainer( mn.title, menuInfo, mn.contentSection() ) );
    mn.setCommonEvents();

    const assets = [
        { type: 'js', url: '/_/ita/js/export_import.js'},
        { type: 'css', url: '/_/ita/css/export_import.css'},
    ];

    fn.loadAssets( assets ).then(function(){
        patch_export_import();
        const exportImport =  new ExportImport( mn.params.menuNameRest, type );
        exportImport.setup();

        mn.onReady();
    });
}
/*
##################################################
    ダッシュボード
##################################################
*/
CommonUi.prototype.dashboard = function() {
    const mn = this;

    const assets = [
        { type: 'js', url: '/_/ita/js/dashboard.js'},
        { type: 'js', url: sysAtt.widget, webAssetsUrl: false },
        { type: 'css', url: '/_/ita/css/dashboard.css'},
    ];
    fn.loadAssets( assets ).then(function(){
        patch_dashboard();
        const dashboard =  new Dashboard('#content');
        dashboard.setup();

        mn.onReady();
    });
}
/*
##################################################
    連携先Terraform管理
##################################################
*/
CommonUi.prototype.terraformManagement = function() {
    const mn = this;

    const contentTab = [
        { name: 'terraformOrganization', title: getMessage.FTE09001, type: 'blank' },
        { name: 'terraformWorkspace', title: getMessage.FTE09002, type: 'blank'},
        { name: 'terraformPolicy', title: getMessage.FTE09003, type: 'blank'},
        { name: 'terraformPolicyset', title: getMessage.FTE09004, type: 'blank'}
    ];

    const menuInfo = fn.cv( mn.info.menu_info.menu_info, '');

    mn.$.content.html( mn.commonContainer( mn.title, menuInfo, mn.contentTab( contentTab ) ) );
    mn.setCommonEvents();
    mn.contentTabEvent('#terraformOrganization');

    const assets = [
        { type: 'js', url: '/_/ita/js/terraformManagement.js'}
    ];

    fn.loadAssets( assets ).then(function(){
        patch_terraformManagement();
        const terraform =  new TerraformManagement( mn.params.menuNameRest );
        terraform.setup();

        mn.onReady();
    });
}
/*
##################################################
    パラメータ集
##################################################
*/
CommonUi.prototype.parameterCollection = function() {
    const mn = this;

    const menuInfo = fn.cv( mn.info.menu_info.menu_info, '');
    mn.$.content.html( mn.commonContainer( mn.title, menuInfo, mn.contentSection() ) );
    mn.setCommonEvents();

    const assets = [
        { type: 'js', url: '/_/ita/lib/exceljs/exceljs.js'},
        { type: 'js', url: '/_/ita/js/parameter_collection.js'},
        { type: 'css', url: '/_/ita/css/parameter_collection.css'},
    ];

    fn.loadAssets( assets ).then(function(){
        const params = mn.params;
        params.user = mn.rest.user;

        const pc = new ParameterCollection( mn.params.menuNameRest, params );
        pc.setup();

        mn.onReady();
    });
}
/*
##################################################
    イベントフロー
##################################################
*/
CommonUi.prototype.eventFlow = function() {
    const mn = this;

    const menuInfo = fn.cv( mn.info.menu_info.menu_info, '');
    mn.$.content.html( mn.commonContainer( mn.title, menuInfo, mn.contentSection('', 'eventFlow') ) );
    mn.setCommonEvents();

    const assets = [
        { type: 'js', url: '/_/ita/js/event_flow.js'},
        { type: 'css', url: '/_/ita/css/event_flow.css'},
    ];

    fn.loadAssets( assets ).then(function(){
        const params = mn.params;
        params.user = mn.rest.user;

        const ef = new EventFlow( mn.params.menuNameRest, params );
        ef.setup('#eventFlow');

        mn.onReady();
    });
}
/*
##################################################
    独自メニュー
##################################################
*/
CommonUi.prototype.customMenu = function() {
    const mn = this;

    const assets = [
        { type: 'js', url: '/_/ita/js/custom_menu.js'}
    ];

    fn.loadAssets( assets ).then(function(){
        customMenu( mn.info ).then(function( $iframe ){
            mn.$.content.html( $iframe );
        }).catch(function(){
            // alert( getMessage.FTE12001 );
        }).then(function(){
            mn.onReady();
        });
    });
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   table.js class DataTable patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
/*
##################################################
    Worker Setup
##################################################
*/
DataTable.prototype.setupWorker = function(){
    this.worker = new Worker(sysAtt.tableWorker);
    this.setWorkerEvent();
}
/*
##################################################
   Worker post
   > Workerにmessageを送信
##################################################
*/
DataTable.prototype.workerPost = async function( type, data ) {
    const tb = this;

    const post = {
        tableInfo: tb.info,
        type: type,
        paging: tb.paging,
        sort: tb.sort,
        idName: tb.idNameRest,
        apiPath: conf.apiPath,
    };
    fn.consoleOutput('type='+type+'; data='+data);

    // 送信タイプ別
    switch ( type ) {
        case 'filter': {
            const filterRest = ( tb.option.fileFlag === false )? tb.rest.filter + '?file=no': tb.rest.filter;

            const url = fn.getRestApiUrl(
                filterRest,
                tb.params.orgId,
                tb.params.wsId );

            const token = ( fn.getCmmonAuthFlag() )? CommonAuth.getToken():
                ( window.parent && window.parent.getToken )? window.parent.getToken(): null;

            post.rest = {
                token: token,
                url: url,
                filter: data
            };
        } break;
        case 'edit':
            post.select = data;
        break;
        case 'add':
        case 'changeEditRegi':
            post.add = data;
        break;
        case 'dup':
            try {
                await tb.duplicatFileCheck( data.select, data.input );
                post.select = data.select;
                post.addId = data.id;
                post.input = data.input;
                post.tempFile = tb.data.tempFile;
            } catch( error ) {
                tb.workEnd();
                tb.resetTable();
                return;
            }
        break;
        case 'changeEditDup':
            try {
                await tb.duplicatFileCheck( data.target, {});
                post.select = data.target;
                post.addId = data.id;
                post.tempFile = tb.data.tempFile;
            } catch( error ) {
                tb.workEnd();
                tb.resetTable();
                return;
            }
        break;
        case 'del':
            post.select = data;
        break;
        case 'normal':
            post.tableData = data;
        break
        case 'discard':
        case 'restore':
            post.select = data;
        break;
        case 'history': {
            const url = fn.getRestApiUrl(
                `${tb.rest.filter}journal/${data}/`,
                tb.params.orgId,
                tb.params.wsId );

            const token = ( fn.getCmmonAuthFlag() )? CommonAuth.getToken():
                ( window.parent && window.parent.getToken )? window.parent.getToken(): null;

            post.rest = {
                token: token,
                url: ( tb.option.fileFlag === false )? url  + '?file=no': url
            };
        } break;
        case 'search':
            post.searchText = data.text;
            post.searchKeys = data.keys;
        break;
        case 'delete':
            post.tableData = data;
        break;
    }
    tb.worker.postMessage( post );
}
/*
##################################################
   Edit OK
##################################################
*/
DataTable.prototype.editOk = async function() {
    const tb = this;

    tb.data.editOrder = [];

    // エラーリセット
    tb.$.container.removeClass('tableError');
    tb.$.errorMessage.empty();

    const editData = [];

    for ( const itemId of tb.data.order ) {
        if ( tb.edit.input[ itemId ] !== undefined ) {
            const info = tb.info.column_info,
                  item = tb.edit.input[ itemId ];

            const itemData = {
                file: {},
                parameter: {}
            };

            tb.data.editOrder.push( itemId );
            if ( !tb.data.regiColumnKeys ) tb.data.regiColumnKeys = tb.data.columnKeys;

            for ( const columnKey of tb.data.regiColumnKeys ) {
                const columnNameRest = info[ columnKey ].column_name_rest,
                      columnType = info[ columnKey ].column_type;

                const fileCheck = async function( file ) {
                    if ( fn.typeof( file ) === 'file') {
                        return await fn.fileToBase64( file );
                    } else if ( fn.typeof( file ) === 'string') {
                        return file
                    } else {
                        return null;
                    }
                };

                // 入力済みがあるか？
                const setData = function( type ) {
                    if ( item.after[ type ][ columnNameRest ] !== undefined ) {
                        return item.after[ type ][ columnNameRest ]
                    } else {
                        return fn.cv( item.before[ type ][ columnNameRest ], null );
                    }
                };

                // 登録か更新か？
                if ( !isNaN( itemId ) && Number( itemId ) < 0 ) {
                    itemData.type = 'Register';
                } else {
                    itemData.type = 'Update';
                }

                if ( tb.idNameRest === columnNameRest && itemData.type === 'Register') {
                    // 登録の場合、IDカラムはnull
                    itemData.parameter[ columnNameRest ] = null;
                } else {
                    switch ( columnType ) {
                        // File
                        case 'FileUploadColumn':
                            itemData.parameter[ columnNameRest ] = setData('parameter');

                            const fileAfterValue = item.after.parameter[ columnNameRest ];
                            if ( ( fileAfterValue !== undefined && fileAfterValue !== '') || itemData.type === 'Register'){
                                itemData.file[ columnNameRest ] = await fileCheck( setData('file') );
                            }
                        break;
                        // File（機器一覧：ssh秘密鍵ファイルなど）
                        case 'FileUploadEncryptColumn': {
                            const fileAfterValue = item.after.parameter[ columnNameRest ];
                            // 変更があるか？（更新時、変更がなければ値をセットしない）
                            if ( fileAfterValue !== undefined && fileAfterValue !== '') {
                                itemData.parameter[ columnNameRest ] = setData('parameter');
                                // nullじゃなければファイルもセット
                                if ( fileAfterValue !== null ) {
                                    itemData.file[ columnNameRest ] = setData('file');
                                }
                                // { key: null } の場合は削除とする
                            } else if ( itemData.type === 'Register') {
                                // 登録時（複製時など）
                                const
                                name = setData('parameter'),
                                file = await fileCheck( setData('file') );
                                if ( name && file ) {
                                    itemData.parameter[ columnNameRest ] = name;
                                    itemData.file[ columnNameRest ] = file;
                                }
                            }
                        } break;
                        // 最終更新日時と最終更新者
                        case 'LastUpdateDateColumn': case 'LastUpdateUserColumn':
                            if ( itemData.type === 'Register' ) {
                                itemData.parameter[ columnNameRest ] = null;
                            } else {
                                itemData.parameter[ columnNameRest ] = setData('parameter');
                            }
                        break;
                        // パスワード
                        case 'PasswordColumn': case 'MultiPasswordColumn': case 'PasswordIDColumn': case 'JsonPasswordIDColumn': case 'MaskColumn':
                        case 'SensitiveSingleTextColumn': case 'SensitiveMultiTextColumn': {
                            const passwordAfterValue = item.after.parameter[ columnNameRest ];
                            if ( passwordAfterValue === false ) {
                                // false -> 削除 { key: null }
                                itemData.parameter[ columnNameRest ] = null;
                            } else if ( passwordAfterValue !== '' && passwordAfterValue !== null && passwordAfterValue !== undefined ){
                                // 値有 -> 更新 { key: value }
                                itemData.parameter[ columnNameRest ] = passwordAfterValue;
                            } else if ( itemData.type === 'Register') {
                                // 登録時（複製時など）
                                const password = setData('parameter');
                                if ( password ) itemData.parameter[ columnNameRest ] = password;
                            }
                            // null or 空白 -> そのまま（keyをセットしない）
                        } break;
                        // 基本
                        default:
                            itemData.parameter[ columnNameRest ] = setData('parameter');
                    }
                }
            }
            editData.push( itemData );
        }
    }

    return new Promise(async function( resolve, reject ){
        fn.xhr( tb.rest.maintenance, editData )
            .then(function( result ){
                resolve( result );
            })
            .catch(function( result ){
                if ( fn.typeof( result ) === 'object') {
                    if ( result.result && result.result.match(/^498/) ) {
                        if ( fn.typeof( result.message ) === 'string') alert( result.message );
                        reject( null );
                    } else {
                        result.data = editData;
                        reject( result );
                        //バリデーションエラー
                        alert(getMessage.FTE00068);
                    }
                } else {
                    reject( null );
                }
            });
    });
}
/*
##################################################
    特殊メニュー　素材リンク
##################################################
*/
DataTable.prototype.specialMenuMaterialLinkColumn = function( materialLink, value ) {
    const filter = {};
    let filterValue = value;
    if ( materialLink.linkColumn === 'role_package_list') {
        filterValue = filterValue.substring( 0, filterValue.lastIndexOf(':') );
    }
    filter[ materialLink.filterColumn ] = { LIST: filterValue };
    const href = fn.createPageUrl( materialLink.linkMenu,
        {
            filter: fn.filterEncode(filter)
        }
    );
    return `<a href="${href}">${value}</a>`;
}
/*
##################################################
   作業実行
##################################################
*/
DataTable.prototype.execute = function( type ) {
    const tb = this;

    return new Promise(function( resolve ){

        const dryrunText = ( tb.driver === 'ansible')? getMessage.FTE00006: getMessage.FTE00167;

        const setConfig = function() {
            switch ( type ) {
                case 'run':
                    return {
                        title: getMessage.FTE00005,
                        rest: `/menu/${tb.params.menuNameRest}/driver/execute/`
                    };
                case 'dryrun':
                    return {
                        title: dryrunText,
                        rest: `/menu/${tb.params.menuNameRest}/driver/execute_dry_run/`
                    };
                case 'parameter':
                    return {
                        title: getMessage.FTE00007,
                        rest: `/menu/${tb.params.menuNameRest}/driver/execute_check_parameter/`
                    };
            }
        };

        const executeConfig = setConfig();
        executeConfig.itemName = 'Movement';
        executeConfig.selectName = tb.select.execute[0].name;
        executeConfig.selectId = tb.select.execute[0].id;
        executeConfig.operation = tb.params.operation;

        tb.workStart( type );
        fn.executeModalOpen( tb.id + '_' + type, tb.params.menuNameRest, executeConfig ).then(function( result ){
            if ( result !== 'cancel') {
                const postData = {
                movement_name: result.selectName,
                operation_name: result.name,
                schedule_date: result.schedule
                };
                // 作業実行開始
                fn.fetch( executeConfig.rest, null, 'POST', postData ).then(function( result ){
                    const href = fn.createPageUrl(`check_operation_status_${tb.params.operationType}`,
                    {
                        execution_no: result.execution_no
                    });
                    window.location.href = href;
                }).catch(function( error ){
                    if ( error.message ) alert( error.message );
                    tb.workEnd();
                    resolve();
                });
            } else {
                tb.workEnd();
                resolve();
            }
        });
    });
}
/*
##################################################
  Button action
##################################################
*/
DataTable.prototype.buttonAction = function( columnInfo, item, columnKey ) {
    const tb = this;

    // ボタンアクション
    let buttonAction;
    try {
        buttonAction = JSON.parse( columnInfo.button_action );
    } catch( e ) {
        buttonAction = [];
    }

    const buttonAttrs = {
        rest: columnInfo.column_name_rest,
    };
    for ( const action of buttonAction ) {

        // タイプ
        buttonAttrs.type = fn.cv( action[0], '');
        switch ( buttonAttrs.type ) {
            // 別ページにリダイレクト
            case 'redirect':
                if ( !buttonAttrs.redirect ) {
                    const sys_id = fn.getParams().sys_id || '';
                    buttonAttrs.redirect = `?sys_id=${sys_id}&`;
                } else {
                    buttonAttrs.redirect += '&';
                }
                const param = fn.cv( item.parameter[ action[2] ], '', true );
                buttonAttrs.action = 'positive';
                buttonAttrs.redirect += action[1] + param;
                // 値が無い場合はボタンを無効化
                if ( param === '') buttonAttrs.disabled = 'disabled';
            break;
            case 'redirect_filter':
                buttonAttrs.item = item.parameter[ tb.idNameRest ];
                buttonAttrs.columnkey = columnKey;
                buttonAttrs.action = 'positive';
            break;
            // ファイルダウンロード
            case 'download': {
                const endPoint = action[2].replace('{menu}', tb.params.menuNameRest ),
                      valueKeys = action[3];

                buttonAttrs.method = action[1];
                buttonAttrs.fileName = action[4][0];
                buttonAttrs.fileData = action[4][1];

                if ( endPoint ) {
                    let api = endPoint.replace(/^\/ita/, '');
                    for ( const key of valueKeys ) {
                        const value = item.parameter[ key ];
                        if ( value ) {
                            // keyを値に置換
                            api = api.replace(`{${key}}`, value );
                        }
                    }
                    buttonAttrs.url = api;
                    buttonAttrs.action = 'default';
                } else {
                    buttonAttrs.disabled = 'disabled';
                }
            } break;
            // モーダル
            case 'modal': {
                buttonAttrs.modal = action[1];
                buttonAttrs.action = 'default';
                buttonAttrs.id = item.parameter[ tb.idNameRest ];
            } break;
            // REST API
            case 'restapi_redirect':
            case 'restapi': {
                const method = action[1],
                      endPoint = action[2],
                      valueKeys = action[3],
                      bodyKeys = action[4];

                if ( endPoint && valueKeys ) {
                    let api = endPoint.replace(/^\/ita/, '');
                    const replaceTarget = api.match(/\{[^\{\}]*\}/g);
                    if ( replaceTarget !== null ) {
                        const replaceLength = replaceTarget.length;
                        for ( let i = 0; i < replaceLength; i++ ) {
                            const value = ( valueKeys[i] )? fn.cv( item.parameter[ valueKeys[i] ] ): '';
                            if ( value ) api = api.replace( replaceTarget[i], value );
                        }
                    }
                    buttonAttrs.restapi = api;
                }

                if ( endPoint && bodyKeys ) {
                    const body = {};
                    for ( const key of bodyKeys ) {
                        const value = item.parameter[ key ];
                        if ( value ) {
                            // keyを値に置換
                            body[ key ] = value;
                        }
                    }
                    buttonAttrs.body = fn.escape( JSON.stringify( body ) );
                }
                buttonAttrs.action = 'default';
                buttonAttrs.key = columnKey;
                buttonAttrs.method = method;
                if ( buttonAttrs.type === 'restapi_redirect') {
                    buttonAttrs.redirect = action[5];
                    buttonAttrs['redirect-key'] = action[6]
                }
            } break;
        }
    }

    const text = fn.cv( columnInfo.column_name, '', true );
    return fn.html.button( text, ['actionButton', 'itaButton'], buttonAttrs );
}
/*
##################################################
   Set table events
##################################################
*/
DataTable.prototype.setTableEvents = function() {
    const tb = this;

    fn.consoleOutput('tb.mode='+tb.mode);

    /*
    ------------------------------
    EDIT以外
    ------------------------------
    */
    if ( tb.mode !== 'edit') {
        // リンクファイルダウンロード
        tb.$.tbody.on('click', '.tableViewDownload', function(e){
            e.preventDefault();

            const $a = $( this );
            if ( $a.is('.nowDownload') ) return;

            const fileName = $a.text();
            const rest = $a.attr('data-rest');
            const type = $a.attr('data-type');

            const id = $a.attr('data-id');
            const journalId = $a.attr('data-journalId');
            const fileId = ( tb.mode !== 'history')? id: journalId;

            let file = tb.getFileData( fileId, rest, type );

            // ファイルモード
            if ( tb.option.fileFlag === false && fileName !== '' && file === undefined ) {
                const restType = $a.attr('data-restType');
                let endPoint = `/menu/${tb.params.menuNameRest}/${id}/${rest}/file/`;
                if ( restType === 'history' && tb.mode === 'history') {
                    const journalId = $a.attr('data-journalId');
                    endPoint += `journal/${journalId}/`;
                }
                $a.addClass('nowDownload');
                fn.getFile( endPoint, 'GET', null, { title: getMessage.FTE00185, ext: fn.getExt(fileName) }).then(function( file ){
                    fn.download('file', file, fileName );
                    $a.removeClass('nowDownload');
                }).catch(function( e ){
                    if ( e !== 'break') {
                        console.error( e );
                        alert( getMessage.FTE00179 );
                    }
                    $a.removeClass('nowDownload');
                });
            } else {
                if ( file !== undefined && file !== null ) {
                    const fileType = ( fn.typeof( file ) === 'file')? 'file': 'base64';
                    fn.download( fileType, file, fileName );
                } else {
                    alert( getMessage.FTE06033 );
                }
            }
        });

        // ファイルプレビュー
        tb.$.tbody.on('click', '.filePreview', async function(e){
            // ファイルモーダルが開いているときは無効
            if ( tb.modalFlag ) {
                e.preventDefault();
                return false;
            }

            const $button = $( this );
            const $a = $( this ).prev();
            const fileName = $a.text();
            const rest = $a.attr('data-rest');
            const type = $a.attr('data-type');

            const id = $a.attr('data-id');
            const journalId = $a.attr('data-journalId');
            const fileId = ( tb.mode !== 'history')? id: journalId;

            $button.prop('disabled', true );
            tb.modalFlag = true;
            let file = tb.getFileData( fileId, rest, type );

            const option = {
                endPoint: `/menu/${tb.params.menuNameRest}/${id}/${rest}/file/`
            };

            // ファイルモード
            if ( tb.option.fileFlag === false && fileName !== '' && file === undefined ) {
                const restType = $a.attr('data-restType');
                if ( restType === 'history' && tb.mode === 'history') {
                    const journalId = $a.attr('data-journalId');
                    option.endPoint += `journal/${journalId}/`;
                }
                try {
                    file = await fn.getFile( option.endPoint, 'GET', null, { ext: fn.getExt(fileName) } );
                } catch ( e ) {
                    if ( e !== 'break') {
                        console.error( e );
                        alert( getMessage.FTE00179 );
                    }
                    $button.prop('disabled', false );
                    tb.modalFlag = false;
                    return;
                }
                fn.fileEditor( file, fileName, 'preview', option ).then(function(){
                    $button.prop('disabled', false );
                    tb.modalFlag = false;
                });
            } else {
                if ( !file ) file = '';
                fn.fileEditor( file, fileName, 'preview', option ).then(function(){
                    $button.prop('disabled', false );
                    tb.modalFlag = false;
                });
            }
        });
    }
    /*
    ------------------------------
    VIEW モード
    ------------------------------
    */
    if ( tb.mode === 'view' || tb.mode === 'select' || tb.mode === 'execute') {
        const $eventTarget = ( tb.option.sheetType !== 'reference')? tb.$.thead: tb.$.header.find('.referenceFilterTable');

        // フィルタプルダウン検索ボタン
        $eventTarget.on('click', '.filterPulldownOpenButton', function(){
            if ( !tb.checkWork ) {
                tb.filterSelectOpen.call( tb, $( this ));
            }
        });

        // フィルター欄、ファイルダウンロード
        const downloadFile = async function( $button, type, url ){
            tb.filterParams = tb.getFilterParameter();
            const ext = ( type === 'excel')? '.xlsx': '.json';
            const fileName = fn.cv( tb.info.menu_info.menu_name, 'file') + '_filter' + ext;

            $button.prop('disabled', true );
            try {
                const file = await fn.getFile( url, 'POST', tb.filterParams, { title: getMessage.FTE00185, fileType: type, ext: fn.getExt(fileName) });
                if ( type !== 'json') type = 'file';
                fn.download( type, file, fileName );
            } catch ( error ) {
                if ( error !== 'break') {
                    fn.gotoErrPage( error.message );
                }
            }
            fn.disabledTimer( $button, false, 1000 );
        };

        // オートフィルター
        $eventTarget.on({
            'change': function(){
                tb.flag.autoFilter = $( this ).prop('checked');
            },
            'click': function( e ){
                if ( !tb.checkWork ) return;
                e.preventDefault();
            }
        }, '.filterMenuAutoFilter');

        $eventTarget.on('change', '.filterInput', function(){
            if ( !tb.checkWork && tb.flag.autoFilter ) {
                $eventTarget.find('.filterMenuButton[data-type="filter"]').click();
            }
        });

        // フィルタボタン
        $eventTarget.on('click', '.filterMenuButton', function(){
            if ( !tb.checkWork ) {

                tb.$.container.removeClass('tableError');
                tb.$.errorMessage.empty();

                const $button = $( this ),
                      type = $button.attr('data-type');
                switch ( type ) {
                    case 'filter':
                        tb.workStart('filter');
                        tb.setInitSort();
                        tb.requestTbody.call( tb, 'filter');
                    break;
                    case 'clear':
                        tb.workStart('table', 0 );
                        tb.clearFilter.call( tb );
                    break;
                    case 'excel':
                        downloadFile( $button, 'excel', tb.rest.excelDownload );
                    break;
                    case 'json':
                        if ( window.confirm( getMessage.FTE00181 ) ) {
                            downloadFile( $button, 'json', tb.rest.jsonDownload );
                        }
                    break;
                    case 'jsonNoFile':
                        downloadFile( $button, 'json', tb.rest.jsonDownload + '?file=no');
                    break;
                }
            }
        });

        // フィルタカレンダー
        if ( tb.option.sheetType !== 'reference') {
            $eventTarget.find('.filterInputDatePicker').on('click', function(){
                if ( !tb.checkWork ) {
                    const $button = $( this ),
                          rest = $button.attr('data-rest'),
                          type = $button.attr('data-type');

                    const $from = tb.$.thead.find(`.filterFromDate[data-rest="${rest}"]`),
                          $to = tb.$.thead.find(`.filterToDate[data-rest="${rest}"]`);

                    const from = $from.val(),
                          to = $to.val();

                    const dateFlag = ( type === 'dateTime')? true: false;

                    fn.datePickerDialog('fromTo', dateFlag, tb.data.restNames[ rest ], { from: from, to: to } ).then(function( result ){
                        if ( result !== 'cancel') {
                            $from.val( result.from );
                            $to.val( result.to ).trigger('change');
                        }
                    });
                }
            });
        } else {
            const $input = $eventTarget.find('.filterDate'),
                  rest = $input.attr('data-rest'),
                  title = tb.data.restNames[ rest ];
            fn.setDatePickerEvent( $eventTarget.find('.filterDate'), title );
        }

        // ソート
        tb.$.thead.on('click', '.tHeadSort', function(){
            if ( !tb.checkWork && tb.data.count ) {
                tb.workStart('sort', 100 );

                const $sort = $( this ),
                      id = $sort.attr('data-id'),
                      sort = tb.info.column_info[ id ].column_name_rest;

                let order = $sort.attr('data-sort');
                if ( !order || order === 'ASC') {
                    order = 'DESC';
                } else {
                    order = 'ASC';
                }
                tb.$.thead.find('.tHeadSort').removeAttr('data-sort');
                $sort.attr('data-sort', order );

                tb.sort = [{}];
                tb.sort[0][ order ] = sort;
                tb.workerPost('sort');
            }
        });

        // 個別メニュー
        tb.$.tbody.on('click', '.tBodyRowMenu', function(){
            if ( tb.getTableSettingValue('menu') === 'show') return;

            if ( !tb.checkWork ) {
                const $row = $( this );
                if ( $row.is('.open') ) {
                    $row.removeClass('open');
                    tb.$.window.off('pointerdown.rowMenu');
                } else {
                    $row.addClass('open');
                    tb.$.window.on('pointerdown.rowMenu', function( e ){
                        const $target = $( e.target );
                        if ( !$target.closest( $row ).length ) {
                            $row.removeClass('open');
                            tb.$.window.off('pointerdown.rowMenu');
                        }
                    });
                }
            }
        });

        // 編集、複製
        tb.$.tbody.on('click', '.tBodyRowMenuTb', function(){
            if ( !tb.checkWork ) {
                const $button = $( this ),
                      type = $button.attr('data-type'),
                      itemId = $button.attr('data-id');

                tb.select.view = [ itemId ];

                const findData = tb.data.body.find(function( data ){
                    return String( data.parameter[ tb.idNameRest ] ) === String( itemId );
                });
                if ( findData ) {
                    tb.selectedData[ itemId ] = findData;
                }

                switch ( type ) {
                    case 'rowEdit':
                        tb.changeEdtiMode.call( tb );
                    break;
                    case 'rowDup':
                        tb.changeEdtiMode.call( tb, 'changeEditDup');
                    break;
                }
            }
        });
    }

    /*
    ------------------------------
    EDIT モード
    ------------------------------
    */
    if ( tb.mode === 'edit') {
        // ファイル選択
        tb.$.tbody.on('click', '.tableEditSelectFile', function(e){
            if ( tb.modalFlag ) {
                e.preventDefault();
                return false;
            }

            const
            $button = $( this ),
            id = $button.attr('data-id'),
            key = $button.attr('data-key'),
            maxSize = $button.attr('data-upload-max-size');

            $button.prop('disabled', true );

            fn.fileSelect('file', maxSize ).then(function( result ){

                const changeFlag = tb.setInputFile( result.name, result, id, key, tb.data.body );

                $button.find('.inner').text( result.name );
                if ( changeFlag ) {
                    $button.addClass('tableEditChange');
                } else {
                    $button.removeClass('tableEditChange');
                }
            }).catch(function( error ){
                if ( error !== 'cancel') {
                    alert( error );
                }
            }).then(function(){
                $button.prop('disabled', false );
            });
        });

        // ファイル編集
        tb.$.tbody.on('click', '.inputFileEditButton',async function(e){
            if ( tb.modalFlag ) {
                e.preventDefault();
                return false;
            }

            const
            $button = $( this ),
            id = $button.attr('data-id'),
            rest = $button.attr('data-key'),
            $fileBox = $button.closest('.inputFileEdit').prev().find('.tableEditSelectFile');

            $button.prop('disabled', true );
            tb.modalFlag = true;

            let file = tb.getFileData( id, rest );
            let fileName = $fileBox.text();

            const fileType = fn.fileTypeCheck( fileName );
            const option = {
                endPoint: `/menu/${tb.params.menuNameRest}/${id}/${rest}/file/`
            };

            // ファイルが空、かつ編集可能の場合はファイルを取得する
            if ( tb.option.fileFlag === false && fileName !== '' && file === undefined && ( fileType === 'text' || fileType === 'image') ) {
                try {
                    file = await fn.getFile( option.endPoint, 'GET', null, { ext: fn.getExt(fileName)} );
                } catch ( e ) {
                    if ( e !== 'break') {
                        console.error( e );
                        alert( getMessage.FTE00179 );
                    }
                    $button.prop('disabled', false );
                    tb.modalFlag = false;
                    return;
                }
            } else {
                if ( !file ) file = null;
            }
            if ( !fileName ) fileName = 'noname.txt';

            fn.fileEditor( file, fileName, 'edit', option ).then(function( result ){
                if ( result !== null ) {
                    const changeFlag = tb.setInputFile( result.name, result.file, id, rest, tb.data.body );

                    $fileBox.find('.inner').text( result.name );
                    if ( changeFlag ) {
                        $fileBox.addClass('tableEditChange');
                    } else {
                        $fileBox.removeClass('tableEditChange');
                    }
                }

                $button.prop('disabled', false );
                tb.modalFlag = false;
            });
        });

        // 入力データを配列へ
        tb.$.tbody.on('change', '.input, .tableEditInputSelect', function(){
            const $input = $( this ),
                  value = ( $input.val() !== '')? $input.val(): null,
                  id = $input.attr('data-id'),
                  key = $input.attr('data-key');

            const changeFlag = tb.setInputData( value, id, key, tb.data.body );
            
            if ( changeFlag ) {
                $input.addClass('tableEditChange');
                if ( $input.is('.tableEditInputSelect') ) {
                    $input.parent('.tableEditInputSelectContainer, .tableEditInputMultipleSelectContainer').addClass('tableEditChange');
                }
                if ( $input.is('.tableEditMultipleHiddenColmun') ) {
                    $input.prev('.tableEditMultipleColmun').addClass('tableEditChange');
                }
            } else {
                $input.removeClass('tableEditChange');
                if ( $input.is('.tableEditInputSelect') ) {
                    $input.parent('.tableEditInputSelectContainer, .tableEditInputMultipleSelectContainer').removeClass('tableEditChange');
                }
                if ( $input.is('.tableEditMultipleHiddenColmun') ) {
                    $input.prev('.tableEditMultipleColmun').removeClass('tableEditChange');
                }
            }
        });

        // 入力チェック
        tb.$.tbody.on('input', '.input', function(){
            const $input = $( this ),
                  value = $input.val();
            // 必須
            if ( $input.attr('data-required') === '1') {
                if ( value !== '') {
                    $input.removeClass('tableEditRequiredError');
                } else {
                    $input.addClass('tableEditRequiredError');
                }
            }
        });

        // データピッカー
        tb.$.tbody.on('click', '.inputDateCalendarButton', function(){
            const $button = $( this ),
                  $input = $button.closest('.inputDateContainer').find('.inputDate'),
                  rest = $input.attr('data-key'),
                  value = $input.val(),
                  timeFlag = $input.attr('data-timeFlag') === 'true';

            fn.datePickerDialog('date', timeFlag, tb.data.restNames[ rest ], value ).then(function( result ){
                if ( result !== 'cancel') {
                    $input.val( result.date ).change().focus().trigger('input');
                }
            });
        });

        // 変更があるときの離脱確認
        tb.$.window.on('beforeunload', function( e ){
            if ( Object.keys( tb.edit.input ).length ) {
                e.preventDefault();
                return '';
            }
        });

        // パスワード削除ボタン
        tb.$.tbody.on('click', '.inputPasswordDeleteToggleButton', function(e){
            if ( tb.modalFlag ) {
                e.preventDefault();
                return false;
            }

            const $button = $( this ),
                  $wrap = $button.closest('.inputPasswordWrap'),
                  $input = $wrap.find('.inputPassword'),
                  value = $input.val(),
                  id = $input.attr('data-id'),
                  key = $input.attr('data-key');

            let flag;

            $button.trigger('pointerleave');

            if ( !$button.is('.on') ) {
                $button.addClass('on').attr({
                    'data-action': 'restore',
                    'title': getMessage.FTE00052
                });
                $button.find('.inner').html( fn.html.icon('ellipsis'));
                $wrap.addClass('inputPasswordDelete');
                flag = true;
            } else {
                $button.removeClass('on').attr({
                    'data-action': 'danger',
                    'title': getMessage.FTE00053
                });
                $button.find('.inner').html( fn.html.icon('cross'));
                $wrap.removeClass('inputPasswordDelete');
                flag = false;
            }

            // パスワードを削除する場合は false を入れる
            const inputValue = ( flag )? false: value;
            tb.setInputData( inputValue, id, key, tb.data.body );
        });

        // ファイル選択クリア
        tb.$.tbody.on('click', '.inputFileClearButton', function(e){
            if ( tb.modalFlag ) {
                e.preventDefault();
                return false;
            }

            const $button = $( this ),
                  $wrap = $button.closest('.inputFileWrap'),
                  $input = $wrap.find('.inputFile'),
                  id = $input.attr('data-id'),
                  key = $input.attr('data-key');

            const changeFlag = tb.setInputFile( null, undefined, id, key, tb.data.body );

            $input.find('.inner').text('');
            if ( changeFlag ) {
                $input.addClass('tableEditChange');
            } else {
                $input.removeClass('tableEditChange');
            }
        });

        // select2が隠れている場合スクロールで調整する
        const select2ScrollCheck = function( $element ) {
            if ( tb.partsFlag ) return;

            const
            width = $element.closest('.ci').width(),
            left = $element.closest('.ci').offset().left,
            wrapLeft = tb.$.wrap.offset().left,
            wrapWidth = tb.$.wrap.width(),
            wrapScroll = tb.$.wrap.scrollLeft();

            if ( left - wrapLeft + width - wrapScroll > wrapWidth - wrapScroll ) {
                tb.$.wrap.scrollLeft( ( left - wrapLeft + width ) - ( wrapWidth - wrapScroll ) );
            }
        };

        // select欄クリック時にselect2を適用する
        tb.$.tbody.on('click', '.tableEditInputSelectValue, .tableEditInputMultipleSelectValue', function(){
            const
            $value = $( this ),
            $select = $value.next('.tableEditInputSelect'),
            restName = $select.attr('data-key'),
            required = $select.attr('data-required'),
            multiple = $select.is('.tableEditInputMultipleSelect');

            if ( $value.is('.tableEditInputSelectValueDisabled') ) return false;

            const list = Object.keys( tb.data.editSelect[ restName ] ).map(function(key){
                return tb.data.editSelect[ restName ][ key ];
            });

            // 必須じゃない場合は空白を追加する
            if ( required === '0' && multiple !== true ) list.unshift('');

            tb.setSelect2( null, $select, list, true, null, $value, multiple ).then(function(){
                $select.change();
            });
        });

        // select2が開いているときはスクロールさせない
        tb.$.tbody.on({
            'select2:opening': function( e ){
                select2ScrollCheck( $( e.target ) );
                $( this ).closest('.tableWrap').on('wheel.select2Scroll', function(){
                    e.preventDefault();
                });
            },
            'select2:closing': function(){
                $( this ).closest('.tableWrap').off('wheel.select2Scroll');
            }
        });

        // select欄フォーカス時にselect2を適用する
        tb.$.tbody.on('focus.select2', '.tableEditInputSelect', function(){
            const
            $select = $( this ),
            flag = $select.is('.tableEditInputMultipleSelect'),
            container = ( flag )? '.tableEditInputMultipleSelectContainer': '.tableEditInputSelectContainer',
            value = ( flag )? '.tableEditInputMultipleSelectValue': '.tableEditInputSelectValue';

            // フォーカス時のスクロールを0に
            $select.closest( container ).scrollTop(0);

            // クリックイベント
            $select.prev( value ).click();
        });

        // input hidden変更時にテキストも変更する
        tb.$.tbody.on('change', '.tableEditInputHidden', function(){
            const $input = $( this ),
                  value = $input.val(),
                  $text = $input.prev('.tableEditInputHiddenText');
            $text.text( value );
        });

        // カラーピッカー クリックしたときに値をinputに入れる
        let colorFlag = false;
        const colorChange = function( $color ) {
            const
            $wrap = $color.closest('.inputColorEditWrap'),
            $mark = $wrap.find('.inputColorEditSelect'),
            $text = $wrap.find('.inputText'),
            value = fn.checkHexColorCode( $color.val() );

            $text.val( value ).change();
            $mark.css('background-color', value );
        };
        tb.$.tbody.on({
            'click': function(){
                colorChange( $(this) );
            },
            'change': function(){
                colorChange( $(this) );
            }
        }, '.inputColorEdit');

        // テキスト入力をカラーピッカーに反映する
        tb.$.tbody.on('change', '.tableEditSColorCode', function(){
            const
            $text = $( this ),
            $wrap = $text.closest('.inputColorEditWrap'),
            $mark = $wrap.find('.inputColorEditSelect'),
            $color = $wrap.find('.inputColorEdit'),
            value = fn.checkHexColorCode( $text.val(), false ),
            text = fn.checkHexColorCode( $text.val() );

            $color.val( value );
            $mark.css('background-color', value );

            $text.val( text );
        });

        // tableEditMultipleColmun
        tb.$.tbody.on('click', '.tableEditMultipleColmun', function(){
            const
            $block = $( this ),
            $input = $block.next('.inputHidden'),
            restName = $input.attr('data-key'),
            columnType = $input.attr('data-column-type'),
            required = $input.attr('data-required'),
            value = $input.val();

            tb.multipleColmunSetting( columnType, restName, value, required ).then(function( result ){
                if ( result !== undefined ) {
                    const resultValue = ( fn.typeof( result ) === 'array' && result.length )? fn.jsonStringifyDelimiterSpace( result ): '[]';
                    $input.val( resultValue ).change();

                    // 表示欄の幅の調整
                    if ( !tb.partsFlag ) {
                        $block.find('span').text( resultValue );
                        tb.tableInputMaxWidthCheck( $block );
                    } else {
                        $block.html( fn.html.labelListHtml( resultValue, tb.label ) );
                    }
                }
            });
        });
    }

    /*
    ------------------------------
    VIEW or EDIT モード
    ------------------------------
    */
    if ( ( tb.mode === 'select' && tb.params.selectType === 'multi') || tb.mode === 'view' || tb.mode === 'edit') {

        // アクションボタン
        tb.$.tbody.on('click', '.actionButton', function(){
            if ( !tb.checkWork ) {
                const $button = $( this ),
                      type = $button.attr('data-type');

                switch ( type ) {
                    case 'redirect': case 'redirect2': {
                        const redirect = $button.attr('data-redirect');
                        if ( redirect ) {
                            window.location.href = redirect;
                        }
                    } break;
                    case 'redirect_filter': {
                        const itemId = $button.attr('data-item'),
                            columnKey = $button.attr('data-columnkey');

                        const itemData = tb.data.body.find(function( item ){
                            return item.parameter[ tb.idNameRest ] === itemId;
                        });

                        if ( itemData ) {
                            let buttonAction;
                            try {
                                buttonAction = JSON.parse( tb.info.column_info[ columnKey ].button_action );
                            } catch( e ) {
                                buttonAction = [];
                            }

                            const redirectUrl = buttonAction[0][1],
                                filter = {};

                            for ( const f of buttonAction[0][2] ) {
                                const parameterKey = f[0],
                                    filterSetKey = f[1],
                                    filterType = f[2];

                                let value;
                                if ( filterType === 'LIST') {
                                    value = [ itemData.parameter[ parameterKey ] ];
                                } else if ( filterType === 'RANGE') {
                                    //
                                } else {
                                    value = itemData.parameter[ parameterKey ];
                                }
                                filter[ filterSetKey ] = {};
                                filter[ filterSetKey ][ filterType ] = value;
                            }
                            if ( redirectUrl ) {
                                window.location.href = `?${redirectUrl}&filter=${fn.filterEncode( filter )}`;
                            }
                        } else {
                            alert('Button action error.');
                        }
                    } break;
                    case 'download': {
                        $button.prop('disabled', true );
                        const url = $button.attr('data-url'),
                              method = $button.attr('data-method'),
                              nameKey = $button.attr('data-filename'),
                              dataKey = $button.attr('data-filedata');
                        fn.getFile( url, method, null, { title: getMessage.FTE00185, ext: 'zip'}).then(function( file ){
                            const fileName = fn.cv( file.name, '');
                            fn.download('file', file, fileName );
                        }).catch(function( error ){
                            if ( error !== 'break') {
                                alert( error.message );
                                window.console.error( error );
                            }
                        }).then(function(){
                            $button.prop('disabled', false );
                        });
                    } break;
                    case 'modal': {
                        $button.prop('disabled', true );
                        const modalType = $button.attr('data-modal'),
                              dataId = $button.attr('data-id'),
                              buttonText = $button.text();
                        tb.actionModalOpen( modalType, dataId, buttonText ).then(function(){
                            $button.prop('disabled', false );
                        });
                    } break;
                    case 'restapi':
                    case 'restapi_redirect': {
                        $button.prop('disabled', true );
                        const text = $button.text(),
                              method = $button.attr('data-method'),
                              endpoint = $button.attr('data-restapi'),
                              option = {};

                        let body = $button.attr('data-body');
                        if ( body !== '') {
                            try {
                                body = JSON.parse( body );
                            } catch( error ) {
                                body = {};
                            }
                        }
                        if ( type === 'restapi_redirect') {
                            option.redirect = $button.attr('data-redirect');
                            option.redirect_key = $button.attr('data-redirect-key');
                        }
                        tb.restApi( text, method, endpoint, body, option ).then(function(){
                            $button.prop('disabled', false );
                        });
                    } break;
                }
            }
        });

        // 行選択チェックボックスの外がクリックされても変更する
        tb.$.thead.find('.tHeadRowSelect').on('click', function( e ){
            if ( !tb.checkWork ) {
                const $button = $( this ).find('.rowSelectButton');
                if ( !$( e.target ).closest('.rowSelectButton').length ) {
                    $button.focus().click();
                }
            }
        });
        const rowSelect = function( e ) {
            if ( !tb.checkWork ) {
                const $wrap = $( this ),
                      $check = ( $wrap.is('.tBodyTrRowSelect') )?
                          $wrap.find('.tBodyRowSelect').find('.tBodyRowCheck'):
                          $wrap.find('.tBodyRowCheck'),
                      checked = $check.prop('checked');

                if ( !$( e.target ).closest('.checkboxWrap').length ) {
                    $check.focus().prop('checked', !checked ).change();
                }
            }
        };
        const target = ( tb.mode === 'select' || tb.mode === 'execute')? '.tBodyTrRowSelect': '.tBodyRowSelect';
        tb.$.tbody.on('click', target, rowSelect );

        // 一括選択
        tb.$.thead.find('.rowSelectButton').on('click', function(){
            if ( !tb.checkWork && tb.data.count ) {
                const $button = $( this ),
                      selectStatus = $button.attr('data-select');

                tb.$.tbody.find('.tBodyRowCheck').each(function(){
                    const $check = $( this ),
                          checked = $check.prop('checked'),
                          id = $check.val();
                    if ( selectStatus === 'not' && checked === false ) $check.prop('checked', true ).change();
                    if ( ( selectStatus === 'all' || selectStatus === 'oneOrMore')
                        && checked === true ) $check.prop('checked', false ).change();
                });

                tb.checkSelectStatus();
            }
        });

        // 行選択チェックボックス
        tb.$.tbody.on('change', '.tBodyRowCheck', function(){

            if ( !tb.checkWork ) {
                const $check = $( this ),
                      checked = $check.prop('checked'),
                      id = $check.val(),
                      checkMode = ( tb.mode === 'edit')? 'edit': ( tb.mode === 'select')? 'select': 'view';

                if ( tb.mode === 'select') {
                    if ( checked ) {
                        if ( fn.typeof( tb.params.selectNameKey ) !== 'array') {
                            const selectName = $check.attr('data-selectname');
                            if ( selectName ) {
                                const item = {
                                    id: id,
                                    name: selectName
                                };
                                tb.select[tb.mode].push( item );
                            } else {
                                tb.select[tb.mode].push( id );
                            }
                        } else {
                            const checkItem = {
                                id: id,
                                parameter: {}
                            };
                            const findData = tb.data.body.find(function( data ){
                                return String( data.parameter[ tb.idNameRest ] ) === String( id );
                            });
                            if ( findData ) {
                                for ( const key of tb.params.selectNameKey ) {
                                    checkItem.parameter[ key ] = findData.parameter[ key ];
                                }
                            }
                            tb.select[tb.mode].push( checkItem );
                        }
                    } else {
                        const index = tb.select[tb.mode].findIndex(function( item ){
                            if ( fn.typeof( item ) === 'object') {
                                return item.id === id;
                            } else {
                                return item === id;
                            }
                        });
                        if ( index !== -1 ) {
                            tb.select[ checkMode ].splice( index, 1 );
                        }
                    }
                } else {
                    if ( checked ) {
                        const findData = tb.data.body.find(function( data ){
                            return String( data.parameter[ tb.idNameRest ] ) === String( id );
                        });
                        if ( findData ) {
                            tb.selectedData[ id ] = findData;
                        }
                        tb.select[ checkMode ].push( id );
                    } else {
                        const index = tb.select[ checkMode ].indexOf( id );
                        if ( index !== -1 ) {
                            tb.select[ checkMode ].splice( index, 1 );
                        }
                        if ( id in tb.selectedData === true ) {
                            delete tb.selectedData[ id ];
                        }
                    }
                }

                tb.checkSelectStatus();

                // メニューボタンを活性化
                if ( checkMode === 'edit' ) {
                    tb.editModeMenuCheck();
                } else if ( tb.mode === 'select') {
                    tb.selectModeMenuCheck();
                    tb.$.container.trigger(`${tb.id}selectChange`);
                } else if ( tb.mode === 'view') {
                    tb.viewModeMenuCheck();
                }
            }
        });
    }
    /*
    ------------------------------
    SELECT or EXECUTEモード
    ------------------------------
    */
    if ( ( tb.mode === 'select' && tb.params.selectType === undefined ) || tb.mode === 'execute') {
        // 行選択ラジオボタンの外がクリックされても変更する
        const radioRowSelect = function( e ) {
            if ( !tb.checkWork ) {
                const $wrap = $( this ),
                      $radio = ( $wrap.is('.tBodyTrRowSelect') )?
                          $wrap.find('.tBodyRowRadioSelect').find('.tBodyRowRadio'):
                          $wrap.find('.tBodyRowRadio'),
                      checked = $radio.prop('checked');

                if ( !checked ) {
                    if ( !$( e.target ).closest('.radioWrap').length ) {
                        $radio.focus().prop('checked', true ).change();
                    }
                } else {
                    $radio.focus();
                }
            }
        };
        const target = ( tb.mode === 'select' || tb.mode === 'execute')? '.tBodyTrRowSelect': '.tBodyRowRadioSelect';
        tb.$.tbody.on('click', target, radioRowSelect );

        // 行選択ラジオ
        tb.$.tbody.on('change', '.tBodyRowRadio', function(){
            if ( !tb.checkWork ) {
                const $radio = $( this ),
                      checked = $radio.prop('checked'),
                      id = $radio.val(),
                      name = $radio.attr('data-selectname');

                tb.select[tb.mode][0] = {
                    id: id,
                    name: name
                };

                if ( tb.params.selectOtherKeys ) {
                    tb.select[tb.mode][0].selectOtherKeys = {};
                    for ( const selectKey of tb.params.selectOtherKeys ) {
                        tb.select[tb.mode][0].selectOtherKeys[ selectKey ] = $radio.attr(`data-${selectKey}`);
                    }
                }

                tb.selectModeMenuCheck();
                tb.$.container.trigger(`${tb.id}selectChange`);
            }
        });
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   dashboard.js class Dashboard patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
function patch_dashboard(){
/*
##################################################
   setup
##################################################
*/
Dashboard.prototype.setup = function(){
    const db = this;
    
    // jQueryオブジェクトキャッシュ
    db.$ = {};
    db.$.window = $( window );
    db.$.body = $('body');
    db.$.target = $( db.target );
    
    db.$.target.addClass('dashboard-loading');
    
    // DashBoardデータの読み込み
    fn.fetch('/user/dashboard/').then(function( result ){
        db.info = result;
        db.scripts = {
            menu_group: WidgetMenuGroup,
            link_list: WidgetLinkList,
            pie_chart: WidgetPieChart,
            stacked_graph: WidgetStackedGraph,
            reserve_list: WidgetReserveList,
            image: WidgetImage
        };
        db.init();
    }).catch(function( error ){
        if ( error.message !== 'Failed to fetch') {
            window.console.error( error );
            alert( error.message );
        }
    });
}
/*
##################################################
   newWidget
##################################################
*/
Dashboard.prototype.newWidget = function( setId ) {
    const db = this;
    
    const scriptName = db.widgetInfo[ setId ].script_name,
            scriptClass = Dashboard.widgetScripts[ scriptName ];
    
    if ( scriptClass ) {
        db.instance[ setId ] = new db.scripts[ scriptName ](
            setId,
            db.widgetInfo[ setId ],
            db.widgetPosition,
            { col: db.maxColumn, row: db.maxColumn },
            db.info[ db.widgetInfo[ setId ].info_data_name ]
        );        
        
        const widgetId = db.widgetInfo[ setId ].widget_id;
        if ( db.widgetNumber[ widgetId ] === undefined ) db.widgetNumber[ widgetId ] = 0;
        db.widgetNumber[ widgetId ]++;
        
        const $widget = db.instance[ setId ].widget();
        
        if ( db.instance[ setId ].ready ) {
            $widget.ready(function(){
                db.instance[ setId ].ready();
            });
        }
        db.$.area.append( $widget );
        return $widget;
    } else {
        return false;
    }
}
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   conductor.js class Conductor patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
function patch_conductor(){
/*
##################################################
   Setup conductor
##################################################
*/
Conductor.prototype.setup = function() {
    const cd = this;

    const html = `
    <div id="${cd.createId('editor', false )}" class="editor conductor load-wait" data-editor-mode="${cd.mode}">
        <div class="editor-inner">
            <div class="editor-main">
                <div class="editor-menu">
                    ${cd.operationMenuHtml()}
                </div>
                <div class="editor-header">
                    <div class="editor-mode"></div>
                    <div class="editor-header-menu">
                        ${cd.headerHtml()}
                    </div>
                </div>
                <div class="editor-body">
                    <div class="editor-edit editor-block">
                        <div class="editor-block-inner">
                            ${cd.editViewHtml()}
                        </div>
                    </div>
                </div>
            </div>
            <div class="editor-panel editor-row-resize">
            </div>
        </div>
    </div>`;

    // jQueryオブジェクトキャッシュ
    cd.$ = {};
    cd.$.window = $( window );
    cd.$.body = $('body');
    cd.$.target = $( cd.target );

    cd.$.target.html( html );

    cd.$.editor = cd.$.target.find('.editor');
    cd.$.menu = cd.$.editor.find('.editor-menu');
    cd.$.header = cd.$.editor.find('.editor-header-menu');
    cd.$.panel = cd.$.editor.find('.editor-panel');
    cd.$.mode = cd.$.editor.find('.editor-mode');

    cd.$.main = cd.$.editor.find('.editor-main');
    cd.$.area = cd.$.editor.find('.canvas-visible-area'),
    cd.$.canvas = cd.$.editor.find('.canvas'),
    cd.$.artBoard = cd.$.editor.find('.art-board');
    cd.$.display = cd.$.target.find('.editor-display');

    // モードタイトル
    cd.modeTitleList = {
        edit: getMessage.FTE02133,
        view: getMessage.FTE02134,
        update: getMessage.FTE02135,
        confirmation: getMessage.FTE02136
    }

    const restApiUrls = [];

    if ( cd.mode === 'confirmation' && cd.id ) {
        // 作業確認モード：インスタンスIDがある場合
        restApiUrls.push(`/menu/${cd.menu}/conductor/info/${cd.id}/`);
        restApiUrls.push(`/menu/${cd.menu}/conductor/${cd.id}/`);
    } else if ( cd.mode === 'confirmation') {
        // 作業確認モード：インスタンスIDがない場合待機状態にする
        const href = fn.createPageUrl('conductor_list');
        cd.$.editor.addClass('conductorInstanceIdStandBy');
        cd.$.header.remove();
        cd.$.editor.removeClass('load-wait');
        cd.$.mode.text( cd.modeTitleList[ cd.mode ] );
        cd.$.main.append(`<div class="editor-message"><div class="conductorInstanceIdStandByMessage"><span class="icon icon-circle_info"></span>
        ` + getMessage.FTE02001 + `<br>
        ` + getMessage.FTE02002 + `<br>
        <a href="${href}">` + getMessage.FTE02003 + `</a>` + getMessage.FTE02004 + `</div></div>`);
        cd.confirmationEvents();
        return false;
    } else {
        // 編集・作業実行モード
        restApiUrls.push(`/menu/${cd.menu}/conductor/class/info/`);
        if ( cd.id ) {
            restApiUrls.push(`/menu/${cd.menu}/conductor/class/${cd.id}/`);
        }
    }

    fn.fetch( restApiUrls ).then(function( result ){
        cd.init( result[0], result[1] );
    }).catch(function( error ){
        if ( error.message ) {
            if ( error.message !== 'Failed to fetch') {
                alert( error.message );
            }
        }
        console.error( error );
        window.location.href = fn.createPageUrl( cd.menu );
    });
}
/*
##################################################
   init
##################################################
*/
Conductor.prototype.init = function( info, conductorData ) {
    const cd = this;

    cd.info = info;

    // 設定値
    cd.setting = {
        debug: false,
        setStorage: false
    };

    // デバッグモード
    if ( fn.getParams().debug === 'true') cd.setting.debug = true;

    // ID 連番用
    cd.count = {
        node: 1,
        terminal: 1,
        edge: 1
    };

    if ( cd.mode === 'confirmation') {
        if ( conductorData.conductor_class && Object.keys( conductorData.conductor_class ).length === 0 ) {
            alert(getMessage.FTE02018 + `[ ${cd.id} ]` + getMessage.FTE02028);
            window.location.href = fn.createPageUrl('conductor_confirmation');
            return false;
        }
        cd.data = conductorData.conductor_class;
        cd.confirmation = {
            conductor: conductorData.conductor,
            node: conductorData.node
        };

        // 作業実行確認
        cd.$.window.one('conductorDrawEnd', function(){
            cd.initConductorStatus();
        });
    } else {
        // Conductor構造データ
        if ( conductorData ) {
            cd.data = conductorData;
            cd.original = $.extend( true, {}, conductorData );
        } else {
            cd.setInitialConductorData();
        }
    }

    // 読み込み完了
    cd.$.editor.removeClass('load-wait');

    // キャンバス初期設定
    cd.initCanvas();

    // SVGエリア初期設定
    cd.initSvgArea();

    // パネル初期設定
    cd.initPanel();

    // モードセット
    cd.conductorMode( cd.mode );

    // ノード初期設定
    cd.initNode();

    if ( cd.mode !== 'confirmation') {
        // 履歴初期設定
        cd.initHistory();
    }

    const temp = fn.storage.get('conductor-edit-temp');

    // 初期表示
    if ( conductorData ) {
        cd.loadConductor();
    } else if ( temp ) {
        cd.message('info', getMessage.FTE02162 );
        cd.loadConductor( temp );
    } else {
        cd.InitialSetNode();
    }

    // 基本イベント
    cd.initEvents();
    cd.rowResize();

}
/*
##################################################
   基本イベント
##################################################
*/
Conductor.prototype.initEvents = function() {
    const cd = this;

    // --------------------------------------------------
    // エディタタブ
    // --------------------------------------------------
    cd.$.editor.find('.editor-tab').each( function() {

        const $tab = $( this ),
              $tabItem = $tab.find('.editor-tab-menu-item'),
              $tabBody = $tab.find('.editor-tab-body');

        $tabItem.eq(0).addClass('selected');
        $tabBody.eq(0).addClass('selected');

        $tabItem.on('click', function() {
          const $clickTab = $( this ),
                $openTab = cd.$.panel.find('.' + $clickTab.attr('data-tab') );

          $tab.find('.selected').removeClass('selected');
          $clickTab.add( $openTab ).addClass('selected');
        });

    });

    // --------------------------------------------------
    // 新規登録時のみ、ページを移動する際に
    // ローカルストレージに保存する
    // --------------------------------------------------
    cd.$.window.on('beforeunload.conductor', function( e ){
        if ( cd.mode === 'edit') {
            cd.saveConductor( cd.data );
        }
        // 変更がある場合、離脱を確認する
        if ( cd.mode === 'edit' || cd.mode === 'update') {
            if ( cd.history.counter > 0 ) {
                e.preventDefault();
                return '';
            }
        }
    });

    // --------------------------------------------------
    // メニューボタン
    // --------------------------------------------------
    cd.$.menu.on('click', '.operationMenuButton', function(){
      const $button = $( this ),
            type = $button.attr('data-type');

      cd.nodeDeselect();
      cd.panelChange();

      switch( type ) {
          // コンダクター作業実行
          case 'execute':
              cd.menuButtonDisabled( true );

              const executeConfig = {
                  title: getMessage.FTE02009,
                  itemName: 'Conductor',
                  selectName: cd.data.conductor.conductor_name,
                  selectId: cd.id,
                  operation: {
                      selectNameKey: 'operation_name',
                      info: `/menu/${cd.menu}/conductor/execute/info/`,
                      filter: `/menu/${cd.menu}/conductor/execute/filter/operation_list/`,
                      filterPulldown: `/menu/${cd.menu}/conductor/execute/filter/operation_list/search/candidates/`,
                      sub: 'operation_list'
                  }
              };

              fn.executeModalOpen('conductor_execute', cd.menu,  executeConfig ).then(function( result ){
                  if ( result === 'cancel') {
                      cd.menuButtonDisabled( false );
                  } else {
                      const executeData = {
                          conductor_class_name: cd.data.conductor.conductor_name,
                          operation_name: result.name,
                          conductor_data: cd.data
                      };
                      if ( result.schedule ) {
                          executeData.schedule_date = result.schedule;
                      }
                      fn.fetch(`/menu/${cd.menu}/conductor/execute/`, null, 'POST', executeData ).then(function( exeResult ){
                            const href = fn.createPageUrl('conductor_confirmation', {
                                conductor_instance_id: exeResult.conductor_instance_id
                            })
                            window.location.href = href;
                      }).catch(function( error ){
                          cd.menuButtonDisabled( false );
                          fn.messageClear();
                          cd.message('danger', getMessage.FTE02029, error.message );
                      });
                  }
              });
          break;
          // コンダクター新規登録
          case 'registration':
              cd.menuButtonDisabled( true );
              fn.iconConfirm('plus', getMessage.FTE10059, getMessage.FTE02030 ).then(function( flag ){
                  if ( flag ) {
                      fn.fetch(`/menu/${cd.menu}/conductor/class/maintenance/`, null, 'POST', cd.data ).then(function( result ){
                          cd.fetchConductor( result.conductor_class_id ).then(function(){
                              cd.menuButtonDisabled( false );
                              cd.conductorMode('view');
                              fn.messageClear();
                              cd.message('success', getMessage.FTE02031);
                              //fn.storage.remove('conductor-edit-temp');
                          });
                      }).catch(function( error ){
                          cd.menuButtonDisabled( false );
                          fn.messageClear();
                          cd.message('danger', getMessage.FTE02032, error.message );
                      });
                  } else {
                    cd.menuButtonDisabled( false );
                  }
              });
          break;
          // 登録済みコンダクターを選択し表示する
          case 'selectConductor': {
              cd.menuButtonDisabled( true );
              cd.selectModalOpen('conductor').then(function( select ){
                  if ( select && select.length ) {
                      cd.fetchConductor( select[0].id ).then(function( result ){
                          cd.menuButtonDisabled( false );
                          cd.conductorMode('view');
                          fn.messageClear();
                          cd.message('success', getMessage.FTE02033);
                      });
                  } else {
                      cd.menuButtonDisabled( false );
                  }
              });
          } break;
          case 'edit':
              cd.conductorMode('update');
          break;
          case 'reset':
              cd.menuButtonDisabled( true );
              fn.iconConfirm('return', getMessage.FTE10059, getMessage.FTE02034 ).then(function( flag ){
                  if ( flag ) {
                      cd.clearConductor();
                      cd.InitialSetNode();
                      fn.messageClear();
                      cd.message('info', getMessage.FTE02035);
                  }
                  cd.menuButtonDisabled( false );
              });
          break;
          case 'diversion':
            // 流用しますか？
            cd.menuButtonDisabled( true );
            fn.iconConfirm('copy', getMessage.FTE10059, getMessage.FTE02036 ).then(function( flag ){
                if ( flag ) {
                    // 流用する場合は下記の項目はnullに
                    cd.data.conductor.id = null;
                    cd.data.conductor.last_update_date_time = null;
                    cd.data.conductor.conductor_name = null;
                    cd.data.conductor.note = null;

                    cd.conductorMode('edit');
                    cd.panelChange();

                    history.replaceState( null, null, fn.createPageUrl('conductor_class_edit'));
                    fn.messageClear();
                    cd.message('info', getMessage.FTE02037);
                }
                cd.menuButtonDisabled( false );
            });
            break;
          case 'new':
              cd.clearConductor();
              cd.InitialSetNode();

              cd.conductorMode('edit');
              cd.panelChange();

              history.replaceState( null, null, fn.createPageUrl('conductor_class_edit'));
          break;
          case 'update':
              // 更新しますか？
              cd.menuButtonDisabled( true );
              fn.iconConfirm('update02', getMessage.FTE10059, getMessage.FTE02038 ).then(function( flag ){
                  if ( flag ) {
                      cd.menuButtonDisabled( true );
                      fn.fetch(`/menu/${cd.menu}/conductor/class/maintenance/${cd.id}/`, null, 'PATCH', cd.data ).then(function(result){
                          cd.fetchConductor( result.conductor_class_id ).then(function(){
                              cd.menuButtonDisabled( false );
                              cd.conductorMode('view');
                              fn.messageClear();
                              cd.message('success', getMessage.FTE02039);
                          });
                      }).catch(function( error ){
                          cd.menuButtonDisabled( false );
                          fn.messageClear();
                          cd.message('danger', getMessage.FTE02040, error.message );
                      });
                  }
                  cd.menuButtonDisabled( false );
              });
          break;
          // 編集中データ再読み込み
          case 'refresh':
              cd.menuButtonDisabled( true );
              fn.iconConfirm('update01', getMessage.FTE10059, getMessage.FTE02041 ).then(function( flag ){
                  if ( flag ) {
                      cd.menuButtonDisabled( true );
                      cd.fetchConductor( cd.id ).then(function( result ){
                          cd.menuButtonDisabled( false );
                          fn.messageClear();
                          cd.message('success', getMessage.FTE02042);
                      });
                  }
                  cd.menuButtonDisabled( false );
              });
            break;
          // 編集をキャンセルする
          case 'cancel':
              cd.selectConductor( cd.original );
              cd.conductorMode('view');
          break;
          // 予約取消
          case 'canselInstance':
              fn.iconConfirm('stop', getMessage.FTE10059, getMessage.FTE02043 ).then(function( flag ){
                  if ( flag ) {
                      cd.menuButtonDisabled( true );
                      cd.cancelInstance();
                  }
              });
              break;
          // 緊急停止
          case 'scramInstance':
              fn.iconConfirm('cal_off', getMessage.FTE10059, getMessage.FTE02044 ).then(function( flag ){
                  if ( flag ) {
                      cd.menuButtonDisabled( true );
                      cd.scramInstance();
                  }
              });
              break;
          // 画面フルスクリーン
          case 'fullscreen':
              cd.fullScreen();
          break;
        }
    });

    // --------------------------------------------------
    // フルスクリーン切り替え時のイベントを追加する
    // --------------------------------------------------
    document.onfullscreenchange = document.onmozfullscreenchange = document.onwebkitfullscreenchange = document.onmsfullscreenchange = function () {
        if( cd.fullScreenCheck() ){
            cd.$.body.addClass('editor-full-screen');
        } else {
            cd.$.body.removeClass('editor-full-screen');
        }
        cd.nodeViewAll( 0 );
    }

    // --------------------------------------------------
    // エディタボタン
    // --------------------------------------------------
    cd.$.header.on('click', '.editor-menu-button', function(){

        const $button = $( this ),
              buttonType = $button.attr('data-menu'),
              buttonDisabledTime = 300;

        switch ( buttonType ) {
          case 'conductor-save':
            fn.download('json', cd.data, cd.data['conductor'].conductor_name );
            break;
          case 'conductor-read':
            fn.fileSelect('json').then(function( result ){

                // IDと日時はリセット
                result.json.conductor.id = null;
                result.json.conductor.last_update_date_time = null;

                cd.selectConductor( result.json );
            });
            break;
          case 'undo':
            cd.conductorHistory().undo();
            break;
          case 'redo':
            cd.conductorHistory().redo();
            break;
          case 'node-delete':
            cd.conductorHistory().nodeRemove( cd.select );
            cd.nodeRemove( cd.select );
            break;
          case 'view-all':
            cd.nodeViewAll( 0 );
            break;
          case 'view-reset':
            cd.canvasPositionReset();
            break;
        }
        // Undo Redoは別管理
        if ( ['undo','redo'].indexOf( buttonType ) === -1 ) {
            // 一定時間ボタンを押せなくする
            $button.prop('disabled', true );

            if ( buttonType !== 'node-delete' ) {
                $button.addClass('active');
                // buttonDisabledTime ms 後に復活
                setTimeout( function(){
                    $button.removeClass('remove').prop('disabled', false );
                }, buttonDisabledTime );
            }
        }
    });

    // --------------------------------------------------
    // 作業確認
    // --------------------------------------------------
    if ( cd.mode === 'confirmation') {
        cd.confirmationEvents();
    }

    // --------------------------------------------------
    // エディタオプション
    // --------------------------------------------------

    cd.$.header.on('change', '#conductor-grid-snap-check', function(){
        if ( cd.mode === 'edit' || cd.mode === 'update') {
            cd.data.conductor.grid_snap = $( this ).prop('checked');
        }
    });

    // --------------------------------------------------
    // 操作説明
    // --------------------------------------------------
    cd.$.display.on('click', '.editor-explanation-toggle-button', function(){
        const $container = cd.$.display.find('.editor-explanation-container');
        $container.toggleClass('explanationOpen');
        if ( $container.is('.explanationOpen') ) {
            fn.storage.remove('conductorExplanation', 'local', false );
        } else {
            fn.storage.set('conductorExplanation', true, 'local', false );
        }
    });

}
/*
##################################################
   作業確認用イベント
##################################################
*/
Conductor.prototype.confirmationEvents = function() {
    const cd = this;

    // --------------------------------------------------
    // 作業確認
    // --------------------------------------------------
    cd.$.menu.on('click', '.operationMenuButton[data-type="work-confirm"]', function(){
        const instanceId = cd.$.menu.find('.inputConductorInstanceId').val();
        const href = fn.createPageUrl('conductor_confirmation', {
            conductor_instance_id: instanceId
        })
        window.location.href = href;
    });
    // --------------------------------------------------
    // 作業確認　インスタンスＩＤ入力時ボタン有効無効化
    // --------------------------------------------------
    cd.$.menu.on('input', '.inputConductorInstanceId', function(){
        const val = $( this ).val(),
              $button = cd.$.menu.find('.operationMenuButton[data-type="work-confirm"]');
        if ( val === '') {
            $button.prop('disabled', true );
        } else {
            $button.prop('disabled', false );
        }
    });
    cd.$.menu.find('.inputConductorInstanceId').trigger('input');
}
/*
##################################################
   Node作成
##################################################
*/
Conductor.prototype.createNode = function( nodeID ) {
    const cd = this;

    const nodeData = cd.data[ nodeID ],
          nodeText = cd.setting.nodeText;

    let nodeHTML = '',
        typeCheck = [],
        nodeClass = ['node'],
        attrData = [];

    if ( nodeData.type !== 'movement') {
        nodeClass.push( nodeText[ nodeData.type ][ 3 ] );
    }

    // Merge
    if ( nodeData.type === 'merge') {
        const terminalIDList = cd.terminalInOutID( nodeData.terminal, 'in'),
              terminalLength = terminalIDList.length;
        nodeHTML += '<div class="node-merge">'
        for ( let i = 0; i < terminalLength; i++ ) {
            nodeHTML += '<div class="node-sub">' + cd.createTerminalHTML('in', terminalIDList[ i ] );

            // Merge status
            nodeHTML += cd.mergeStatusHTML();

            nodeHTML += '<div class="branch-cap branch-out"></div></div>';
        }
        nodeHTML += '</div>'
        + '<div class="branch-line"><svg></svg></div>';
    }

    // Node main
    nodeHTML += '<div class="node-main">';

    // Terminal in CAP
    typeCheck = ['start', 'merge'];
    if ( typeCheck.indexOf( nodeData.type ) !== -1 ) {
        nodeHTML += cd.createTerminalHTML('in');
    } else {
      const terminalInID = cd.terminalInOutID( nodeData.terminal, 'in');
        nodeHTML += cd.createTerminalHTML('in', terminalInID[0] );
    }

    // Node body
    nodeHTML += '<div class="node-body">';

    let nodeCircle, nodeType, nodeName;
    if ( nodeData.type === 'movement') {
        nodeClass.push('movement');
        nodeName = cd.getMovementName( nodeData.movement_id );

        if ( cd.mode !== 'confirmation') {
            // Movementが存在するか確認する
            const movementData = cd.info.list.movement.find(function( m ){
                return nodeData.movement_id === m.id;
            });
            // Movementデータから名称をセット
            if ( movementData !== undefined ) {
                nodeData.orchestra_id = movementData.orchestra_id;
                nodeData.movement_name = movementData.name;
                nodeCircle = cd.setting.movementCircleText[ movementData.orchestra_id ];
                nodeType = cd.getOrchestratorName( movementData.orchestra_id );
            } else {
                // 見つからない場合
                nodeData.orchestra_id = 0;
                nodeData.movement_name = 'Unknown';
                nodeCircle = '?';
            }

        } else {
            nodeType = cd.getOrchestratorName( nodeData.orchestra_id );
            nodeCircle = cd.setting.movementCircleText[ nodeData.orchestra_id ];
        }
        if ( !nodeName ) nodeName = 'Unknown';
        if ( !nodeType ) nodeType = 'Unknown';
        if ( !nodeCircle ) nodeCircle = 'Mv';
        nodeClass.push('node-' + nodeType.toLocaleLowerCase().replace(/\s|\//g, '-') );
    } else {
        nodeCircle = nodeText[ nodeData.type ][0];
        nodeType = nodeText[ nodeData.type ][1];
        nodeName = nodeText[ nodeData.type ][2];
    }

    if ( nodeData.type === 'end') {
        const endStatus = cd.status.end[ cd.data[ nodeID ].end_type ][1],
              endID = cd.status.end[ cd.data[ nodeID ].end_type ][0];
        if ( cd.data[ nodeID ].end_type !== '6') {
            nodeName += ' : ' + endStatus;
        }
        attrData.push('data-end-status="' + endID + '"');
    }

    // Node circle & Node type
    typeCheck = ['start', 'end', 'movement', 'call'];
    if ( typeCheck.indexOf( nodeData.type ) !== -1 ) {
        nodeHTML += ''
        + '<div class="node-circle">'
          + '<span class="node-gem"><span class="node-gem-inner node-gem-length-' + nodeCircle.length + '">' + nodeCircle + '</span></span>'
          + '<span class="node-running"></span>'
          + '<span class="node-result" data-result-text="" data-href="#"></span>'
          + '<span class="node-end-status"><span class="node-end-status-inner"></span></span>'
        + '</div>'
        + '<div class="node-type"><span>' + nodeType + '</span></div>';
    }
    // Node name
    typeCheck = ['start', 'end', 'movement'];
    if ( typeCheck.indexOf( nodeData.type ) !== -1 ) {
        let nodeNameHtml;
        if ( cd.setting.movementMenuLink && nodeData.type === 'movement') {
            const linkData = cd.setting.movementMenuLink[ nodeData.orchestra_id ];
            const linkFilter = {};
            linkFilter[ linkData.column ] = {
                LIST: [ nodeName ]
            };
            const href = fn.createPageUrl( linkData.menu, {
                filter: fn.filterEncode(linkFilter)
            })
            const link = href;
            nodeNameHtml = `<a class="node-link" draggable="false" href="${link}">${fn.cv( nodeName, '', true )}</a>`;
        } else {
            nodeNameHtml = `<span>${fn.cv( nodeName, '', true )}</span>`;
        }
        nodeHTML += `<div class="node-name">${nodeNameHtml}</div>`;
    }
    if ( nodeData.type === 'call' ) {
        const callConductorId = nodeData['call_conductor_id'];
        if ( callConductorId !== undefined && callConductorId !== null ) {
            nodeClass.push('call-select');
            nodeName = cd.getConductorName( callConductorId );
        }
        nodeHTML += ``
        + `<div class="node-name">`
            + `<span class="select-conductor-name">`
                + `<span class="select-conductor-name-inner">${fn.cv( nodeName, '', true )}</span>`
            + `</span>`
        + `</div>`;
    }

    // Pause
    if ( nodeData.type === 'pause' ) {
      nodeHTML += cd.pauseStatusHTML();
    }

    // Status file
    if ( nodeData.type === 'status-file-branch' ) {
      nodeHTML += '<div class="node-type"><span>Status file</span></div>'
        + '<div class="node-name">'
          + '<span class="status-file-result"><span class="status-file-result-inner"></span></span>'
        + '</div>';
    }

    // Node body END
    nodeHTML += '</div>';

    // Terminal out CAP
    typeCheck = ['end', 'parallel-branch', 'conditional-branch', 'status-file-branch'];
    if ( typeCheck.indexOf( nodeData.type ) !== -1 ) {
        nodeHTML += cd.createTerminalHTML('out');
    } else {
        const terminalOutID = cd.terminalInOutID( nodeData.terminal, 'out');
        nodeHTML += cd.createTerminalHTML('out', terminalOutID[0] );
    }

    // Node main END
    nodeHTML += '</div>';

    // Branch
    typeCheck = ['parallel-branch', 'conditional-branch', 'status-file-branch'];
    if ( typeCheck.indexOf( nodeData.type ) !== -1 ) {
      nodeHTML += '<div class="branch-line"><svg></svg></div>'
      + '<div class="node-branch">';
      const terminalIDList = cd.terminalInOutID( nodeData.terminal, 'out'),
            terminalLength = terminalIDList.length;
      let caseNumberHTML = {};
      for ( let i = 0; i < terminalLength; i++ ) {
          let conditionList = nodeData.terminal[ terminalIDList[ i ] ].condition,
              caseNumber = nodeData.terminal[ terminalIDList[ i ] ].case;

          if ( caseNumber === undefined ) caseNumber = 'undefined' + i;

          if ( conditionList !== undefined && Number( conditionList[0] ) === 9999 ) {
              caseNumberHTML[ caseNumber ] = '<div class="node-sub default">';
          } else if ( nodeData.terminal[ terminalIDList[ i ] ].case === 'else') {
              caseNumberHTML[ caseNumber ] = '<div class="node-sub default">';
          } else {
              caseNumberHTML[ caseNumber ] = '<div class="node-sub">';
          }
          caseNumberHTML[ caseNumber ] += '<div class="branch-cap branch-in"></div>';

          // ムーブメント結果条件
          if ( nodeData.type === 'conditional-branch' ) {
              const conditionLength = conditionList.length;
              caseNumberHTML[ caseNumber ] += '<div class="node-body">'
              + '<div class="branch-type"><ul>';
              for ( let j = 0; j < conditionLength; j++ ) {
                  const conditionID = conditionList[ j ];
                  let conditionClass = cd.status.movement[ conditionID ][0];
                  caseNumberHTML[ caseNumber ] += '<li class="' + conditionClass + '" data-end-status="' + conditionID + '">' + cd.status.movement[ conditionID ][1] + '</li>';
              }
              caseNumberHTML[ caseNumber ] += '</ul></div>'
              + '</div>';
          }
          // ステータスファイル分岐
          if ( nodeData.type === 'status-file-branch' ) {
              if ( conditionList === undefined ) conditionList = [''];
              caseNumberHTML[ caseNumber ] += cd.statuFileBranchBodyHTML( caseNumber, (caseNumber === 'else')? true: false, conditionList.join('') );
          }
          caseNumberHTML[ caseNumber ] += cd.createTerminalHTML('out', terminalIDList[ i ] ) + '</div>';
      }

      for ( const html in caseNumberHTML ) {
        nodeHTML += caseNumberHTML[html];
      }
      nodeHTML += '</div>';
    }

    // Note
    let noteText = nodeData['note'];
    if ( noteText !== undefined && noteText !== null && noteText !== '') {
        noteText = fn.escape( noteText, true );
        nodeHTML += '<div class="node-note note-open"><div class="node-note-inner"><p>' + noteText + '</p></div></div>';
    } else {
        nodeHTML += '<div class="node-note"><div class="node-note-inner"><p></p></div></div>';
    }

    // Skip, Status, Operation
    typeCheck = ['movement', 'call', 'call_s'];
    if ( typeCheck.indexOf( nodeData.type ) !== -1 ) {
      // Default skip
      let nodeCheckedType = '',
          skipFlag = false;
      // 個別Operation
      let nodeOperationData = '',
          selectOperationID = '',
          selectOperationName = '';
      // 作業確認の場合はステータス情報を参照する
      if ( cd.mode === 'confirmation') {
          skipFlag = ( cd.confirmation.node[ nodeID ].skip === 'True') ? true : false;
          selectOperationID = cd.confirmation.node[ nodeID ].operation_id;
          selectOperationName = cd.confirmation.node[ nodeID ].operation_name;
      } else {
          skipFlag = ( Number( nodeData.skip_flag ) === 1 ) ? true : false;
          selectOperationID = nodeData['operation_id'];
          selectOperationName = cd.getOperationName( selectOperationID );
      }

      if ( skipFlag ) {
          nodeCheckedType = ' checked';
          nodeClass.push('skip');
      }
      if ( selectOperationID !== undefined && selectOperationID !== null ) {
        nodeClass.push('operation');
        nodeOperationData = selectOperationName;
      }
      nodeHTML += ''
      + '<div class="node-skip"><input class="node-skip-checkbox" tabindex="-1" type="checkbox"' + nodeCheckedType + '><label class="node-skip-label">Skip</label></div>'
      + '<div class="node-operation">'
        + '<dl class="node-operation-body">'
          + '<dt class="node-operation-name">OP</dt>'
          + '<dd class="node-operation-data">' + fn.cv( nodeOperationData, '', true ) + '</dd>'
        + '</dl>'
        + '<div class="node-operation-border"></div>'
      + '</div>'
      + '<div class="node-status"><p></p></div>';
    }

    // Node wrap
    nodeHTML = '<div id="' + cd.createId( nodeID, false ) + '" data-id="' + nodeID + '" class="' + nodeClass.join(' ') + '" ' + attrData.join(' ') + '>' + nodeHTML + '</div>';

    return $( nodeHTML );

}
/*
##################################################
  指定のIDのコンダクターを読み込む
##################################################
*/
Conductor.prototype.fetchConductor = function( conductorId ) {
    const cd = this;

    let process = fn.processingModal( getMessage.FTE02161 );

    return new Promise(function( resolve ){
        const urls = [
            `/menu/${cd.menu}/conductor/class/${conductorId}/`,
            `/menu/${cd.menu}/conductor/class/info/`
        ];
        fn.fetch( urls ).then(function( result ){
            cd.id = conductorId;
            cd.selectConductor( result[0] );
            cd.info = result[1];
            const href = fn.createPageUrl('conductor_class_edit', {
                conductor_class_id: conductorId
            })
            history.replaceState( null, null, href );
        }).catch(function(){
            alert(getMessage.FTE02127);
        }).then(function(){
            process.close();
            process = null;

            resolve();
        });
    });
}
/*
##################################################
   noticeModalOpen
##################################################
*/
Conductor.prototype.noticeModalOpen = function() {
    const cd = this;

    // 通知先があるかチェック
    const notice = cd.info.list.notice_info,
          noticeLength = notice.length;

    if ( noticeLength === 0 ) {
        fn.iconConfirm('circle_info', getMessage.FTE02165, getMessage.FTE02164, getMessage.FTE02166, getMessage.FTE02167 ).then(function( flag ){
            if ( flag ) {
                window.location.href = fn.createPageUrl('conductor_notice_definition');
            }
        });
    } else {

        if ( cd.notice.modal ) {
            const noticeInfo = cd.data.conductor.notice_info;
            cd.notice.modal.show();

            // チェック状態をセット
            cd.notice.modal.$.dbody.find('.noticeCheck').each(function(){
                const $check = $( this ),
                      val = $check.val(),
                      notice = $check.attr('data-notice');
                if ( noticeInfo[ notice ] && noticeInfo[ notice ].indexOf( val ) !== -1 ) {
                    $check.prop('checked', true );
                } else {
                    $check.prop('checked', false );
                }
            });
        } else {
            // モーダル表示
            const config = {
                mode: 'modeless',
                position: 'center',
                width: 'auto',
                header: {
                    title: getMessage.FTE02168,
                },
                footer: {
                    button: {
                        ok: { text: getMessage.FTE02169, action: 'default', width: '120px'},
                        cancel: { text: getMessage.FTE02170, action: 'normal', width: '120px'},
                    }
                }
            };

            // モーダルOK、キャンセル
            const funcs = {
                ok: function() {
                    cd.data.conductor.notice_info = {};
                    cd.notice.modal.$.dbody.find('.noticeCheck:checked').each(function(){
                        const $check = $( this ),
                              key = $check.attr('data-notice'),
                              val = $check.val();
                        if ( !cd.data.conductor.notice_info[ key ] ) cd.data.conductor.notice_info[ key ] = [];
                        cd.data.conductor.notice_info[ key ].push( val );
                        cd.panelChange();
                    });
                    cd.notice.modal.hide();
                },
                cancel: function() {
                    cd.notice.modal.hide();
                },
            };

            cd.notice.modal = new Dialog( config, funcs );
            cd.notice.modal.open( cd.noticList() );

            // 見出しの幅を調整する
            cd.notice.modal.$.dbody.find('.noticeStatusNameInner').each(function(){
                const $text = $( this ),
                      sWidth = $text.get(0).scrollWidth,
                      cWidth = $text.closest('.noticeStatusName').get(0).offsetWidth;
                if ( cWidth < sWidth ) {
                    $text.css('transform', 'scaleX(' + ( cWidth / sWidth ) + ')')
                } else {
                    $text.removeAttr('style');
                }
            });

            // チェックボックスの外がクリックされても変更する
            cd.notice.modal.$.dbody.find('.tbody').on('click', '.noticeStatusCheckTd', function( e ){
                const $button = $( this ).find('.noticeCheck');
                if ( !$( e.target ).closest('.checkboxWrap').length ) {
                    $button.focus().click();
                }
            });
        }

    }
}
/*
##################################################
  作業状況確認
##################################################
*/
Conductor.prototype.executeCheckJump = function( $element ) {
    const cd = this;

    const type = $element.attr('data-type');
    switch ( type ) {
        // 読み出しコンダクターをモーダルで表示する
        case 'call': {
            const callId = $element.attr('data-id');
            fn.modalConductor( cd.menu, 'confirmation', callId );
        } break;
        case 'movement': {
            const menu = $element.attr('data-menu'),
                  execution_no = $element.attr('data-id');
            if ( menu && execution_no ) {
                const sys_id = fn.getParams().sys_id;
                fn.modalIframe( menu + '&sys_id=' + sys_id + '&execution_no=' + execution_no, getMessage.FTE02128, { width: '960px'} );
            }
        } break;
        //
        default:
            const href = encodeURI( $element.attr('data-href') );
            if ( href !== '#') {
                window.open('?' + href, '_brank');
            }
    }
}
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   operation_status.js class Status patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
function patch_operation_status(){
/*
##################################################
    Setup conductor
##################################################
*/
Status.prototype.setup = function() {
    const op = this;

    fn.contentLoadingStart();

    op.$ = {};
    op.$.content = $('#content');
    op.$.operation = $('#operationStatus').find('.sectionBody');
    op.$.executeLog = $('#executeLog').find('.sectionBody');
    op.$.errorLog = $('#errorLog').find('.sectionBody');

    op.$.tab = op.$.content.find('.contentMenu');
    op.$.executeTab = op.$.tab.find('.executeLogTab');
    op.$.errorTab = op.$.tab.find('.errorLogTab');

    op.setRestApiUrls();

    // ドライバータイプ
    if ( op.menu.match('_ansible_') ) {
        op.driver = 'ansible';
    } else if ( op.menu.match('_terraform_cli') ) {
        op.driver = 'terraform_cli';
    } else if ( op.menu.match('_terraform_cloud_ep') ) {
        op.driver = 'terraform_cloud_ep';
    } else {
        op.driver = null;
    }

    if ( op.rest.info ) {
        const href = fn.createPageUrl( op.menu, {
            execution_no: op.id
        })
        history.replaceState( null, null, href );
        fn.fetch( op.rest.info ).then(function( info ){
            op.info = info;
            op.operationStatusInit();
            op.operationStatus();
            op.logInit()

            // status_monitoring_cycleごとに更新
            op.monitoring();

        }).catch(function( error ){
            if ( error.message !== 'Failed to fetch') {
                alert( error.message );
                window.location.href = fn.createPageUrl( op.menu );
            }
        }).then(function(){
            fn.contentLoadingEnd();
        });
    } else {
        history.replaceState( null, null, fn.createPageUrl( op.menu ));
        op.operationStatusInit();
        op.operationMessage();
        fn.contentLoadingEnd();
    }
}
/*
##################################################
    Operation message
##################################################
*/
Status.prototype.operationMessage = function() {
    const op = this;

    const href = fn.createPageUrl( Status.string[op.menu].executionListMenu );
    const html = `<div class="contentMessage">
        <div class="contentMessageInner">
            <span class="icon icon-circle_info"></span>` + getMessage.FTE05005 + `<br>
            ` + getMessage.FTE05006 + `<br>
            <a href="${href}">` + getMessage.FTE05007 + `</a>` + getMessage.FTE05008 + `
        </div>
    </div>`;

    op.$.operationContainer.html( html );
}
/*
##################################################
    Operation status
##################################################
*/
Status.prototype.operationStatus = function() {
    const op = this;

    let html = `<div class="commonSection"><div class="commonBlock">`;

    // 作業ステータス
    const workStatus = [
        {
            title: getMessage.FTE05001,
            type: 'execution_no'
        },
        {
            title: getMessage.FTE05010,
            type: 'execution_type'
        },
        {
            title: getMessage.FTE05011,
            type: 'status'
        }
    ];
    if ( op.driver === 'ansible') {
        workStatus.push({
            title: getMessage.FTE05012,
            type: 'execution_engine'
        });
    }
    workStatus.push(
        {
            title: getMessage.FTE05013,
            type: 'caller_conductor'
        },
        {
            title: getMessage.FTE05014,
            type: 'execution_user'
        },
        {
            title: getMessage.FTE05015,
            type: 'populated_data'
        },
        {
            title: getMessage.FTE05016,
            type: 'result_data'
        }
    );
    html += `<div class="commonTitle">${getMessage.FTE05009}</div>`
    + op.operationStatusTable( workStatus );

    // 作業状況
    const subStatus = [
        {
            title: getMessage.FTE05018,
            type: 'scheduled_date_time'
        },
        {
            title: getMessage.FTE05019,
            type: 'start_date_time'
        },
        {
            title: getMessage.FTE05020,
            type: 'end_date_time'
        }
    ];
    html += `<div class="commonSubTitle">${getMessage.FTE05017}</div>`
    + op.operationStatusTable( subStatus );

    // オペレーション
    const operation = [
        {
            title: getMessage.FTE05022,
            type: 'operation_id'
        },
        {
            title: getMessage.FTE05023,
            type: 'operation_name'
        }
    ];
    html += `<div class="commonTitle">${getMessage.FTE05021}</div>`
    + op.operationStatusTable( operation );

    // オペレーションボタン
    const operationButton = [];
    if ( op.driver === 'ansible') {
        operationButton.push({
            title: getMessage.FTE05024,
            type: 'host',
            disabled: 'disabled'
        });
    }
    operationButton.push({
        title: getMessage.FTE05025,
        type: 'value',
        disabled: 'disabled'
    });
    html += op.operationStatusButtonList( operationButton );

    html += `</div><div class="commonBlock">`;

    // Movememt
    html += `<div class="commonTitle">${getMessage.FTE05026}</div>`;

    html+= ``
    + `<div class="movementArea" data-mode="">`
        + `<div class="movementAreaInner">`
            + `<div class="node ${Status.string[op.menu].movementClassName}">`
                + `<div class="node-main">`
                    + `<div class="node-terminal node-in connected">`
                        + `<span class="connect-mark"></span>`
                        + `<span class="hole">`
                            + `<span class="hole-inner"></span>`
                        + `</span>`
                    + `</div>`
                    + `<div class="node-body">`
                        + `<div class="node-circle">`
                            + `<span class="node-gem">`
                                + `<span class="node-gem-inner">${Status.string[op.menu].movementGem}</span>`
                            + `</span>`
                            + `<span class="node-running"></span>`
                            + `<span class="node-result"></span>`
                        + `</div>`
                        + `<div class="node-type">`
                            + `<span>${Status.string[op.menu].movementType}</span>`
                        + `</div>`
                        + `<div class="node-name">`
                            + `<span class="operationStatusData" data-type="movement_name"></span>`
                        + `</div>`
                    + `</div>`
                    + `<div class="node-terminal node-out connected">`
                        + `<span class="connect-mark"></span>`
                        + `<span class="hole">`
                            + `<span class="hole-inner"></span>`
                        + `</span>`
                    + `</div>`
                + `</div>`
            + `</div>`
        + `</div>`
    + `</div>`;

    const movement = [
        {
            title: getMessage.FTE05022,
            type: 'movement_id'
        },
        {
            title: getMessage.FTE05023,
            type: 'movement_name'
        },
        {
            title: getMessage.FTE05027,
            type: 'delay_timer'
        }
    ];
    html += op.operationStatusTable( movement );

    // Movementボタン
    const movementButton = [
        {
            title: getMessage.FTE05028,
            type: 'movement'
        }
    ];
    html += op.operationStatusButtonList( movementButton );

    if ( op.driver === 'ansible') {
        // Ansible利用情報
        const ansibleInfo = [
            {
                title: getMessage.FTE05030,
                type: 'host_specific_format'
            },
            {
                title: getMessage.FTE05031,
                type: 'winrm_connection'
            },
            {
                title: getMessage.FTE05032,
                type: 'ansible_cfg'
            }
        ];
        html += `<div class="commonSubTitle">` + getMessage.FTE05029 + `</div>`
        + op.operationStatusTable( ansibleInfo );

        // Ansible Automation Controller利用情報
        const ansibleControllerInfo = [
            {
                title: getMessage.FTE05036,
                type: 'execution_environment'
            }
        ];
        html += `<div class="commonSubTitle">` + getMessage.FTE05035 + `</div>`
        + op.operationStatusTable( ansibleControllerInfo );

        // Ansibleエージェント利用情報
        const ansibleAgentInfo = [
            {
                title: getMessage.FTE05040,
                type: 'ansible_agent_execution_environment'
            }
        ];
        html += `<div class="commonSubTitle">` + getMessage.FTE05039 + `</div>`
        + op.operationStatusTable( ansibleAgentInfo );
    } else if ( op.driver === 'terraform_cloud_ep') {
        // Terraform利用情報
        const terraformInfo = [
            {
                title: `Organization:Workspace`,
                type: `organization_workspace`
            },
            {
                title: `RUN-ID`,
                type: `run_id`
            }
        ];
        html += `<div class="commonSubTitle">` + getMessage.FTE05038 + `</div>`
        + op.operationStatusTable( terraformInfo );
    } else if ( op.driver === 'terraform_cli') {
        // Terraform利用情報
        const terraformInfo = [
            {
                title: `Workspace`,
                type: `tf_workspace_name`
            }
        ];
        html += `<div class="commonSubTitle">` + getMessage.FTE05038 + `</div>`
        + op.operationStatusTable( terraformInfo );
    }
    html += `</div></div>`;
    op.$.operationContainer.html( html );

    op.$.movementArea = op.$.operationContainer.find('.movementArea');
    op.$.node = op.$.operationContainer.find('.node');

    // コンテンツボタン
    op.$.operationContainer.find('.commonButton').on('click', function(){
        const $button = $( this ),
                type = $button.attr('data-type'),
                target = { iframeMode: 'tableViewOnly'};
        switch ( type ) {
            case 'movement': {
                const movementId = fn.cv( op.info.execution_list.parameter.movement_id, '');
                target.title = getMessage.FTE05028;
                target.menu = Status.string[ op.menu ].movementListMenu;
                target.filter = { movement_id: { NORMAL: movementId } };
            } break;
            case 'host':
                target.title = getMessage.FTE05024;
                target.menu = Status.string[ op.menu ].targetHostMenu;
                target.filter = { execution_no: { NORMAL: op.id } };
            break;
            case 'value':
                target.title = getMessage.FTE05025;
                target.menu = Status.string[ op.menu ].substValueMenu;
                target.filter = { execution_no: { NORMAL: op.id } };
            break;
        }
        const sys_id = fn.getParams().sys_id;
        fn.modalIframe( target.menu + '&sys_id=' + sys_id, target.title, { filter: target.filter, iframeMode: target.iframeMode });
    });

    // ファイルダウンロード
    op.$.operationContainer.on('click', '.operationStatusFileDownload', function( e ){
        e.preventDefault();

        const $link = $( this ),
                rest = $link.attr('data-rest'),
                fileName = $link.text();

        // 連続でダウンロードさせない
        if ( $link.is('.nowDownload') ) return;

        $link.addClass('nowDownload');

        const endPoint = `/menu/${Status.string[op.menu].executionListMenu}/${op.id}/${rest}/file/`;
        fn.getFile( endPoint, 'GET', null, { title: getMessage.FTE00185, ext: 'zip' }).then(function( file ){
            fn.download('file', file, fileName ).then(function(){
                $link.removeClass('nowDownload');
            });
        }).catch(function( e ){
            if ( e !== 'break') {
                console.error( e );
                alert( getMessage.FTE00179 );
            }
        });
    });

    // ノードのアニメーション完了時
    op.$.node.find('.node-result').on('animationend', function(){
        if ( op.$.node.is('.complete') ) {
            $( this ).off('animationend').addClass('animationEnd');
        }
    });

    if ( op.info ) {
        op.operationStatusUpdate();
    }
}
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   create_menu.js class CreateMenu patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
function patch_create_menu() {
/*
##################################################
    登録
##################################################
*/
CreateMenu.prototype.registrationMenu = function( type ) {
    return new Promise( ( resolve, reject ) => {
        // 登録データ
        const registrationData = this.createJsonData();
        registrationData.type = type;

        // 進行中モーダル
        let process = fn.processingModal('');

        fn.fetch('/create/define/execute/', null, 'POST', registrationData ).then( (result) => {
            let id  = result['history_id'];
            let string = getMessage.FTE01140;
            let log = string + id;
            this.log.set( 'done', log );

            fn.alert('', fn.escape( log, true ) ).then(function(){
                let url_path = location.pathname,
                    menu_name_rest = result['menu_name_rest'],
                    menu = fn.getParams().menu;
                process.close();
                process = null;
                resolve();

                const href = fn.createPageUrl( menu, {
                    menu_name_rest: menu_name_rest,
                    history_id: id
                });

                window.location.href = href;
            });
        }).catch( ( error ) => {
            if ( fn.typeof( error ) === 'object') {
                if ( error.result === '498-00004') {
                    if ( fn.typeof( error.message ) === 'string') window.alert( error.message );
                } else {
                    let message = this.errorFormat(error.message);
                    this.log.clear();
                    this.log.set('error', message );
                    window.alert(getMessage.FTE01141);
                }
            }
            process.close();
            process = null;
            reject();
        });
    });
}
// ページ移動（履歴）
CreateMenu.prototype.pageMoveHistory = function() {
    const menu = 'menu_creation_history';
    const uuid = fn.getParams().history_id;
    const filter = fn.filterEncode({"uuid":{"NORMAL": uuid }} );
    const href = fn.createPageUrl( menu, {
        filter: filter
    });
    location.replace( href );
}
// ページ移動（モード変更）
CreateMenu.prototype.pageMoveModeChange = function( mode ) {
    const targetId = $('#menu-editor').attr('data-load-menu-id');
    const menu = fn.getParams().menu;
    const params = {
        menu_name_rest: targetId
    };
    if( mode ) params.mode = mode;
    const href = fn.createPageUrl( menu, params );    
    window.location.href = href;
}
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   export_import.js class ExportImport patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
function patch_export_import() {
    /*
##################################################
   Export Events
##################################################
*/
ExportImport.prototype.exportEvents = function() {
    const ex = this;

    // 時刻指定
    const $modeTimeInput = ex.$.content.find('.exportModeTime'),
          $modeTimeButton = ex.$.content.find('.inputDateCalendarButton');
    fn.setDatePickerEvent( $modeTimeInput, getMessage.FTE07003 );

    // エクスポートモード
    ex.$.content.find('.exportMode').on('change', function(){
        const mode = $( this ).val();
        if ( mode === '2') {
            $modeTimeInput.prop('disabled', false );
            $modeTimeButton.prop('disabled', false );
        } else {
            $modeTimeInput.prop('disabled', true );
            $modeTimeButton.prop('disabled', true );
        }
    });

    // エクスポートボタン
    ex.$.content.find('.operationMenu').find('.operationMenuButton').on('click', function(){
        const $button = $( this ),
              exportData = ex.getExportData();

        // 確認HTML
        const html = '<div class="commonSection">'
            + `<div class="commonTitle">${getMessage.FTE07004}</div>`
            + '<div class="commonBody">'
                + `<p class="commonParagraph">${getMessage.FTE07005}</p>`
                + '<table class="commonTable">'
                    + '<tbody class="commonTbody">'
                        + '<tr class="commonTr">'
                            + `<th class="commonTh">${getMessage.FTE07006}</th>`
                            + `<td class="commonTd">${exportData.menu.length}</td>`
                        + '</tr>'
                        + `${( ex.type === 'menuExport')?
                            `<tr class="commonTr">`
                                + `<th class="commonTh">${getMessage.FTE07007}</th>`
                                + `<td class="commonTd">${ex.exportModeText( exportData.mode )}</td>`
                            + `</tr>`
                            + `${( exportData.mode === '2')? `<tr class="commonTr"><th class="commonTh">${getMessage.FTE07008}</th><td class="commonTd">${fn.escape( exportData.specified_timestamp )}</td></tr>`: ``}`: ``}`
                        + '<tr class="commonTr">'
                            + `<th class="commonTh">${getMessage.FTE07009}</th>`
                            + `<td class="commonTd">${( ex.type === 'menuExport')? ex.exportDiscardText( exportData.abolished_type ): ex.exportExcelDiscardText( exportData.abolished_type )}</td>`
                        + '</tr>'
                        + `${( ex.type === 'menuExport')?
                            `<tr class="commonTr">`
                                + `<th class="commonTh">${getMessage.FTE07038}</th>`
                                + `<td class="commonTd">${ex.exportJournalText( exportData.journal_type )}</td>`
                            + `</tr>`: ``}`
                        + '</tr>'
                    + '</tbody>'
                + '</table>'
            + '</div>'
        + '</div>';

        // エクスポート確認
        fn.alert( getMessage.FTE07010, html, 'common', {
            ok: { text: getMessage.FTE07011, action: 'default', style: 'width:160px', className: 'dialogPositive'},
            cancel: { text: getMessage.FTE07012, action: 'negative', style: 'width:120px'}
        }, '480px').then( function( flag ){
            if ( flag ) {
                const rest = ( ex.type === 'menuExport')? '/menu/bulk/export/execute/': '/excel/bulk/export/execute/',
                      manage = ( ex.type === 'menuExport')? 'menu_export_import_list': 'bulk_excel_export_import_list';

                // 読み込み中
                let process = fn.processingModal( getMessage.FTE07013 );
                fn.fetch( rest, null, 'POST', exportData ).then(function( result ){
                    const filter = { execution_no: { NORMAL: result.execution_no } };
                    window.location.href = fn.createPageUrl( manage, {
                        filter: fn.filterEncode( filter )
                    });
                }).catch(function( error ){
                    if ( fn.typeof( error ) === 'object' && error.message ) {
                        alert( error.message );
                    } else {
                        alert( error )
                    }
                    process.close();
                    process = null;
                });
            }
        });
    });
}
/*
##################################################
   Import
##################################################
*/
ExportImport.prototype.importModal = function() {
    const ex = this;

    return new Promise(function( resolve ){
        // Importリスト作成
        const restData = {};

        let fileName = '',
            menuCount = 0;

        if ( ex.type === 'excelImport') {
            // Excel インポート
            const menu = {};
            ex.$.content.find('.exportImportCheckItem:checked').each(function(){
                const $item = $( this ),
                    value = $item.val(),
                    group = $item.attr('data-menuGroup');

                if ( !menu[ group ] ) menu[ group ] = [];
                menu[ group ].push( value );
                menuCount++;
            });
            restData.menu = menu;
            restData.upload_id = ex.importData.upload_id;
            restData.data_portability_upload_file_name = ex.importData.data_portability_upload_file_name;
            fileName = ex.importData.data_portability_upload_file_name;
        } else {
            // Menu インポート
            const menu = [];
            ex.$.content.find('.exportImportCheckItem:checked').each(function(){
                menu.push( $( this ).val() );
                menuCount++;
            });
            restData.menu = menu;
            restData.upload_id = ex.importData.upload_id;
            restData.file_name = ex.importData.file_name;
            fileName = ex.importData.file_name;
        }

        // 確認HTML
        let html = ``
        + `<div class="commonSection">`
            + `<div class="commonTitle">${getMessage.FTE07021}</div>`
            + `<div class="commonBody">`
                + `<p class="commonParagraph">${getMessage.FTE07029}</p>`
                + `<table class="commonTable">`
                    + `<tbody class="commonTbody">`
                        + `<tr class="commonTr">`
                            + `<th class="commonTh">${getMessage.FTE07028}</th>`
                            + `<td class="commonTd">${fn.escape( fileName )}</td>`
                        + `</tr>`
                        + `<tr class="commonTr">`
                            + `<th class="commonTh">${getMessage.FTE07006}</th>`
                            + `<td class="commonTd">${menuCount}</td>`
                        + `</tr>`;
        if ( ex.type === 'menuImport') {
            const specifiedTimeTr = ( ex.importData.mode === '2')?
            `<tr class="commonTr"><th class="commonTh">${getMessage.FTE07008}</th>`
            + `<td class="commonTd">${fn.cv( ex.importData.specified_time, '', true )}</td></tr>`:
            ``;
            html += ``
                        + `<tr class="commonTr">`
                            + `<th class="commonTh">${getMessage.FTE07007}</th>`
                            + `<td class="commonTd">${ex.exportModeText( ex.importData.mode )}</td>`
                        + `</tr>`
                        + specifiedTimeTr
                        + `<tr class="commonTr">`
                            + `<th class="commonTh">${getMessage.FTE07009}</th>`
                            + `<td class="commonTd">${ex.exportDiscardText( ex.importData.abolished_type )}</td>`
                        + `</tr>`
                        + `<tr class="commonTr">`
                            + `<th class="commonTh">${getMessage.FTE07038}</th>`
                            + `<td class="commonTd">${ex.exportJournalText( ex.importData.journal_type )}</td>`
                        + `</tr>`;
        }
        html += ``
                    + `</tbody>`
                + `</table>`
            + `</div>`
        + `</div>`;

        // インポート確認
        fn.alert( getMessage.FTE07030, html, 'common', {
            ok: { text: getMessage.FTE07031, action: 'default', style: 'width:160px', className: 'dialogPositive'},
            cancel: { text: getMessage.FTE07012, action: 'negative', style: 'width:120px'}
        }, '480px').then( function( flag ){
            if ( flag ) {
                const rest = ( ex.type === 'menuImport')? '/menu/import/execute/': '/excel/bulk/import/execute/',
                    manage = ( ex.type === 'menuImport')? 'menu_export_import_list': 'bulk_excel_export_import_list';
                let process = fn.processingModal( getMessage.FTE07032 );
                fn.fetch( rest, null, 'POST', restData ).then(function( result ){
                    const filter = { execution_no: { NORMAL: result.execution_no } };
                    window.location.href = fn.createPageUrl( manage, {
                        filter: fn.filterEncode( filter )
                    });
                }).catch(function( error ){
                    if ( fn.typeof( error ) === 'object') {
                        if ( fn.typeof( error.message ) === 'string') {
                            alert( error.message );
                        } else {
                            alert( getMessage.FTE07033 );
                        }
                    } else {
                        alert( getMessage.FTE07033 );
                    }
                    process.close();
                    process = null;
                    resolve();
                });
            } else {
                resolve();
            }
        });
    });
}
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   compare.js class Compare patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
function patch_compare() {
/*
##################################################
   比較メニューボタン
##################################################
*/
Compare.prototype.compareEvents = function() {
    const cp = this;

    cp.$.content.find('.operationMenuButton').on('click', function(){
        const $button = $( this ),
              type = $button.attr('data-type');

        switch ( type ) {
            case 'compareSelect':
                cp.selectModalOpen('compare').then(function( result ){
                    if ( result ) {
                        cp.compareData.compare = result[0].name;
                        cp.$.setting.html( cp.compareSettingHtml( result[0] ) );
                        cp.$.result.html( cp.compareResultMessageHtml() );

                        cp.$.referenceDate1 = cp.$.setting.find('#referenceDate1');
                        cp.$.referenceDate2 = cp.$.setting.find('#referenceDate2');
                        cp.$.output = cp.$.setting.find('.compareOutput');

                        cp.compareSettingEvents();
                        cp.compareButtonCheck();
                        cp.restExeHost();
                    }
                });
            break;
            case 'hostSelect':
                cp.selectModalOpen('host').then(function( result ){
                    if ( result ) {
                        // 形式を合わせる
                        cp.select.host = result.map(function( item ){
                            if ( fn.typeof( item ) === 'object') {
                                return item.name;
                            } else {
                                return item;
                            }
                        });
                        cp.$.host.html( cp.hostHtml( cp.select.host ) );
                        cp.$.result.html( cp.compareResultMessageHtml() );
                        cp.$.host.removeClass('compareExecuteHost');
                        cp.compareButtonCheck();
                    }
                });
            break;
            case 'compare': {
                $button.prop('disabled', true );
                cp.getCompareSettingData();
                cp.$.result.addClass('nowLoading').empty();
                fn.fetch( cp.rest.compare, null, 'POST', cp.compareData ).then(function( result ){
                    cp.restExeHost();
                    cp.setCompareResult( result );
                }).catch(function( error ){
                    if ( fn.typeof( error ) === 'object') {
                        if ( fn.typeof( error.message ) === 'string') {
                            alert( error.message );
                        } else {
                            alert( getMessage.FTE06021 );
                        }
                    } else {
                        alert( getMessage.FTE06021 );
                    }
                    cp.$.result.html( cp.compareResultMessageHtml() );
                }).then(function(){
                    cp.$.result.removeClass('nowLoading');
                    $button.prop('disabled', false );
                });
            } break;
            case 'download': {
                $button.prop('disabled', true );
                cp.getCompareSettingData();
                fn.getFile( cp.rest.download, 'POST', cp.compareData, { title: getMessage.FTE00185, ext: 'xlsx'}).then(function( file ){
                    const fileName = fn.cv( file.name, '');
                    fn.download('file', file, fileName );
                }).catch(function( error ){
                    if ( fn.typeof( error ) === 'object') {
                        if ( fn.typeof( error.message ) === 'string') {
                            alert( error.message );
                        } else {
                            alert( getMessage.FTE06033 );
                        }
                    } else {
                        if ( error !== 'break') {
                            alert( getMessage.FTE06033 );
                        }
                    }
                }).then(function(){
                    $button.prop('disabled', false );
                });
            } break;
        }
    });
}
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   terraformManagement.js class terraformManagement patch
//
////////////////////////////////////////////////////////////////////////////////////////////////////
function patch_terraformManagement() {
TerraformManagement.prototype.exeRestApi = function( buttonText, rest, method, body, option ) {
    return new Promise(function( resolve ){
        if ( option.download ) {
            fn.getFile( rest, method, body, { title: getMessage.FTE00185 }).then(function( file ){
                const fileName = fn.cv( file.name, '');
                fn.download('file', file, fileName );
            }).catch(function( error ){
                window.console.error( error );
                alert( error.message );
            }).then(function(){
                resolve('noUpdate');
            });
        } else {
            const text = getMessage.FTE00119( buttonText );

            fn.alert(`${buttonText}${getMessage.FTE00118}`, text, 'confiarm', {
                ok: { text: getMessage.FTE00122, action: 'default', style: 'width:160px', className: 'dialogPositive'},
                cancel: { text: getMessage.FTE00123, action: 'negative', style: 'width:120px'}
            }, '400px').then( function( flag ){
                if ( flag ) {
                    let process = fn.processingModal( getMessage.FTE00120 );
                    fn.fetch( rest, null, method, body, { message: true } ).then(function( result ){
                        if ( option.redirect ) {
                            if ( fn.typeof( result ) === 'array') {
                                const value = result[0][ option['redirect_key'] ];
                                if ( value ) {
                                    const href = fn.createPageUrl();
                                    window.location.href = `${href}&${option.redirect + value}`;
                                }
                            }
                        } else {
                            const message = ( fn.typeof( result ) === 'array')? result[1]: result;
                            fn.alert( getMessage.FTE00121, message ).then(function(){
                                resolve();
                            });
                        }
                    }).catch(function( error ){
                        window.console.error( error );
                        alert( error.message );
                        resolve();
                    }).then(function(){
                        process.close();
                        process = null;
                    });
                } else {
                    resolve('noUpdate');
                }
            });
        }
    });
}
}