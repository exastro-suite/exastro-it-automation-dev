(function process( request, response ) {
	try {
        var configTableName = 'u_it_automation_config';
        var tempTableName = 'u_it_automation_temp_file';
        var urlColumnName = 'u_it_automation_url';
        var basicAuthColumnName = 'u_basic_auth_sys_id';
        var textExt = ['tf','hc','hcl','sentinel'];

		// 設定値を取得
		var gr = new GlideRecord( configTableName );
		gr.addQuery('u_user_name', gs.getUserName() );
		gr.orderByDesc('sys_created_on');
		gr.query();

		var baseUrl = '';
		var basicAuthSysId = '';
		if ( gr.next() ) {
			baseUrl = gr.getValue( urlColumnName ) ?? null;
			basicAuthSysId =  gr.getValue( basicAuthColumnName ) ?? null;
		} else {
			response.setStatus(499);
  			response.setBody({ message: 'Failed to get Config Record.'});
			return;
		}
		
		if ( !baseUrl ) {
			response.setStatus(499);
  			response.setBody({ message: 'Failed to get base URL.'});
			return;
		}
		
		var data = request.body.data || {};
		var mode = (data.mode || 'json').toString().trim();
		var path = (data.path || '').toString().trim();
		var method = (data.method || '').toString().trim();
        var ext = (data.ext || '').toString().trim();

		if ( !mode || !path || !method ) {
			response.setStatus(499);
  			response.setBody({ message: 'Invalid data format.'});
			return;
		}
		var endpoint = baseUrl + path;

		var rm = new sn_ws.RESTMessageV2();
		if ( basicAuthSysId ) {
			rm.setAuthenticationProfile('basic', basicAuthSysId );
		}
		rm.setHttpMethod( method );
		rm.setEndpoint( endpoint );
		if ( data.body ) {
			rm.setRequestHeader('Accept', 'application/json');
			rm.setRequestHeader('Content-Type', 'application/json');
			rm.setRequestBody(JSON.stringify(data.body));
		}		

		if ( mode === 'json') {
            //////////////////////////////////////////////////
            // 基本
            //////////////////////////////////////////////////
			var res = rm.execute();
			var raw = String( res.getBody() || '');

			// JSON変換
			var json;
			try {
				json = JSON.parse(raw);
			} catch (pe) {
				response.setStatus(499);
				response.setBody({
					message: pe,
					raw: raw
				});
				return;
			}

			// 結果
			response.setStatus(res.getStatusCode());
			response.setHeader('Content-Type', 'application/json; charset=utf-8');
			response.setBody( json );
		} else if ( mode === 'upstream') {
            //////////////////////////////////////////////////
            // ファイル取得
            //////////////////////////////////////////////////
			var tempName = 'download.txt';
			if ( ext && textExt.indexOf( ext ) === -1 ) {
				tempName = 'download.' + ext;
			}

            // 新しいレコードを作成
            var holder = new GlideRecord( tempTableName );
            holder.initialize();
            var holderSysId = holder.insert();
            if (!holderSysId) {
                response.setStatus(499);
				response.setBody({
					message: 'GlideRecord error.'
				});
                return;
            }

			// 添付保存 => execute
            rm.saveResponseBodyAsAttachment( tempTableName, holderSysId, tempName);
            var resp = rm.execute();

            // attachSysId取得
            var attachSysId = null;
            try {
                attachSysId = resp.getResponseAttachmentSysid();
            } catch (e) {}

            // getResponseAttachmentSysidで取得できなかった場合レコードから取得
            if (!attachSysId) {
                var att = new GlideRecord('sys_attachment');
                att.addQuery('table_name', tableName);
                att.addQuery('table_sys_id', holderSysId);
                att.addQuery('file_name', tempName);
                att.orderByDesc('sys_created_on');
                att.setLimit(1);
                att.query();
                if (att.next()) attachSysId = att.getValue('sys_id');
            }

            if (!attachSysId) {
                response.setStatus(499);
				response.setBody({
					message: 'sys id error.'
				});
                return;
            }

            // Content-Dispositionからファイル名を取得
            var cd = String(resp.getHeader('Content-Disposition') || resp.getHeader('content-disposition') || '');
            var fileName = /filename\s*=\s*([^;]+)/i.exec(cd) || '';

            // Content-Length取得
            var contentLength = resp.getHeader('Content-Length');
            if (!contentLength) {
                contentLength = 0;
            }
            // 数値化
            contentLength = parseInt(contentLength, 10);
            
            var status = resp.getStatusCode();
            response.setStatus(status);
            response.setHeader('Content-Type', 'application/octet-stream');
            response.setHeader('Content-Disposition', 'attachment; filename="' + fileName + '"');
            response.setHeader('X-File-Size',  String(contentLength));

            var writer = response.getStreamWriter();
            var is = new GlideSysAttachmentInputStream(attachSysId);
            writer.writeStream(is);
            return;
		}
	} catch (e) {
		response.setStatus(499);
		response.setBody({
			message: String(e),
			result: '499-00000'
		});
	}
})( request, response );